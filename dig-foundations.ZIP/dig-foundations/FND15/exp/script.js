'use strict'
// 1行目に記載している 'use strict' は削除しないでください

function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Yay! Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.log("    actual: ", actual);
    console.log("  expected: ", expected);
    console.trace();
  }
}

console.log("Hello World!");


  /**
    * @param {Array<string>} names - 友達の名前が入った配列
    * @returns {Array<string>} 友達の名前それぞれに `"Hello"` の挨拶が付け加わった文字列を要素に持つ配列
    */
  function sayHelloToFriends(names){
    let result = [];
    for(let i = 0; i < names.length;i++){
      result.push("Hello, " + names[i] + "!");
    }
    return result;
  }

 const friends = ["Mario", "Luigi"];
 test(sayHelloToFriends(friends), ["Hello, Mario!", "Hello, Luigi!"]);


 //

const obj1 = { a: "A" };
const obj2 = { a: "A", b: 2 };
const obj3 = { a: "A", b: 2, c: "C", d: true };
const obj4 = { a: "A", c: "C" };
 

   /**
    * @param {object} オブジェクト
    * @returns {{ [key: string]: string }} 引数で与えられたオブジェクトの、値が文字列であるキーと値のペアだけを持つ新しいオブジェクト。
    */
   function filterObjectForStrings(object) {
    let result = {};
    for (const [key, value] of Object.entries(object)){
      if(typeof value === "string"){
        result[key] = value
      }
    }
    return result;
    }

  test(filterObjectForStrings(obj1), obj1); // 変化なし
  test(filterObjectForStrings(obj2), obj1); // 値が 2 のペアは含まれていない
  test(filterObjectForStrings(obj3), obj4); // 値が 2 や true のペアは含まれていない

  