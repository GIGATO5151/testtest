'use strict'
// 1行目に記載している 'use strict' は削除しないでください

//console.log("Hello world!");

//演習//

// let a = 5;
// a + 10;

// console.log(a); // => 5

// let b = 17;

// b = ( b + 1 ) / 2 ;

// console.log(b); // => (17 + 1) / 2 => 9

// let c = 5;
// let d = 20;

// c = d; // c => 20
// d = d + 7; // d => 20 + 7 => 27
// console.log(c); //c => 20 代入されただけ
// console.log(d); //d => 27

// let e = 10;
// let f = 5;
// e = e * 4 - 3;  // e => 10 * 4 - 3 => 37
// e + 17; // 37 + 17 => 54 代入無し
// e = e + f; // 37 + 5 => 42
// console.log(e);  // e => 42 // => ???

// ここにあなたのコードを書いてください
const name = "Adachi Hiroki";
let age = 34;
const isProgrammer = "ture";
let currentTask = 1;

currentTask = 2;


console.log(name); // あなたの名前を表示
console.log(age); // あなたの年齢を表示
console.log(isProgrammer); // "true" を表示
console.log(currentTask); // "1" を表示


// 正方形の面積を計算して保存
const squareSideLength = 2;
// ここにあなたのコードを書いてください
let squareArea = 0;

squareArea = squareSideLength * squareSideLength;

console.log(squareArea); // "4" を表示


// 長方形の面積を計算して保存
const rectangleBaseLength = 3;
const rectangleHeightLength = 4;
// ここにあなたのコードを書いてください
let rectangleArea = 0;

rectangleArea = rectangleBaseLength * rectangleHeightLength

console.log(rectangleArea); // "12" を表示

// 三角形の面積を計算して保存
const triangleBaseLength = 4;
const triangleHeightLength = 5;
// ここにあなたのコードを書いてください

let triangleArea = 0;

triangleArea = triangleBaseLength * triangleHeightLength / 2;

console.log(triangleArea); // "10" を表示

// 円の円周と面積を計算して保存する
const circleDiameter = 10;
// ここにあなたのコードを書いてください

let circleCircumference = 0;
let circleArea = 0;
let py = 3.141592653589793;

circleCircumference = circleDiameter * py;
circleArea = (circleDiameter / 2) ** 2 * py;

console.log(circleCircumference); // "31.41592653589793" に近い値を表示
console.log(circleArea); // "78.53981633974483" に近い値を表示


//演習//

let a = "B";
let b = "A";

let c = 0;
let d = 0;

c = a; // c => B
d = b; // d => A

b = c; // b => B
a = d; // a => A

console.log(a); // "A" を表示
console.log(b); // "B" を表示

//指数関数的成長//

let value = 1;

console.log(value); // "1" を表示

// value に何かを行う
value = value * 2;

console.log(value); // "2" を表示

// value に何かを行う
value = value * 2;

console.log(value); // "4" を表示

// value に何かを行う
value = value * 2;

console.log(value); // "8" を表示

// value に何かを行う
value = value * 2;

console.log(value); // "16" を表示

// value に何かを行う
value = value * 2;

console.log(value); // "32" を表示

// value に何かを行う
value = value * 2;

console.log(value); // "64" を表示


//文字列結合//

const firstName = "Yan";
const lastName = "Fan";
const city = "Tokyo";

console.log("Hello, my name is " + firstName + " " + lastName + "." + "I live in " + city + "."); // "Hello, my name is Yan Fan. I live in Tokyo." を表示


//応用演習//

// ヒント： ここで何かする必要があるかもしれません
let aaa = 0;

function counter() {
  // ここにあなたのコードを書いてください
  aaa++;
  console.log(aaa);

}

counter();
counter();
counter();
// etc.

//応用2//


function isOdd(givenNumber) {
  if (givenNumber % 2 == 1) {
    console.log("Yes, it's odd");
  }
  else {
    console.log("No, it's even");
  }

  // ここにあなたのコードを書いてください
  // 与えられた数値によって、"Yes, it's odd" もしくは "No, it's even" を表示
}

isOdd(121);


const variableString = "I am a string";
console.log(typeof variableString);
//Type of は型を評価して、返す。variableStringの中身は文字列なので、stringが返される

const variableNumber = 1;         // "number"と表示させるにはどんな値を代入すればいいでしょう？
console.log(typeof variableNumber); // "number"と表示されましたか？

// ここにコードを書いて、"boolean"と表示されるようにしてください。
const variableBoolean = false;
console.log(typeof variableBoolean);
//booleanはtrue or falseが入っていれば、タイプはbooleanと評価される。

//ここにコードを書いて、"undefined"と表示されるようにしてください。
const variableUndefined = undefined;
console.log(typeof variableUndefined);

const numberA = 8;
const numberB = 10;

const average = (numberA + numberB) / 2;
console.log(average); // numberA と numberB の平均が表示される。
