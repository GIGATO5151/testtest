'use strict'
// 1行目に記載している 'use strict' は削除しないでください

function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Yay! Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.log("    actual: ", actual);
    console.log("  expected: ", expected);
    console.trace();
  }
}

//////////////////////No.1///////////////////

/**
 * @param {Array<num>} array
 * @param {boolean} boolean
 * @returns {Array<num>} boolean が true の場合は、偶数のみの配列を返し、 false の場合は、奇数のみの配列を返します。
 */

function evenOrOdd(array, boolean) {
  if (boolean) {
    return array.filter((element) => element % 2 === 0)
  }
  else {
    return array.filter((element) => element % 2 !== 0)
  }
}

test(evenOrOdd([1, 2, 3, 4, 5], true), [2, 4]); // [2, 4]
test(evenOrOdd([0, 4, 36], false), []); // []
test(evenOrOdd([-1, -2, 4, -5, -7], false), [-1, -5, -7]); // [-1, -5, -7]


//////////////////////No.2///////////////////
/**
 * @param {obj} obj
 * @param {string} str
 * @returns {Array<num>} オブジェクト中、ターゲットにマッチする値を持つ全てのキーを含む新しい配列を返します。
 */

function findKeys(obj, str) {
  const result = [];
  for (const key in obj) {
    if (obj[key] === str) {
      result.push(key)
    }
  }
  return result;
}

test(findKeys({ a: 1, b: 2, c: 6, d: 4, e: 2 }, 2), ["b", "e"]); // ["b", "e"]
test(findKeys({ 1: "h", b: "el", c: "hello", d: "hello", e: "o" }, "hello"), ["c", "d"]); // ["c", "d"]

//////////////////////No.3///////////////////

/**
 * @param {Array} array1
 * @param {Array} array2
 * @returns {Array<num>} 第一引数の配列の要素をオブジェクトのキーとして設定し、第二引数の配列の要素をオブジェクトの値として設定します。
 * 
 */

function buildObject(array1, array2) {
  let result = {};
  for (let i = 0; i < array1.length; i++) {
    result[array1[i]] = array2[i];
  }
  return result;
}

test(buildObject(["a", "b", "c"], [1, 2, 3]), { "a": 1, "b": 2, "c": 3 }); // {"a": 1, "b": 2, "c": 3}
test(buildObject(["cat", "dog", "duck"], ["meow", "woof", "quack"]), { "cat": "meow", "dog": "woof", "duck": "quack" }); // {"cat": "meow", "dog": "woof", "duck": "quack"}
test(buildObject(["cat", "dog", "duck"], [null, 0, NaN]), { "cat": null, "dog": 0, "duck": NaN }); // {"cat": null, "dog": 0, "duck": NaN}
test(buildObject(["abc", "def", "ghi"], [[0, 1, 2], [3, 4, 5], [6, 7, 8]]), { "abc": [0, 1, 2], "def": [3, 4, 5], "ghi": [6, 7, 8] });  // {"abc": [0, 1, 2], "def": [3, 4, 5], "ghi": [6, 7, 8]}

//////////////////////No.4///////////////////

/**
 * @param {number} x
 * @returns {(y: number) => number} 引数として 1 つの数値 y を受けとる関数を返します。リターンされた関数は、実行時に 'x' と 'y' の和を返します。
 */

function add(x) {
  return function (y) {
    return x + y
  }
}

const addTwo = add(2);
test(addTwo(3), 5); // 5
test(addTwo(70), 72); // 72

const addOneHundred = add(100);
test(addOneHundred(3), 103); // 103

//////////////////////No.5///////////////////

function simpleHello() {
  console.log("Hello");
}

function anotherGreeting(name) {
  return "Hello, " + name;
}

const foo = simpleHello();
const bar = anotherGreeting("JavaScript");

console.log(foo);
console.log(bar);

// あなたの回答と、なぜそうなるのかの説明をここに記載してください
/*
undefinedが出た後に、Hello, JavaScriptと出るようになる。

Javascriptは上から読み込む特性もあるが、関数も先に読む特性がある。
simpleHello関数に関しては、returnが無い為、返り値はundefinedとなる。

また、barに代入されたanotherGreeting関数はJavaScriptという文字列が仮引数に代入され
returnでHelloにJavaScriptが足された文字列が返される。
その為、undefinedが出た後に、Hello, JavaScriptという結果がconsole.logに表示される

*/


//////////////////////No.6///////////////////
/*別のscript.jsに記載*/


//////////////////////No.7///////////////////

/**
 * @param {Obj or Array} any
 * @param {function} func
 * @returns {Array} コレクション内の各要素に対してコールバック関数を実行した結果を要素に持つ新しい配列を返します。
 */
function map(any, func) {
  let result = [];
  if (Array.isArray(any)) {
    for (const num of any) {
      result.push(func(num));
    }
  } else if (typeof any === "object") {
    for (const key in any) {
      result.push(func(any[key]));
    }
  }
  return result;
}

function addOne(num) {
  return num + 1;
}

test(map([1, 2, 3], addOne), [2, 3, 4]); // [2, 3, 4]
test(map({ a: 1, b: 2, c: 3 }, addOne), [2, 3, 4]); // [2, 3, 4]

//////////////////////No.8///////////////////

/**
 * @param {string} str1
 * @param {string} str2
 * @returns {Array} 「1 単語の文字列」を受け取り、第一引数の中央の単語を第二引数の文字列に置き換えた新しい文字列を返します
 */

function changeMiddle(str1, str2) {
  const words = str1.split(" ");
  const judge = Math.floor(words.length / 2);
  if (words.length % 2 === 1) {
    words[judge] = str2;
    const rebuild = words.join(" ");
    return rebuild;
  } else {
    return "The number of words is not odd";
  }
}

test(changeMiddle("I like cats", "love"), "I love cats"); // "I love cats"
test(changeMiddle("red green blue", "yellow"), "red yellow blue"); // "red yellow blue"
test(changeMiddle("red green blue black white", "yellow"), "red green yellow black white");
test(changeMiddle("red green blue black", "yellow"), "The number of words is not odd");

//////////////////////No.9///////////////////

/**
 * @param {Array} array
 * @returns {String} 要素の登場回数が最も多い型をチェックし、型が多かった数を返す。
 */

function countSomething(array) {
  const stringCount = array.filter(elem => typeof elem === "string").length;
  const booleanCount = array.filter(elem => typeof elem === "boolean").length;
  const numberCount = array.filter(elem => typeof elem === "number").length;

  if (booleanCount < stringCount && numberCount < stringCount) {
    return `STRING COUNT: ${stringCount}`;
  } else if (stringCount < booleanCount && numberCount < booleanCount) {
    return `BOOL COUNT: ${booleanCount}`;
  } else {
    return `NUMBER COUNT: ${numberCount}`;
  }
}


test(countSomething(["a", "b", "c", true, false, 2]), "STRING COUNT: 3"); // "STRING COUNT: 3"
test(countSomething([true, true, false, true]), "BOOL COUNT: 4"); // "BOOL COUNT: 4"
test(countSomething([true, true, 1, 0, 1, false, 1]), "NUMBER COUNT: 4"); // "NUMBER COUNT: 4"

//////////////////////No.10///////////////////

/**
 * @param {Collection} any
 * @param {function} func
 */

function each(any, func) {
  let result
  if (Array.isArray(any)) {
    for (const num of any) {
      result = num;
      func(result)
    }
  } else if (typeof any === "object") {
    for (const key in any) {
      result = any[key];
      func(result);
    }
  }
}

function view(disp) {
  return disp
}

each({ a: 1, b: 2, c: 3 }, console.log);
each([4, 5, 6], console.log);

// 上記を実行すると下記を表示するはずです
// 1
// 2
// 3
// 4
// 5
// 6

//////////////////////No.11///////////////////
/**
* @param {function} funcA
* @param {function} funcB
* @returns {number}リターンされた関数を実行すると、funcA の実行結果を funcB の引数として渡した結果を返します。
*/


function compose(funcA, funcB) {
  return function (x) {
    return funcB(funcA(x));
  }
}

function multiplyTwo(x) {
  return x * 2;
}

function addTen(x) {
  return x + 10;
}

const baz = compose(multiplyTwo, addTen);
test(baz(5), 20); // 20
test(baz(100), 210); // 210