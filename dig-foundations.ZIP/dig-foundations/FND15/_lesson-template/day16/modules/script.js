'use strict'
// 1行目に記載している 'use strict' は削除しないでください


const obj1 = {a:"A",b:"B"}

const obj2 = {b:"B",a:"A"}

test(obj1,obj2)



//////////////////////////////////////////
 /**
    * @param {{ [key: string]: number }} num
    * @returns {{ [key: string]: number }} 与えられたオブジェクトと同じ値を持つが、数値には 1 が足されたオブジェクト
    */
  function incrementNumbers(num){
    for(const key in num){
      if(typeof num[key] === "number"){
      num[key]++
    }
  }
     return num
  }


 test(incrementNumbers({ a: 1, b: 2, 1: 3, d: "hello" }), {
  a: 2,
  b: 3,
  1: 4,
  d: "hello",
});
test(incrementNumbers({ a: 2, b: 3, 1: 4, d: "hello" }), {
  a: 3,
  b: 4,
  1: 5,
  d: "hello",
});