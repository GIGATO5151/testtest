'use strict'
//1行目に記載している 'use strict' は削除しないでください

console.log("Hello world!");

let actual;
let expected;


////////////////////////////////////基礎演習No.1//////////////////
/**
   * @param {string} str - テストの対象となる文字列
   * @param {number} num - 閾値
   * @returns {any} 与えられた文字列の長さが指定された閾値より長いかどうか
   */
function isLongerThan(str, num) {
  let aaa = str.length;
  if (typeof str === "string") {
    if (aaa > num) {
      return true;
    }
    return false;
  } return "Invalid input."
}

actual = isLongerThan("three", 3);
expected = true;

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = isLongerThan("three", 5);
expected = false;

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = isLongerThan(3, 5);
expected = "Invalid input.";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}


////////////////////////////基礎演習No.2//////////////////////////////////
/**
   * @param {number} num - テストの対象となる数値
   * @returns {boolean} 与えられた数値が奇数かどうかを表すブーリアン
   */
function isOddWithoutIf(num) {
  if (typeof num === "number") {
    return (num % 2 === 1);
  } return "Invalid input."
}

actual = isOddWithoutIf(3);
expected = true;

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = isOddWithoutIf(4);
expected = false;

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = isOddWithoutIf("あああ");
expected = "Invalid input.";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}


///////////////////////基礎演習No.3///////////////////////////

/**
* @param {number} num - 数値（0-10）。その名前がアルファベットの形で返ることになる
* @returns {"zero"|"one"|"two"|"three"|"four"|"five"|"six"|"seven"|"eight"|"nine"|"ten"} 与えられた数値をアルファベットで記した時の名前
*/

function getSimpleNumberName(num) {
  if (typeof num === "number") {
    if (num === 0) {
      return "zero";
    }
    else if (num === 1) {
      return "one";
    }
    else if (num === 2) {
      return "two";
    }
    else if (num === 3) {
      return "three";
    }
    else if (num === 4) {
      return "four";
    }
    else if (num === 5) {
      return "five";
    }
    else if (num === 6) {
      return "six";
    }
    else if (num === 7) {
      return "seven";
    }
    else if (num === 8) {
      return "eight";
    }
    else if (num === 9) {
      return "nine";
    }
    else if (num === 10) {
      return "ten";
    }
    return "Invalid input."
  }
}

actual = getSimpleNumberName(0);
expected = "zero";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = getSimpleNumberName(10);
expected = "ten";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = getSimpleNumberName(11);
expected = "Invalid input.";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}


// さらにテストを書いて、コードが正しいことを確認してください


/**
* @param {number} num - 正多角形の辺の数 (3-8)
* @returns {"triangle"|"square"|"pentagon"|"hexagon"|"heptagon"|"octagon"} 与えられた数の辺を持つ凸多角形の英語名
*/
function getRegularConvexPolygonName(num) {
  if (typeof num === "number") {
    if (num === 3) {
      return "triangle";
    }
    else if (num === 4) {
      return "square";
    }
    else if (num === 5) {
      return "pentagon";
    }
    else if (num === 6) {
      return "hexagon";
    }
    else if (num === 7) {
      return "heptagon";
    }
    else if (num === 8) {
      return "octagon";
    }
  }
  return "Invalid input."
}

actual = getRegularConvexPolygonName(3);
expected = "triangle";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = getRegularConvexPolygonName(2);
expected = "Invalid input.";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = getRegularConvexPolygonName(true);
expected = "Invalid input.";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

// さらにテストを書いて、コードが正しいことを確認してください

/**
* @param {1|2|3|4|5|6|7|8|9|10|11|12} hour - 時 (12時間制)
* @param {number} min - 分
* @param {"AM"|"PM"} noon - "AM" または "PM"
* @returns {"morning"|"afternoon"|"evening"|"night"} 大まかな「時間帯」
*/
function getTimeOfDay(hour, min, noon) {
  if (noon === "AM") {
    if (hour >= 4 && hour <= 11) {
      if (min >= 0 && min <= 59) {
        return "morning";
      }
    }
    else if (hour >= 1 && hour <= 3) {
      if (min >= 0 && min <= 59) {
        return "night";
      }
    }
    if (hour === 12) {
      if (min >= 0 && min <= 59) {
        return "night"
      }
    }
  }

  if (noon === "PM") {
    if (hour >= 1 && hour <= 4) {
      if (min >= 0 && min <= 59) {
        return "afternoon";
      }
    }
    else if (hour >= 5 && hour <= 7) {
      if (min >= 0 && min <= 59)
        return "evening";
    }

    if (hour === 8) {
      if (min >= 0 && min <= 29) {
        return "evening";
      }
      else if (min >= 30 && min <= 59)
        return "night";
      if (min >= 30 && min <= 59) {
        return "night";
      }
    }

    if (hour >= 9 && hour <= 11) {
      if (min >= 0 && min <= 59) {
        return "night"
      }
    }
    if (hour === 12) {
      if (min >= 0 && min <= 59) {
        return "afternoon"
      }
    }
  }
  return "Invalid input."
}

actual = getTimeOfDay(4, 0, "AM");
expected = "morning";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = getTimeOfDay(3, 59, "AM");
expected = "night";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = getTimeOfDay(5, 0, "PM");
expected = "evening";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = getTimeOfDay(8, 29, "PM");
expected = "evening";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = getTimeOfDay(11, 59, "AM");
expected = "morning";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}


actual = getTimeOfDay(4, 59, "PM");
expected = "afternoon";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

// さらにテストを書いて、コードが正しいことを確認してください。

/**
* @param {number} num - 半径
* @returns {number} 与えられた半径の円の面積
*/
function getAreaOfCircle(num) {
  return (Math.pow(num, 2) * Math.PI);
}

actual = getAreaOfCircle(2);
expected = 12.566370614359172;

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

   // ここにあなたのテストを書きましょう

