'use strict'
//1行目に記載している 'use strict' は削除しないでください

console.log("Hello world!");


//////////////////////////WramUp//////////////////////

/**
    * @param {number} X - 1 番目の数字
    * @param {number} Y - 2 番目の数字
    * @returns {"X は Y と等しい" | "X は Y より小さい" | "X は Y より大きい"} 与えられた 2 つの数字の比較結果
    */
function compareTwoNumbers(X, Y) {
  if (X === Y) {
    return `${X} は ${Y} と等しい`;
  }
  else if (X < Y) {
    return `${X} は ${Y} より小さい`;
  }
  else
    return `${X} は ${Y} より大きい`;
}

let actual = compareTwoNumbers(1, 1);
let expected = "1 は 1 と等しい";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = compareTwoNumbers(3, 4);
expected = "3 は 4 より小さい";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}
actual = compareTwoNumbers(5, 4);
expected = "5 は 4 より大きい";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}


// "X は Y より大きい" というテストを書いてみましょう



function sayIfComfortabel(temp) {
  if (temp >= 20 && temp <= 25) {
    return "It's comfortable.";
  } else if (temp < 18 || temp > 28) {
    return "It's not comfortable.";
  }
  else {
    return "It's ok.";
  }
}

console.log(sayIfComfortabel(26));

function whatToDo(isTired, hasMoney) {
  if (!isTired) {
    return "勉強しよう";
  } else {
    if (hasMoney) {
      return "コーヒーを買おう";
    }
    else {
      return "昼寝しよう";
    }
  }
}

console.log(whatToDo(true, false));

   /**
    * @param {string} str - テストの対象となる文字列
    * @param {number} num - 閾値
    * @returns {any} 与えられた文字列の長さが指定された閾値より長いかどうか
    */
   // ここにコードを書きましょう
    function isLongerThan(str,num){
      if (str.length > num){
        return true;
      }else if(str.length <= num){
        return false;
      }else{
        return "Invalid input.";
      } 
    }

   actual = isLongerThan("three", 3);
   expected = true;

   if (actual === expected) {
     console.log("Yay! Test PASSED.");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.log("    actual: ", actual);
     console.log("  expected: ", expected);
   }

   actual = isLongerThan("three", 5);
   expected = false;

   if (actual === expected) {
     console.log("Yay! Test PASSED.");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.log("    actual: ", actual);
     console.log("  expected: ", expected);
   }

   actual = isLongerThan(3, 5);
   expected = "Invalid input.";

   if (actual === expected) {
     console.log("Yay! Test PASSED.");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.log("    actual: ", actual);
     console.log("  expected: ", expected);
   }

   

