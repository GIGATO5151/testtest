'use strict'
//1行目に記載している 'use strict' は削除しないでください

console.log("Hello world!");

let actual;
let expected;


////////////////////基礎No.1+2////////////////////////
/**
 * @param {number} age - 年齢
 * @returns {boolean} 与えられた年齢がティーンエイジャー（13 歳から 19 歳までの間：「thirTEEN」から「nineTEEN」）かどうか
 */
function isTeenager(age) {
  // ここにコードを書きましょう.
  if (typeof age === "number") {
    if (age >= 13 && age <= 19) {
      return true;
    }
    else {
      return false;
    }
  } else {
    return "無効です！与えられた年齢は数字ではありません！";
  }
}

actual = isTeenager(3);
expected = false;

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = isTeenager(14);
expected = true;

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = isTeenager("Hello!");
expected = "無効です！与えられた年齢は数字ではありません！";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = isTeenager(true);
expected = "無効です！与えられた年齢は数字ではありません！";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = isTeenager();
expected = "無効です！与えられた年齢は数字ではありません！";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}
// さらにテストを書いて、コードが正しいことを確認してください。

////////////////////基礎No.3////////////////////////

/**
 * @param {string} person - 人の名前
 * @param {boolean} polite - 丁寧な挨拶にするかどうかを表すブーリアン
 * @param {boolean} greet - "Hello" なら true を、"Goodbye" なら false
 * @returns {string} 与えられた引数に応じた適切な挨拶の文章
 */
function anotherGreeting(person, polite, greet) {
  if (typeof person === "string" || typeof polite === "boolean" || typeof greet === "boolean") {
    if (polite === true && greet === true) {
      return "Hello, " + person + "-san.";
    }
    else if (polite === false && greet === true) {
      return "Hello, " + person + "!"
    }
    else if (polite === true && greet === false) {
      return "Goodbye, " + person + "-san.";
    }
  } return "無効なインプットです！";
}

actual = anotherGreeting("Mary", true, true);
expected = "Hello, Mary-san.";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = anotherGreeting("Mary", false, true);
expected = "Hello, Mary!";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = anotherGreeting("Felix", true, false);
expected = "Goodbye, Felix-san.";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

// さらにテストを書いて、コードが正しいことを確認してください。


/**
    * @param {number} ??? - 0 以上 100 以下の点数
    * @returns {"A"|"B"|"C"|"D"|"F"} 点数に応じた成績
    */

function getLetterGrade(number) {
  if (number < 100 && number > 0) {

    if (number >= 90 && number <= 100) {
      return "A";
    }
    else if (number <= 89 && number >= 80) {
      return "B";
    }
    else if (number <= 79 && number >= 70) {
      return "C";
    }
    else if (number <= 69 && number >= 60) {
      return "D";
    }
    else return "E";
  }
  return "無効な点数です。";
}


actual = getLetterGrade(95);
expected = "A";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = getLetterGrade(70);
expected = "C";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}
actual = getLetterGrade(59);
expected = "E";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = getLetterGrade(101);
expected = "無効な点数です。";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = getLetterGrade(-10);
expected = "無効な点数です。";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

// さらにテストを書いて、コードが正しいことを確認してください

////////////////////////中級演習No.4///////////////////
/**
    * @param {"A"|"B"|"C"|"D"|"F"} score - 成績
    * @returns {number} 各成績における最高点
    */

  function getBestNumericalGrade(score){
    if (score === "A" || score === "B" || score === "C" || score === "D" || score === "E"){
    if (score === "A") {
      return 100;
    }
    else if (score === "B") {
      return 89;
    }
    else if (score === "C") {
      return 79;
    }
    else if (score === "D") {
      return 69;
    }
    else if (score === "E"){
    return 59;
    }
  } else return "無効な点数です。";
}

actual = getBestNumericalGrade("A");
expected = 100;

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = getBestNumericalGrade("B");
expected = 89;

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}
actual = getBestNumericalGrade("恐竜ってすばらしい");
expected = "無効な点数です。";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = getBestNumericalGrade(100);
expected = "無効な点数です。";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

// さらにテストを書いて、コードが正しいことを確認してください


///////////////////応用演習No.1//////////////////////
 /**
    * @param {any} ope1 - １つめの被演算子
    * @param {any} ope2 - ２つめの被演算子
    * @returns {any} ２つの被演算子を与えられた順番のまま || で評価したときと同じ結果
    */
   // ここにコードを書きましょう

    function or(ope1,ope2){
      if(ope1){
        return ope1; //もしope1がtrueならope1を返して
      }
        else return ope2;//ope1がfalseならope2を返す
    }

   actual = or(true, true);
   expected = true;

   if (actual === expected) {
     console.log("Yay! Test PASSED.");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.log("    actual: ", actual);
     console.log("  expected: ", expected);
   }

   actual = or(true, false);
   expected = true;

   if (actual === expected) {
     console.log("Yay! Test PASSED.");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.log("    actual: ", actual);
     console.log("  expected: ", expected);
   }

   actual = or("bananas", false);
   expected = "bananas";

   if (actual === expected) {
     console.log("Yay! Test PASSED.");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.log("    actual: ", actual);
     console.log("  expected: ", expected);
   }

   actual = or("", "bananas");
   expected = "bananas";

   if (actual === expected) {
     console.log("Yay! Test PASSED.");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.log("    actual: ", actual);
     console.log("  expected: ", expected);
   }
   // さらにテストを書いて、コードが正しいことを確認してください

   /////////////////////////応用演習No.2////////////////////
   /**
    * @param {any} ope1 - １つめの被演算子
    * @param {any} ope2 - ２つめの被演算子
    * @returns {any} ２つの被演算子を与えられた順番のまま && で評価したときと同じ結果
    */
   // ここにコードを書きましょう
    function and(ope1,ope2){
      if(!ope1){
        return ope1;
      }
        return ope2;
      
    }

   actual = and(true, true);
   expected = true;

   if (actual === expected) {
     console.log("Yay! Test PASSED.");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.log("    actual: ", actual);
     console.log("  expected: ", expected);
   }

   actual = and(true, false);
   expected = false;

   if (actual === expected) {
     console.log("Yay! Test PASSED.");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.log("    actual: ", actual);
     console.log("  expected: ", expected);
   }

   actual = and(false, true);
   expected = false;

   if (actual === expected) {
     console.log("Yay! Test PASSED.");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.log("    actual: ", actual);
     console.log("  expected: ", expected);
   }

   actual = and("bananas", false);
   expected = false;

   if (actual === expected) {
     console.log("Yay! Test PASSED.");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.log("    actual: ", actual);
     console.log("  expected: ", expected);
   }

   actual = and("", "bananas");
   expected = "";

   if (actual === expected) {
     console.log("Yay! Test PASSED.");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.log("    actual: ", actual);
     console.log("  expected: ", expected);
   }
   // さらにテストを書いて、コードが正しいことを確認してください