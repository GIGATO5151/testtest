'use strict'
// 1行目に記載している 'use strict' は削除しないでください
function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.group("Result:");
    console.log("  actual:", actual);
    console.log("expected:", expected);
    console.groupEnd();
  }
}


// #1
function greeting() {
  console.log("Hello!");
}
//返り値を持つ

// #2
let triple = function (x) {
  return 3 * x;
};
//値を持つ

// #3
let double = function (x) {
  console.log(2 * x);
};
//値を持つ

// #4
const cache = [];

function average(array) {
  let result = 0;
  for (const number of array) {
    result = result + number;
  }
  result = result / array.length;

  cache.push(result);
  return result;
}

//両方持つ



// #5
function sayHello(friend) {
  const languages = ["Hello", "Konnichiwa", "Hola", "Nihao"];
  const randomIndex = Math.round(Math.random() * languages.length - 1);
  const randomGreeting = languages[randomIndex];
  console.log(randomGreeting + " " + friend + "!");
}

//副作用を持つ

//////////////////////////////////////////////////////////////////

function greeting() {
  console.log("Hello!");
}
//1-関数が宣言される
//console.logでHelloが表示される


function runSomething(func) {
  func();
}
//1-関数が宣言される

runSomething(greeting);

//2-関数が呼び出される
//3runSomethingの関数にgreetingが引数として代入され
//func=greetingとなる。つまり、function greeting()が
//呼び出され、Hello！が表示される。

//unSomething(greeting());

//greetingを変数で呼び出すとHello!が呼び出される
//これによってfuncがHello！となり、Hello!という関数が宣言されてない為
//codeはストップする。


//////////////////////基礎演習No.1/////////////////////////////

// function returnAll(value) {
//   return value;
// }

//関数式で示すと
// let returnAll = function (value) {
//   return value;
// }

// console.log(returnAll(5));
// console.log(typeof returnAll(false)); // boolean
// console.log(typeof returnAll(5)); // number
// console.log(typeof returnAll("5")); // string
// console.log(typeof returnAll([])); // object
// console.log(typeof returnAll({ a: 1 })); // object

// function foo() {
//   return "hi";
// }

// console.log(typeof returnAll(foo)); // function
// console.log(typeof returnAll(foo())); // string

//fooだけだとfunctionの名前なのでfunction
//foo()だと実行されるので"hi"となり、string

////////////////////中級演習No.1////////////////////

/**
 * @param {Function} doSomething
 * @param {any} num - 与えられた関数に渡す引数
 * @returns {any} 与えられた引数を、与えられた関数に渡したときの返り値
 */
function doSomething(any, number) {
  return any(number);
}

function addTen(number) {
  return number + 10;
}

test(doSomething(addTen, 6), 16);
test(doSomething(addTen, -100), -90);

test(
  doSomething(function (num) {
    return num * 4;
  }, 2),
  8
);


////////////////////////解説//////////////////

const outer = function () {
  return function () {
    return 5;
  };
};

console.log(outer());
/*
ƒ () {
    return 5;
  }
  */

console.log(typeof outer()); // function

const inner = outer();
console.log(inner);
/*
ƒ () {
    return 5;
  }
  */

console.log(typeof inner); //function

console.log(outer(
  function () {
    return 5;
  })());

//関数式を使用する場合はouterはクロージャを返すように書く必要があるが
//最後に()を付けることを忘れてはいけない。function{}()
//関数宣言タイプのクロージャ―だと、functio｛｝のみで対応出来る。


const add = function (x) {
  return function (y) {
    return x + y;
  };
};

const addFive = add(5);
console.log(addFive);
/*
ƒ (y) {
  return x + y;
}
*/

let foo = addFive(3);
console.log(foo); // 8

//これはaddFiveに3が代入されたことで
//無名関数のfuction(3){
//return x + 3;
//}が発動。しかも、ローカル変数扱いするaddfiveの5も先代入されているので
//xに5が代入される。

console.log(typeof addFive);
 //functionとなる。

