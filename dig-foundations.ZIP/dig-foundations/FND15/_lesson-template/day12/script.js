'use strict'
// 1行目に記載している 'use strict' は削除しないでください
function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.group("Result:");
    console.log("  actual:", actual);
    console.log("expected:", expected);
    console.groupEnd();
  }
}

 // #1
 function greeting() {
  console.log("Hello!");
}

// #2
let triple = function(x) {
  return 3 * x;
};

// #3
let double = function(x) {
  console.log(2 * x);
};

// #4
const cache = [];

function average(array) {
  let result = 0;
  for (const number of array) {
    result = result + number;
  }
  result = result/array.length;

  cache.push(result);
  return result;
}

// #5
function sayHello(friend) {
  const languages = ["Hello", "Konnichiwa", "Hola", "Nihao"];
  const randomIndex = Math.round(Math.random() * languages.length-1);
  const randomGreeting = languages[randomIndex];
  console.log(randomGreeting + " " + friend + "!");
}




// myName("yan", "Fan");
// function myName(first,last){
//   window.alert(first + " " + last);
// }

// myName("yan", "Fan");
// const myName = function myName(first,last){
//     window.alert(first + " " + last);
//   }

  //Uncaught ReferenceError: Cannot access 'myName' before initialization
  //これが発生してしまう。関数宣言は一番最初にしないといけない。










  // function returnAll(value) {
  //   return value;
  // }


const returnAll = function(value){
  return value;
}

//console.log(returnAll());


   // 例えば、、、
   console.log(typeof returnAll(false)); // boolean

   console.log(typeof returnAll(5)); // number
   console.log(typeof returnAll("5")); // string
   console.log(typeof returnAll([])); // object
   console.log(typeof returnAll({ a: 1 })); // object

   function foo() {
     return "hi";
   }

   console.log(returnAll(foo)); // fuction
   console.log(returnAll(foo())); // string



   /**
    * @param {Function} func
    * @param {any} num - 与えられた関数に渡す引数
    * @returns {any} 与えられた引数を、与えられた関数に渡したときの返り値
    */
   // ここにコードを書きましょう
    function doSomething(func,num){
      return func(num);
    }

   function addTen(number) {
    return number + 10;
  }

  test(doSomething(addTen, 6), 16);
  test(doSomething(addTen, -100), -90);




