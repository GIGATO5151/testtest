'use strict';
// please do not delete the 'use strict' line above

document.getElementById('color-button').addEventListener('click', changeColor)

let count = 0;
function changeColor() {
  console.log('Button clicked!'); // feel free to change/delete this line
  const color = ["red", "blue", "yellow", "pink", "white", "purple", "green"]
  let backcolor = color[Math.floor(Math.random() * color.length)];
  document.body.style.backgroundColor = backcolor;

  let increment = document.getElementById("star")
  count++;
  increment.innerText += "✨"
  if (count >= 10){
    document.getElementById("title").innerText = "10回ボタンを押されましたので"
    increment.innerText = "星は夜空のムコウに旅立ちました・・・(@^^)/~~~"
  }
}
