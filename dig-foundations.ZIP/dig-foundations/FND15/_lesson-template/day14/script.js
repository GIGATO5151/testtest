'use strict'
// 1行目に記載している 'use strict' は削除しないでください
function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.group("Result:");
    console.log("  actual:", actual);
    console.log("expected:", expected);
    console.groupEnd();
  }
}

   /**
    * @param {number} x
    * @returns {(y: number) => number} 引数として y を取り、x を y で割った値を返す関数
    */
    function divide(x){
      return function(y){
        return x / y;
      }
    }

   const divide2 = divide(2);

   test(divide2(4), 0.5);
   test(divide(2)(1), 2);










console["log"]("Hello"); // => Hello
//.logというのがどっかのオブジェクトになっている考え方
//class.name の.nameのような感じ

console.log(typeof console); // =>　object
//consoleはビルトインオブジェクト

const dog = {
  name : "Hana",
  age : 12,
  greet : function(friend){
    return "Bow-wow, " + friend + "!";
  }
}

console.log(dog.name);
console.log(dog.age);
console.log(dog.greet("Yusuke"))








// const body = document.body; //No
// const divElement = document.createElement("div");//Yes
// divElement.className = "heading-container";//No
// divElement.innerText = "Hello World";//No
// const username = window.prompt("What's your name?");//Yes
// localStorage.setItem("username", username);//yes
// document.body.append(divElement);//yes
// window.prompt("Woohoo!");//yes


const myMathObject = {
  sum: function (...num) {
    let result = 0;
    for(let i = 0; i < num.length; i++){
      result += num[i];
    }
    return result;
  },
  product: function () {},
  isEven: function () {},
};




   // これらはテストのサンプルです。下の問題は自分でテストを考えましょう。
   test(myMathObject.sum(1), 1);
   test(myMathObject.sum(1, 2, 3), 6);




//DOM

//.getElementByTagNameは何をしている？
// => 生きた HTMLCollection で指定されたタグ名を持つ要素を返します。

//.innerTextは何をする？
// => 要素のオブジェクトが持つ、テキストコンテンツを調べる。




console.log(document.getElementsByTagName("p"))

