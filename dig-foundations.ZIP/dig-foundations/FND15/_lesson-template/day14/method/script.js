'use strict'
// 1行目に記載している 'use strict' は削除しないでください
function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.group("Result:");
    console.log("  actual:", actual);
    console.log("expected:", expected);
    console.groupEnd();
  }
}

////////////////////////ペア演習/////////////////////////////

// const body = document.body; 
// const divElement = document.createElement("div"); //メソッド
// divElement.className = "heading-container";
// divElement.innerText = "Hello World";
// const username = window.prompt("What's your name?"); //メソッド
// localStorage.setItem("username", username); //メソッド
// document.body.append(divElement); //メソッド
// window.prompt("Woohoo!"); //メソッド

////////////////////////基礎演習//////////////////////////

const myMathObject = {

  sum: function (...num) {
    let sumResult = 0;
    for (let i = 0; i < num.length; i++) {
      sumResult += num[i];
    }
    return sumResult;
  },

  product: function (...num) {
    let sumResult = 0;
    for (let i = 0; i < num.length; i++) {
      if (i === 0) {
        sumResult = num[0];
      }
      else {
        sumResult = sumResult * num[i]
      }
    }
    return sumResult;
  },


  isEven: function (...num) {
    for (let i = 0; i < num.length; i++) {
      if (num[i] / 2 === 0) {
        return true;
      }
      else return false;
    }
  },

  getNumbers: function (...arg) {
    let result = [];
    for (let i = 0; i < arg.length; i++) {
      if (typeof arg[i] === "number") {
        result.push(arg[i]);
      }
    }
    console.log(result);
    return result;
  },

  abs: function (num) {
    if (Math.sign(num) === -1) {
      return num * -1;
    }
    else return num;
  },

  power: function (base, index) {
    if (index === 0) {
      return 1;
    }
    let result = 1;
    if (index > 0) {
      for (let i = 0; i < index; i++) {
        result *= base
      }
    }
    else {
      for (let i = 0; i > index; i--) {
        result /= base;
      }
    }
    return result
  },

  ceil: function (num) {
    if (!Number.isInteger(num)) {
      return num < 0 ? ~~num : ~~num + 1;
       //負の数の場合、
      //~~を使用して整数に変換すると、Math.trunc()と同じように小数点以下を切り捨てます。
      //正の数の場合、~~を使用して整数に変換した後、1を加えることで、Math.trunc()と同じように整数を切り上げます。
    }
    else
      return num;
  },

  floor: function (num) {
    if (!Number.isInteger(num)) {
      return num < 0 ? ~~num : ~~num;
    }
    else
      return num;
  },

  round: function (num) {
    if (!Number.isInteger(num)) {
      const digit = 0;
      //console.log(typeof num.toFixed(digit))
      return parseInt(num.toFixed(digit));//toFixed() メソッドは、数を固定小数点表記を用いて整形します。
    }
    else
      return num;
  },

  primeFactorization: function (num) {
    let result = {}; //結果を格納するオブジェクト

    for (let i = 2; num >= 2; i++) {
      // 割り切れる回数を指定する変数 count を初期化
      let count = 0;
      //2で割り切れる限り割るプログラム⇒次は3で割り切れる限り････････
      for (let dummy; num % i === 0; count++) {
        num /= i;
      }
      // カウントが0以上ならオブジェクトに素因数を追加し、指数を設定する
      if (count > 0) {
        result[i] = count;
      }
    }
    return result;
  }
}




// これらはテストのサンプルです。下の問題は自分でテストを考えましょう。
test(myMathObject.sum(1), 1);
test(myMathObject.sum(1, 2, 3), 6);
test(myMathObject.sum(1, 2, 3, 4), 10);

test(myMathObject.product(1), 1);
test(myMathObject.product(1, 2, 3), 6);
test(myMathObject.product(1, 2, 3, 4), 24);

test(myMathObject.isEven(1), false);
test(myMathObject.isEven(1, 2, 3), false, true, false);
test(myMathObject.isEven(1, 2, 3, 4), false, true, false, true);

test(myMathObject.sum(19283, 18475, 199999), 237757);
test(myMathObject.product(19283, 18475, 199999), 71250328746575);
test(myMathObject.isEven(19), false);


/////////////////////////基礎演習No.3//////////////////////////////

/**
 * @param {...any} ...arg - 任意の数の引数
 * @returns {Array<number>} 引数のうち、数値型のものだけを要素に持つ配列。要素の順番は引数で与えられた順番にする。

 */
test(myMathObject.getNumbers(1, 2, 3, 4), [1, 2, 3, 4]);
test(myMathObject.getNumbers("foo", 3, "4", "hi", 1), [3, 1]);

///////////////////////////中級演習No.1/////////////////////

/**
 * @param {number} num
 * @returns {number} 与えられた数字の絶対値
 */


test(myMathObject.abs(1), 1);
test(myMathObject.abs(-1), 1);
test(myMathObject.abs(435678.745389), 435678.745389);
test(myMathObject.abs(-675843.753489), 675843.753489);
test(myMathObject.abs(0), 0);

///////////////////////////中級演習No.2/////////////////////

/**
 * @param {number} base 底（てい）
 * @param {number} index 指数
 * @returns {number} 与えられた底を与えられた指数で累乗した結果
 */

let actual;
let expected;
function power(base, index) {
  let result;
  for (let i = 1; i <= index; i++) {
    result += base * i
  }
  return result
}



const MIN_BASE = -5;
const MAX_BASE = 5;
const MIN_EXPONENT = -5;
const MAX_EXPONENT = 5;

// 以下のコードでは、一度にたくさんのテストしています。
// （また、浮動小数点数の比較をするためにisNearlyEqualという関数を使っています。）
for (let base = MIN_BASE; base <= MAX_BASE; ++base) {
  for (let exponent = MIN_EXPONENT; exponent <= MAX_EXPONENT; ++exponent) {
    const actual = myMathObject.power(base, exponent);
    const expected = Math.pow(base, exponent);
    if (isNearlyEqual(actual, expected)) {
      console.log("Yay! Test PASSED.");
    } else {
      console.error("Test FAILED. Keep trying!");
      console.log("    actual: ", actual);
      console.log("  expected: ", expected);
      console.trace();
    }
  }
}

// 参照文献： https://floating-point-gui.de/errors/comparison/

function isNearlyEqual(a, b) {
  const absA = Math.abs(a);
  const absB = Math.abs(b);
  const diff = Math.abs(a - b);

  if (a == b) {
    return true;
  } else if (a == 0 || b == 0 || absA + absB < Number.MIN_VALUE) {
    return diff < Number.EPSILON * Number.MIN_VALUE;
  } else {
    return diff / Math.min(absA + absB, Number.MAX_VALUE) < Number.EPSILON;
  }
}


///////////////////////応用演習No.1///////////////////////////

/**
    * @param {number} ???
    * @returns {number} 与えられた数字を切り上げた整数
    */
test(myMathObject.ceil(1.1), 2);
test(myMathObject.ceil(2.2), 3);
test(myMathObject.ceil(3.3), 4);
test(myMathObject.ceil(4.4), 5);
test(myMathObject.ceil(5.5), 6);
test(myMathObject.ceil(5.0), 5);


////////////////////////応用演習No.2//////////////////////////

/**
 * @param {number} num
 * @returns {number} 与えられた数字を切り下げた整数
 */
test(myMathObject.floor(1.1), 1);
test(myMathObject.floor(2.2), 2);
test(myMathObject.floor(3.3), 3);
test(myMathObject.floor(4.4), 4);
test(myMathObject.floor(5.5), 5);
test(myMathObject.floor(5), 5);


////////////////////////応用演習No.3//////////////////////////

/**
 * @param {number} num
 * @returns {number} 与えられた数字を四捨五入した整数
 */
test(myMathObject.round(1.1), 1);
test(myMathObject.round(2.2), 2);
test(myMathObject.round(3.3), 3);
test(myMathObject.round(4.4), 4);
test(myMathObject.round(5.5), 6);
test(myMathObject.round(6.6), 7);
test(myMathObject.round(7.7), 8);
test(myMathObject.round(7), 7);

////////////////////応用演習No.4///////////////////////////

/**
* @param {number} num
* @returns {{ [primeFactor: number]: number }} 引数の数値を素因数分解し、キーを _素因数_ 、値を対応する _指数_ にしたオブジェクト
*/
test(myMathObject.primeFactorization(2), { 2: 1 });
test(myMathObject.primeFactorization(3), { 3: 1 });
test(myMathObject.primeFactorization(4), { 2: 2 });
test(myMathObject.primeFactorization(5), { 5: 1 });
test(myMathObject.primeFactorization(6), { 2: 1, 3: 1 });
test(myMathObject.primeFactorization(200560490130), {
  2: 1,
  3: 1,
  5: 1,
  7: 1,
  11: 1,
  13: 1,
  17: 1,
  19: 1,
  23: 1,
  29: 1,
  31: 1,
});
test(myMathObject.primeFactorization(900719925474099), {
  3: 1,
  53: 1,
  157: 1,
  1613: 1,
  2731: 1,
  8191: 1,
});