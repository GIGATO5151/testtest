'use strict'
// 1行目に記載している 'use strict' は削除しないでください

console.log(document.getElementsByTagName("p"))

console.log(document.getElementById("main-header"))

let result;
result = document.getElementsByClassName("inner-paragraph");

for(let i = 0; i < result.length; i++){
  console.log(result[i]);
}


////////////////////////////////////////////////////

 const innerParagraphs = document.querySelectorAll('.inner-paragraph');
 console.log(innerParagraphs);

 let text = [];

 for(let i = 0; i <innerParagraphs.length; i++){
 const firstParagraph = innerParagraphs[i];
 text[i] = firstParagraph.textContent;
 console.log(text); // Inner Paragraph A
 }

 console.log(document.querySelectorAll('div'));

//  function toUpperCase() {
//   for(let i = 0; i < innerParagraphs.length; i++){
//   const str = document.querySelector(innerParagraphs[i]);
//   str.textContent = str.textContent.toUpperCase();
//   }
// }
// console.log(innerParagraphs[0]);
// const word = []
// word.push(innerParagraphs);
// console.log(word);

// const any = [word[0].tostring()];

const any = ["h1","p","div.outer","body"];

function toUpperCase() {
  for(let i = 0; i < any.length; i++){
  const str = document.querySelector(any[i]);
  str.textContent = str.textContent.toUpperCase();
  }
}

//関数を呼び出す
toUpperCase();
