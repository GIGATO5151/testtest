'use strict'
// 1行目に記載している 'use strict' は削除しないでください


let actual;
let expected;

//////////////////////No.1//////////////////////////

/**
  * @param {string} name 名前の文字列
  * @returns {string} 挨拶分を返す文字列
  */

function greeting(name) {
  if (typeof name === "string") {
    return `Hello, ${name}!`;
  }
  else {
    return "Not input string"
  }
}

actual = greeting("Kana");
expected = "Hello, Kana!";

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = greeting("Kimiko");
expected = "Hello, Kimiko!";

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = greeting(true);
expected = "Not input string";

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

//////////////////////No.2//////////////////////////

/**
   * @param {number} num1 1つめの引数
   * @param {number} num2 2つめの引数
   * @returns {number} 2つの引数の平均を返す
   */

function average(num1, num2) {
  if (typeof num1 === "number" && typeof num2 === "number") {
    return (num1 + num2) / 2;
  }
  else {
    return "Not input number";
  }
}

actual = average(2, 2);
expected = 2;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = average(50, 30);
expected = 40;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = average(30, "a")
expected = "Not input number";

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

///////////////////////////No.3//////////////////////////////////

/**
  * @param {"Spring"|"Summer"|"Fall"|"Winter"} season - 現在の季節
  * @param {"warm"|"hot"|"cool"|"cold"} temp - 現在の気温
  * @returns {"The temperature is normal for the season."|"The temperature is unusual for the season."} 季節や気温に応じて変わる、気候に関する説明
  */
function describeTheWeather(season, temp) {
  if (season === "Spring" && temp === "warm") {
    return "The temperature is normal for the season.";
  }

  else if (season === "Summer" && temp === "hot") {
    return "The temperature is normal for the season.";
  }

  else if (season === "Fall" && temp === "cool") {
    return "The temperature is normal for the season.";
  }

  else if (season === "Winter" && temp === "cold") {
    return "The temperature is normal for the season.";
  }

  else return "The temperature is unusual for the season."
}

actual = describeTheWeather("Spring", "warm");
expected = "The temperature is normal for the season.";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = describeTheWeather("Spring", "cold");
expected = "The temperature is unusual for the season.";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = describeTheWeather("Summer", "hot");
expected = "The temperature is normal for the season.";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = describeTheWeather("Fall", "cool");
expected = "The temperature is normal for the season.";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = describeTheWeather("Winter", "cold");
expected = "The temperature is normal for the season.";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = describeTheWeather("Winter", "Hot");
expected = "The temperature is unusual for the season.";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

  // さらにテストを書いて、コードが正しいことを確認してください