'use strict'
// 1行目に記載している 'use strict' は削除しないでください

console.log("Hello world!");

function isHot(temperature) {
  if (temperature > 30) {
    return "It's hot!";
  } else {
    return "It's not hot.";
  }
}

console.log(isHot(31)); // "It's hot!" を表示
console.log(isHot(2)); // "It's not hot." を表示
console.log(isHot(30)); // "It's not hot." を表示

function getTypeOfSchool(age) {
  if (age < 6) {
    return "kindergarten";
  }

  else if (age < 11) {
    return "elementary school";
  }

  else if (age < 15) {
    return "junior high school";
  }

  else if (age <= 18) {
    return "high school";
  }

  else {
    return "after high school";
  }
}

console.log(getTypeOfSchool(3)); // "kindergarten" を表示
console.log(getTypeOfSchool(8)); // "elementary school" を表示
console.log(getTypeOfSchool(13)); // "junior high school" を表示
console.log(getTypeOfSchool(16)); // "high school" を表示
console.log(getTypeOfSchool(30)); // "after high school" を表示






// ファイル全体で使用する TDD 用の変数を宣言する
let expected; //比較する
let actual; //実際の

// // テストする対象のコード
// function add(a, b) {
//     return a + a;
// }

// expected = 3; // EXPRESSION（式）の期待値
// actual = add(1, 2); // テストを行う EXPRESSION（式）

// if (actual === expected) {
//     console.log("Test PASSED!");
// } else {
//     console.error("Test FAILED. Keep trying!");
//     console.group("Result:");
//     console.log("  actual:", actual);
//     console.log("expected:", expected);
//     console.groupEnd();
//}


/**
  * @param {string} firstName - 下の名前
  * @param {string} lastName - 苗字
  * @returns {string} 名前と苗字を連結し、間にスペースを入れたもの
  */
function getFullName(firstName, lastName) {
  return firstName + " " + lastName;
}

actual = getFullName("Ken", "Watanabe");
expected = "Ken Watanabe";

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

/**
 * @param {string} name - 人の名前
 * @param {boolean} isFormal - 敬称をつけるべきかどうか（敬称ありならtrue、なしならfalse）
 * @returns {string} 与えられた人の名前と敬称が入った挨拶文
 */
function simpleGreeting(name, isFormal) {
  // ここにコードを書きましょう
  if (isFormal === true) {
    return "Hello, " + name + "-san.";
  } else {
    return "Hello, " + name + ".";
  }
}

actual = simpleGreeting("Amy", true);
expected = "Hello, Amy-san.";

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = simpleGreeting("Matt", false);
expected = "Hello, Matt.";

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}


/**
  * @param {number} ??? - 1 番目の数字
  * @param {number} ??? - 2 番目の数字
  * @returns {boolean} 与えられた 1 番目の数字が 2 番目の数より大きいかどうか
  */
// 関数を宣言しましょう
function isGreaterThan(number1, number2) {
  if (number1 > number2) {
    return true;
  }
  return false;
}

actual = isGreaterThan(5, 4);
expected = true;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = isGreaterThan(3, 4);
expected = false;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}


/**
   * @param {"+"|"-"|"*"|"/"|"**"|"%"} ??? - 使用する算術演算子を表す文字列
   * @param {number} ??? - 1 番目の被演算子
   * @param {number} ??? - 2 番目の被演算子
   * @returns {number} 与えられた演算子を被演算子と組み合わせて実行した結果
   */
// 関数を定義しましょう
function operate(ope, num1, num2) {
  if (ope === '+') {
    return num1 + num2;
  }
  else if (ope === '-') {
    return num1 - num2;
  }
  else if (ope === '*') {
    return num1 * num2;
  }
  else if (ope === '/') {
    return num1 / num2;
  }
  else if (ope === '**') {
    return num1 ** num2;
  }
  else if (ope === '%') {
    return num1 % num2;
  }

}

actual = operate("+", 1, 2);
expected = 3;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = operate("-", 100, 33);
expected = 67;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = operate("*", 2, 2);
expected = 4;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = operate("/", 2, 2);
expected = 1;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = operate("**", 2, 3);
expected = 8;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = operate("%", 2, 2);
expected = 0;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// *, /, **, % を使ってもっとテストを書いてみましょう

/**
* @param {string} color - チェックしたい色の名前
* @returns {boolean} 与えられた色が虹色に含まれているかどうか
*/
// 関数を定義しましょう
function isRainbowColor(color) {
  let str = color.toUpperCase();
  console.log(str);
  if (str === "RED") {
    return true;
  }
  else if (str === "ORRANGE") {
    return true;
  }
  else if (str === "YELLOW") {
    return true;
  }
  else if (str === "GREEN") {
    return true;
  }
  else if (str === "BLUE") {
    return true;
  }
  else if (str === "INDIGO") {
    return true;
  }
  else if (str === "VIOLET") {
    return true;
  }
  else return false;
}

actual = isRainbowColor("red");
expected = true;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = isRainbowColor("rEd");
expected = true;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = isRainbowColor("Brown");
expected = false;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = isRainbowColor("blue");
expected = true;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// 他の虹色をチェックするテストを書きましょう

/**
 * @param {any} type - チェックする値
 * @returns {string}  与えられた引数のデータ型を表すわかりやすいメッセージ
 */
// 関数を定義しましょう

function typeOfFriendly(type) {
  let check = typeof type;
  console.log(check);
  if (check === "string") {
    return "与えられた引数は " + check + " (文字列) です。";
  }
  else if (check === "number") {
    return "与えられた引数は " + check + " (数値) です。";
  }
  else if (check === "boolean") {
    return "与えられた引数は " + check + " (真偽値) です。";
  }
}

actual = typeOfFriendly("Hello");
expected = "与えられた引数は string (文字列) です。";

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = typeOfFriendly(5);
expected = "与えられた引数は number (数値) です。";

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = typeOfFriendly(true);
expected = "与えられた引数は boolean (真偽値) です。";

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// 他の型をチェックするテストも書きましょう

/**
  * @param {"=="|"==="|"<"|"<="|">"|">="} ope - 使用したい比較演算子
  * @param {number} num1 - 1 番目の被演算子
  * @param {number} num2 - 2 番目の被演算子
  * @returns {number} 与えられた演算子を被演算子と組み合わせて比較した結果
  */
// 関数を定義しましょう
function compare(ope, num1, num2) {
  if (ope === "===") {
    return num1 === num2;
  }
  else if (ope === "==") {
    return num1 == num2;
  }
  else if (ope === "<") {
    return num1 < num2;
  }
  else if (ope === "<=") {
    return num1 <= num2;
  }
  else if (ope === ">") {
    return num1 > num2;
  }
  else if (ope === ">=") {
    return num1 >= num2;
  }
  else
    return false;

}

actual = compare("===", 1, 1);
expected = true;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = compare("===", 1, "1");
expected = false;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = compare("==", 1, "1");
expected = true;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = compare(">=", 2, 5);
expected = false;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// 他の演算子を使ったテストも書いてみましょう。

/**
* @param {number} num1 - 1 番目の数値
* @param {number} num2 - 2 番目の数値 (任意)
* @param {number} num3 - 3 番目の数値 (任意)
* @returns {string} 与えられた数字を 1 つの文字列に結合したもの
*/
// ここにコードを書きましょう

function concatenateNumbers(num1, num2, num3) {
  if (typeof num1 !== "undefined" && typeof num2 !== "undefined" && typeof num3 !== "undefined") {
    return `${num1}${num2}${num3}`;
  }
  else if (typeof num1 !== "undfined" && typeof num2 !== "undefined" && typeof num3 === "undefined") {
    return `${num1}${num2}`;
  }
  else {
    return `${num1}`;
  }
}

actual = concatenateNumbers(7);
expected = "7";

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = concatenateNumbers(7, 9);
expected = "79";

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = concatenateNumbers(7, 9, 4);
expected = "794";

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}


// 必要に応じてテストを書きましょう。


/**
    * @param {number} ini - 初めの数量
    * @param {number} halftime - 半減期（数量が半分になるまでの時間）
    * @param {number} time - 経過時間
    * @returns {number} 与えられた時間が経過したあとに残っている数量
    */
// ここにコードを書きましょう

function halfLife(ini, halftime, time) {
  return ini * 0.5 ** (time / halftime);
}

actual = halfLife(1, 1, 1);
expected = 1 / 2;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = halfLife(8, 4, 2);
expected = 4 * Math.SQRT2;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = halfLife(2, 2, 4);
expected = 1 / 2;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// 必要に応じてテストを書きましょう。

/**
 * @param {string} str - 文字列
 * @returns {string} 与えられた文字列の小文字と大文字を逆にした文字列。アルファベット以外は変更しない。
 */
// ここにコードを書きましょう

function invertCase(str) {
  let result = "";

  for (let i = 0; i < str.length; i++) {

    let aaa = str.charAt(i); //charAtは()で示された文字を取り出すメソッド

    if (aaa === aaa.toUpperCase()) {
      //console.log(aaa);
      result += aaa.toLowerCase();
    }
    else if (aaa === aaa.toLowerCase()) {
      //console.log(aaa);
      result += aaa.toUpperCase();
    }
    else if (aaa === " ") {
      result += aaa;
    }
  }
  return result;
}


actual = invertCase("I hope you are having a nice day");
expected = "i HOPE YOU ARE HAVING A NICE DAY";

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = invertCase("My daughter is 5 years old");
expected = "mY DAUGHTER IS 5 YEARS OLD";

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = invertCase("123456789");
expected = "123456789";

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// 必要に応じてテストを書きましょう。


//////////////////////コードスタイル////////////////////////////////

// ファイル全体で使用するtdd変数を宣言します



//////////////////////////-No.1-/////////////////////////////

/**
* @param {number} num1 - 1つ目の数値型
* @param {number} num2 - 2つ目の数値型
* @returns {number} 1つ目の数字と2つ目の数字を足して2で割る
*/

function Ave(x, y) {
  const n = 2;
  return (x + y) / n;
}

expected = 1; // 期待するテスト結果
actual = Ave(1, 1); // テストする式

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

expected = 1.5; // 期待するテスト結果
actual = Ave(1, 2); // テストする式

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

expected = 2.5;
actual = Ave(2, 3);

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

expected = 3;
actual = Ave(2, 4);

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}


//////////////////////////-No.2-/////////////////////////////

/**
    * @param {number} num1 - 1つ目の数値型
    * @returns {number} 正の数値だったらtrue（0はfalse)
*/

function ispositive(num1) {
  if (num1 < 0) {
    return false;
  }
  else if (num1 > 0) {
    return true;
  }
  else if (num1 === 0) {
    return false;
  }
}

expected = true; // 期待するテスト結果
actual = ispositive(1); // テストする式

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

expected = false; // 期待するテスト結果
actual = ispositive(-4); // テストする式

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// さらにテストを書きましょう。

//////////////////////////-No.3-/////////////////////////////

function getTriangleArea(base, height) {
  //const rectangleArea = base * height;
  return base * height / 2;
}

expected = 7.5; // 期待するテスト結果
actual = getTriangleArea(3, 5); // テストする式

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// さらにテストを書きましょう。


//////////////////////////-No.4-/////////////////////////////


function is7Multiple(num) {
  //const % 7 === 0;
  return (num % 7 === 0) === true;
}

expected = true; // 期待するテスト結果
actual = is7Multiple(14); // テストする式

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

expected = false; // 期待するテスト結果
actual = is7Multiple(72); // テストする式
if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}
  // さらにテストを書きましょう。



//////////////////////////-No.5-/////////////////////////////

/**
    * @param {number} num1 - 1つ目の数値型
    * @returns {number} 全ての数の絶対値を返す
*/
function ABSOLUTE(num1) {
  const zero = 0;
  if (num1 < zero) {
    return zero - num1;
  }
  return num1;
}


expected = 5; // 期待するテスト結果
actual = ABSOLUTE(-5); // テストする式
if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

expected = 5; // 期待するテスト結果
actual = ABSOLUTE(5); // テストする式
if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}
// さらにテストを書きましょう


//////////////////////////-中級演習No.1-/////////////////////////////


/**
    * @param {number} num1 - 比較される数値
    * @param {number} Low - 下限値
    * @param {number} Up - 上限値
    * @returns {number} 下限値と上限値の間だったらtrueを返す
*/

function Range(num1, Low, Up) {
  if (num1 >= Low && num1 <= Up) {
      return true;
    } else {
      return false;
    }
}

expected = true; // 期待するテスト結果
actual = Range(5,1,7); // テストする式
if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

expected = false; // 期待するテスト結果
actual = Range(3,4,7); // テストする式
if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// さらにテストを書きましょう。




//////////////////////////-中級演習No.2-/////////////////////////////
/**
    * @param {number} num1 - 1つ目の数値型
    * @param {number} num2 - 2つ目の数値型
    * @returns {number} 1つ目の数値型と2つ目の数値型の余りをだす。％使わないやり方
*/

function EXCESS(num1, num2) {
  //const thing = op2 * Math.floor(op1/op2);
  //return op1 - thing;
  return num1 -num2 * Math.floor(num1/num2);//Math.floorは（）内を整数値で返す（小数点消す）
}


expected = 1; // 期待するテスト結果
actual = EXCESS(5,2); // テストする式
if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

expected = 2; // 期待するテスト結果
actual = EXCESS(10,8); // テストする式
if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}
// さらにテストを書きましょう。


//////////////////////////-中級演習No.3-/////////////////////////////

/**
    * @param {number} num1 - 1つ目の数値型
    * @param {number} num2 - 2つ目の数値型
    * @returns {number} 排他的論理和,どちらかが1なら1。
*/
function XOR(num1, num2) {
  let isor = num1 || num2;
  let isand = num1 && num2;
  let isxor = isor && !isand; //
  return isxor;
}


expected = true; // 期待するテスト結果
actual = XOR(1,0); // テストする式
if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

expected = false; // 期待するテスト結果
actual = XOR(1,1); // テストする式
if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// さらにテストを書きましょう。


//////////////////////////-中級演習No.4-/////////////////////////////

/**
    * @param {number} num1 - 1つ目の数値型
    * @param {number} num2 - 2つ目の数値型
    * @param {number} num3 - 3つ目の数値型
    * @param {number} num3 - 4つ目の数値型
    * @returns {number} 排他的論理和,どちらかが1なら1。
*/

function thanNumber(num1, num2, num3, num4) {
  if (num1 < num2 && num2 < num3 && num3 < num4 ) {
    return true;
  }
  else{
    return false
  }
}

expected = false; // 期待するテスト結果
actual = thanNumber(1,5,9,4); // テストする式
if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// さらにテストを書きましょう。


//////////////////////////-応用演習No.5-/////////////////////////////
/**
    * @param {number} x1 - x1の座標
    * @param {number} y1 - y1の座標
    * @param {number} x2 - x2の座標
    * @param {number} y2 - y2の座標
    * @returns {number} 正方形の斜辺の長さを求める
*/

function Pitagoras(x1, y1, x2, y2) {
  if((x2-x1) === (y2-y1)){ 
  const XofCordToDiff = x2-x1; //X座標の差分
  let XofCordToSquare = Math.pow(XofCordToDiff,2);//x座標の差分を2乗
  const YofCordToDiff = y2-y1; //y座標の差分
  let YofCordToSquare = Math.pow(YofCordToDiff,2);//y座標の差分を2乗
  let XtoYCordSquareSum = XofCordToSquare + YofCordToSquare;//x座標の差分を2乗したものとy座標の差分を2乗したものを足す
  const XtoYCordSquareSumSquart2 = XtoYCordSquareSum ** 0.5; //その合計値を1/2乗したもの
  return XtoYCordSquareSumSquart2;
  }
  else return false
}

expected = 1.4142135623730951; // 期待するテスト結果
actual = Pitagoras(2,2,1,1); // テストする式
if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

expected = false; // 期待するテスト結果
actual = Pitagoras(5,6,8,8); // テストする式
if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}
// さらにテストを書きましょう。
