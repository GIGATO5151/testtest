'use strict'
// 1行目に記載している 'use strict' は削除しないでください

   /**
    * @param {Array<string>} ???
    * @returns {Array<string>} 与えられた配列の中にある、大文字で始まり、疑問符で終わる文字列のみを要素として持つ配列
    */
   // ここにコードを書きましょう

   const arrayOfStrings3 = [
    "Hi, there.",
    "What in the world?",
    "My name is JavaScript",
    "Do you want to know a secret?",
  ];

  function getQuestions(array){
    return array.filter(str => str[0] === str[0].toUpperCase())
                .filter(str => str[str.length - 1] === "?");
  }


  test(getQuestions(arrayOfStrings3), [
    "What in the world?",
    "Do you want to know a secret?",
  ]);
  test(getQuestions(arrayOfStrings3.slice(2)), [
    "Do you want to know a secret?",
  ]);


     /**
    * @param {Array<string>} array
    * @returns {Array<string>} 与えられた配列の中にある、長さが奇数で、文字がすべて大文字の文字列のみを要素として持つ配列
    */
   // ここにコードを書きましょう

    function getOddLengthCapitalWords(array){
      return array.filter(str => str.length % 2 !== 0)
                  .filter(str => str === str.toUpperCase())
    }


   const arrayOfStrings4 = ["SNAKE", "APPLES", "Peaches", "PUMPKINPIES"];

   test(getOddLengthCapitalWords(arrayOfStrings4), ["SNAKE", "PUMPKINPIES"]);
   test(getOddLengthCapitalWords(arrayOfStrings4.slice(1)), ["PUMPKINPIES"]);


      /**
    * @param {Array<any>} num1
    * @param {Array<any>} num2
    * @returns {Array<any>} 与えられた配列の両方に存在する要素だけが入った配列
    */
   // ここにコードを書きましょう
    function intersection(num1,num2){
      return num1.filter(x1 => num2.includes(x1))
    }


   test(intersection([1, 2, 3], [1, 2, 3]), [1, 2, 3]);
   test(intersection([1, 2, 3], [2, 3, 4]), [2, 3]);
   test(intersection([1, 2, 3], [3, 4, 5]), [3]);
   test(intersection([1, 2, 3], [4, 5, 6]), []);


      /**
    * @param {number} x
    * @returns {(y: number) => number} 引数 y をとり、y に x を足した値を返す関数
    */
   // コードを書き始めましょう
   function add(x) {
    function aaa(y){
     return  x+y
    }
    return aaa
  }

  const addFive = add(5);
  test(addFive(1), 6);


     /**
    * @param {number} x
    * @returns {(y: number) => number} 引数として y をとり、x に y を掛け合わせた値を返す関数
    */
   // ここにコードを書きましょう

  function product(x){
    return function(y){
      return x * y;
    }
  }


   const product3 = product(3);

   test(product3(4), 12);
   test(product(4)(5), 20);


  