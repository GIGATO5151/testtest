'use strict'
// 1行目に記載している 'use strict' は削除しないでください

console.log("Hello World!");

let actual;
let expected;

///////////////////////////基本演習No.1/////////////////////

/**
   * @param {Array<number>} sum - 数値型の要素を持つ配列

   * @returns {number} 与えられた配列のすべての数字の合計
   */
function sumArray(sum) {
  let result = 0;

  for (const count of sum) {
    result += count;
  }
  return result;
}


actual = sumArray([1, 2, 3, 5]);
expected = 11;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// さらにテストを書きましょう。



//////////////////////////基本演習No.2////////////////////////////

/**
   * @param {Array<number>} prd - 数値型の要素を持つ配列

   * @returns {number} 与えられた配列のすべての数字をかけあわせた答え
   */
function productArray(prd) {
  let result = 1;

  for (const count of prd) {
    result = result * count;
  }
  return result;
}

actual = productArray([1, 2, 3, 4]);
expected = 24;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// さらにテストを書きましょう。

///////////////////////基礎演習No.3//////////////


/**
    * @param {Array<any>} sort
    * @returns {boolean} 与えられた配列に "fun" という文字列が入っているかどうかを表すブーリアン
    */
function hasFun(sort) {
  let result;

  for (const count of sort) {
    result = count;
    console.log(result);
    if (result === "fun") {
      return true;
    }
  }
  return false;
}

actual = hasFun(["whatever", 2, false, "fun", "hello"]);
expected = true;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = hasFun(["whatever", 2, false, "run", "hello"]);
expected = false;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// さらにテストを書きましょう。

///////////////////////基礎演習No.4//////////////

/**
    * @param {Array<any>} any
    * @returns {boolean} 与えられた配列の要素がすべてブーリアンかどうかを表すブーリアン
    */
function containsOnlyBooleans(any) {
  let result;

  for (const count of any) {
    if (typeof count !== "boolean") {
      //result = count;
      //console.log(result)
      return false;
    }
  }
  //console.log(result);
  return true;
}

actual = containsOnlyBooleans([true, false, true, false, false]);
expected = true;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = containsOnlyBooleans([true, true, true, "not a boolean"]);
expected = false;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// さらにテストを書きましょう。

///////////////////////////////基礎演習No.5//////////////////////////////////////

/**
 * @param {Array<any>} any1 - 1番目の配列
 * @param {Array<any>} any2 - 2番目の配列
 * @returns {Array<any>} 与えられた2つの配列を連結させた配列
 */

function concatenate(any1, any2) {
  let result = [];  //let result はfuctionの中で定義しないと、二度目回した時に繋がってしまう
  for (let count of any1) {
    result.push(count);
  }
  for (let count of any2) {
    result.push(count);
  }
  return result;
}


actual = concatenate(["eeny", "meeny"], ["miny", "moe"]);
expected = ["eeny", "meeny", "miny", "moe"];

// 現時点では、配列を比較するには JSON.stringify を使う必要があると覚えておいてください。
if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// さらにテストを書きましょう。

actual = concatenate(["eeny", "meeny"], ["miny", "moe", "mint"]);
expected = ["eeny", "meeny", "miny", "moe", "mint"];

// 現時点では、配列を比較するには JSON.stringify を使う必要があると覚えておいてください。
if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}


///////////////////////////////基礎演習No.6//////////////////////////////////////

/**
* @param {Array<number>} numArray - 数値型の要素を持つ配列

* @returns {Array<number>} 与えられた配列の中の偶数だけを入れた配列
*/
function getEvenNumbers(numArray) {
  let result = [];

  for (const count of numArray) {
    if (count % 2 !== 0) {
      result.push(count);
      //console.log(count);
    }
  }
  return (result);
}

actual = getEvenNumbers([0, 1, 2, 3, 4, 5, 6, 7, 8]);
expected = [1, 3, 5, 7];

// 現時点では、配列を比較するには JSON.stringify を使う必要があると覚えておいてください。
if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// さらにテストを書きましょう。

///////////////////////////////基礎演習No.7//////////////////////////////////////

/**
* @param {Array<number>} numArray - 数値型の要素を持つ配列

* @param {number} multi - 配列の中の数字にかける数字
* @returns {Array<number>} 配列の中の数字に第2引数をかけた結果が入った新しい配列
*/
function getMultipliedArray(numArray, multi) {
  let result = [];

  for (const count of numArray) {
    result.push(count * multi)
  }
  return result;
}

actual = getMultipliedArray([1, 2, 3], 6);
expected = [6, 12, 18];

// 現時点では、配列を比較するには JSON.stringify を使う必要があると覚えておいてください。
if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = getMultipliedArray([5, 10, 15], 5);
expected = [25, 50, 75];

// 現時点では、配列を比較するには JSON.stringify を使う必要があると覚えておいてください。
if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// さらにテストを書きましょう。


/////////////////////////////////中級演習No.1/////////////////////////////////

/**
 * @param {Array<number>} numArray - 数値型の要素を持つ配列

 * @returns {boolean} 与えられた配列が昇順になっているかを表すブーリアン
 */
function isSorted(numArray) {
  let result = numArray[0];

  for (const count of numArray) {
    if (count < result) {
      return false;
    }
    result = count;
  }
  return true;
}

//1回目　count:1 result:1
//2回目　count:2 result:1
//3回目　count:3 result:2
//昇順じゃなければ count < resultが成り立ちfalse→昇順じゃない
//そうじゃなければ、count < result が成り立たないので、true →昇順

actual = isSorted([1, 2, 3]);
expected = true;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = isSorted([3, 2, 3]);
expected = false;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = isSorted([2, 3, 4, 5, 6, 7]);
expected = true;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}
// さらにテストを書きましょう。


/////////////////////////////////中級演習No.2/////////////////////////////////
/**
 * @param {Array<any>} array - 配列
 * @param {string|number|boolean} data - 出現回数をカウントしたい値（値のデータ型は `string`、`number`、`boolean` のいずれかとする。）
 * @returns {number} その値が配列内で出てきた回数
 */
function countOccurrences(array, data) {
  let sum = 0;
  if ((typeof data === "string") || (typeof data === "number") || (typeof data === "boolean")) {
    for (const count of array) {
      if (count === data) {
        sum++;
      }
    }
    return sum;
  }
  else return "No"
}

actual = countOccurrences([1, 2, 3], 2);
expected = 1;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = countOccurrences([1, 2, 2], 2);
expected = 2;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = countOccurrences([1, 2, "elephant"], "elephant");
expected = 1;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = countOccurrences([true, true, true], true);
expected = 3;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = countOccurrences([true, true, undefined], undefined);
expected = "No";

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}


// さらにテストを書きましょう。

/////////////////////////////////中級演習No.3/////////////////////////////////

/**
 * @param {Array<any>} array
 * @returns {Array<any>} 与えられた配列の要素が逆の順番に入っている配列
 */
function reverse(array) {
  let result = [];

  for (const count of array) { //配列の長さ分ループを回して、空の配列にarrayの先頭から代入していく
    result.unshift(count);
  }
  return result;
}

const arrayToReverse = ["eeny", "meeny", "miny", "moe"];

actual = reverse(arrayToReverse);
expected = ["moe", "miny", "meeny", "eeny"];

// 現時点では、配列を比較するには JSON.stringify を使う必要があると覚えておいてください。
if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// 元の配列が変更されていないことを確認してください。
// 現時点では、配列を比較するには JSON.stringify を使う必要があると覚えておいてください。

actual = arrayToReverse;
expected = ["eeny", "meeny", "miny", "moe"];

if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// さらにテストを書きましょう。

/////////////////////////////////中級演習No.4/////////////////////////////////

/**
* @param {Array<number>} numArray
* @param {"+"|"-"|"*"|"/"|"**"|"%"} wantOpe - 使用したい算術演算子を表す文字列
* @param {number} num - 使用したい被演算子
* @returns {Array<any>} 与えられた配列の各要素に、引数の算術演算子と被演算子を適用した結果が入った新たな配列
*/



function getOperatedArray(numArray, wantOpe, num) {
  let result = [];

  if (wantOpe === "+") {
    for (const count of numArray) {
      result.push(count + num);
    }
    return result;
  }

  else if (wantOpe === "-") {
    for (const count of numArray) {
      result.push(count - num);
    }
    return result;
  }

  else if (wantOpe === "*") {
    for (const count of numArray) {
      result.push(count * num);
    }
    return result;
  }
  else if (wantOpe === "/") {
    for (const count of numArray) {
      result.push(count / num);
    }
    return result;
  }
  else if (wantOpe === "**") {
    for (const count of numArray) {
      result.push(count ** num);
    }
    return result;
  }
  else if (wantOpe === "%") {
    for (const count of numArray) {
      result.push(count % num);
    }
    return result;
  }
}

actual = getOperatedArray([1, 2, 3], "+", 5);
expected = [6, 7, 8];

// 現時点では、配列を比較するには JSON.stringify を使う必要があると覚えておいてください。
if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = getOperatedArray([9, 6, 3], "/", 3);
expected = [3, 2, 1];

// 現時点では、配列を比較するには JSON.stringify を使う必要があると覚えておいてください。
if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = getOperatedArray([9, 6, 3], "**", 2);
expected = [81, 36, 9];

// 現時点では、配列を比較するには JSON.stringify を使う必要があると覚えておいてください。
if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

// さらにテストを書きましょう。


////////////////////////////応用演習No.1///////////////////////////

/**
* @param {Array<string>} painArray - 「痛む場所」が入った配列
* @returns {string} お医者さんに診てもらうときに言うセリフ
*/
function callADoctor(painArray) {
  let result = [];
  if (painArray.length > 1) {
    let lastparts = [] = painArray;
    let otherparts = [] = painArray;
    lastparts = lastparts.pop();
    //console.log(lastparts);
    otherparts = otherparts.slice(0, otherparts.length)
    otherparts = otherparts.map(item => " " + item);
    otherparts = otherparts.toString();
    //console.log(otherparts)
    return `Doctor, doctor! My${otherparts}, and ${lastparts} hurt!`
  }
  for (const count of painArray) {
    result = (painArray.slice(0, 1));
    result = result.toString();
    //console.log(result);
    //console.log(result.slice(-1));
    if (result.slice(-1) === "s") {
      console.log("true:" + result.slice(-1));
      return `Doctor, doctor! My ${result} hurt!`
    }
    else
      console.log("falese:" + result.slice(-1));
    return `Doctor, doctor! My ${result} hurts!`
  }
  return true;
}
actual = callADoctor(["head"]);
expected = "Doctor, doctor! My head hurts!";

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = callADoctor(["shoulders"]);
expected = "Doctor, doctor! My shoulders hurt!";

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = callADoctor(["head", "shoulders", "knees", "toes"]);
expected = "Doctor, doctor! My head, shoulders, knees, and toes hurt!";

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = callADoctor(["head", "shoulders", "knees", "toes", "nose"]);
expected = "Doctor, doctor! My head, shoulders, knees, toes, and nose hurt!";

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}


// さらにテストを書きましょう。


/**
* @param {Array<any>} ary
* @returns {number} 与えられた配列の「要素」の数。このとき、入れ子になった配列がある場合は、配列内の各要素も一つ一つカウントすること。
*/
function deepCount(ary) {
  return ary.reduce(function (sum, cur) { //sum:累積保持　cur:現在要素
    if (Array.isArray(cur)) { //curの中身が配列だったら
      return sum + deepCount(cur); //sumで累積値を保持→配列の中身を全て走査して、足し算していく。
    } else {
      return sum + 1
    }
  }, 0);
}


actual = deepCount([1]);
expected = 1;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = deepCount([1, 3]);
expected = 2;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = deepCount([1, 3, [2, 4]]);
expected = 4;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

actual = deepCount(["a", "b", ["c", ["d", "e", ["f"]]]]);
expected = 6;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

    // さらにテストを書きましょう。