'use strict'
// 1行目に記載している 'use strict' は削除しないでください

console.log("Hello World!");

//////////////////////ウォームアップ////////////////


const colors = ["red", "green", "blue"];

console.log(colors);

let i = 0
for (const color of colors) {
  i = i + 1;
  console.log(i);
  console.log(color);
}

function getDoubleArray(arrayOfNumbers) {
  const result = [];

  for (const number of arrayOfNumbers) {
    result.push(number * 2);
  }

  return result;

}

console.log(getDoubleArray([1, 2, 3]));

let actual;
let expected;

/**
 * @param {Array<number>} num - 数値型の要素を持つ配列

 * @returns {number} 与えられた配列のすべての数字をかけあわせた答え
 */
function productArray(num) {
  let add = 1;

  for (const number of num) { // n1 : 1  n2: 2  n3: 6  n4:24
    console.log("number",number);
    add = add * number;
    console.log("add",add);
  }

  return add;
}

actual = productArray([1, 2, 3, 4, 5]);
expected = 120;

if (actual === expected) {
  console.log("Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd();
}

  // さらにテストを書きましょう。

   /**
    * @param {Array<any>} array
    * @returns {boolean} 与えられた配列に "fun" という文字列が入っているかどうかを表すブーリアン
    */
    
   function hasFun(array) {
    for(const any of array){
      if(any === "fun"){
        return true;
      }
    }
    return false;
  }

  actual = hasFun(["whatever", 2, false, "fun", "hello"]);
  expected = true;

  if (actual === expected) {
    console.log("Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.group("Result:");
    console.log("  actual:", actual);
    console.log("expected:", expected);
    console.groupEnd();
  }

  actual = hasFun(["whatever", 2, false, "run", "hello"]);
  expected = false;

  if (actual === expected) {
    console.log("Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.group("Result:");
    console.log("  actual:", actual);
    console.log("expected:", expected);
    console.groupEnd();
  }

  // さらにテストを書きましょう。
