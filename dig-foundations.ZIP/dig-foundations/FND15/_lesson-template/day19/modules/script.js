'use strict'
// 1行目に記載している 'use strict' は削除しないでください


const obj1 = { a: "A", b: "B" }

const obj2 = { b: "B", a: "A" }

test(obj1, obj2)


