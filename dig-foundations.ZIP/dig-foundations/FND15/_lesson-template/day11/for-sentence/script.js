'use strict'
// 1行目に記載している 'use strict' は削除しないでください
function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.group("Result:");
    console.log("  actual:", actual);
    console.log("expected:", expected);
    console.groupEnd();
  }
}

///////////////////////////////////////////////

// let index = 0;

// while (index <= 4) {
//   console.log("hello!");
//   index++;
// }

//↓

for (let index = 0; index <= 4; index++) {
  console.log("hello!");
}

///////////////////////////////////////
const array = ["a", "b", "c", "d", "e"];
for (let i = 0; i < array.length; i++) {
  console.log("Value: " + array[i], "Index: " + i);
}

///////////////////////////////////////

function sayFourHellos() {
  for (let i = 0; i < 4; i++)
    console.log("Hello!");
}


sayFourHellos();
// "Hello!"
// "Hello!"
// "Hello!"
// "Hello!"

function countDown(start) {
  let num = start;
  for (let i = 0; i < 10; i++) {
    if (num === start) {
      console.log(start);
    }
    console.log(start = start - 1);
  }
}

countDown(10);

//////////////////基礎演習No.1/////////////////////


function sayHellos(n) {
  for (let i = 0; i < n; i++)
    console.log("Hello!");
}
sayHellos(4);

//////////////////基礎演習No.2/////////////////////

function countToTen() {
  for (let i = 1; i <= 10; i++) {
    console.log(i);
  }
}

countToTen();

////////////////基礎演習No.3/////////////////////

function counter(num) {
  for (let i = 0; i < num; i++) {
    console.log(i)
  }
  // let i = 0;
  // while (i < num) {
  //   console.log(i);
  //   i++;
  // }
}

counter(10);

////////////////基礎演習No.4/////////////////////


function printArray(ary) {
  for (let i = 0; i < ary.length; i++) {
    console.log(ary[i]);
  }
}
const aaa = ["a", "b", "c", "d", "e"];
const bbb = ("abcde")

printArray(aaa);
printArray(bbb);

///文字列でも配列でも同じように一文字要素ずつ取り出される。

//////////////////////////////////////////////////

/**
   * @param {Array<number>} arrayNum
   * @returns {Array<number>} 与えられた配列の要素にそれぞれ 1 を加えた数字を要素として持つ配列
   */
function addOne(arrayNum) {
  let result = [];
  for (let i = 0; i <= arrayNum.length - 1; i++) {
    result[i] = arrayNum[i] + 1;
  }
  return result;
}

const array1 = [1, 2, 3, 4];

// function が動作するかテストする
test(addOne(array1), [2, 3, 4, 5]);
// 元の配列が変更されていないことを確認する
test(array1, [1, 2, 3, 4]);

/////////////////////////中級演習No.1/////////////////////////

/**
* @param {number} start
* @param {number} end
* @returns {Array<number>} start 以上 end 以下のすべての整数を含む配列
*/
function createRange(start, end) {
  let result = [];
  let num = end - start;
  if (start <= end) {
    result.push(start);
    for (let i = 0; i < num; i++) {
      start++
      result.push(start);
    }
  }
  else {
    return ("No");
  }
  return result;
}

test(createRange(4, 6), [4, 5, 6]);
test(createRange(10, 16), [10, 11, 12, 13, 14, 15, 16]);
test(createRange(4, 3), "No");

///////////////////////////中級演習No.2///////////////////////////

function printCars() {
  const cars = ["Toyota", "Mazda", "Mercedes", "BMW", "Hyundai", "Volvo"];

  for (let i = 0; i < cars.length; i++) {
    console.log(cars[i])
  }
  // let i = 0;

  // while (i < cars.length) {
  //   console.log(cars[i]);
  //   i++;
  // }
}

printCars()


//////////////////////////////中級演習No.3//////////////////////

const commands = ["Print me last", "Print me second", "Print me first"];

function decrement(list) {
  let i = list.length - 1
  while (i >= 0) {
    console.log(list[i]);
    i--;
  }
}

//function decrement(list) {
// for (let i = list.length - 1; i >= 0; i--) {
//   console.log(list[i]);
// }


decrement(commands);
// "Print me first"
// "Print me second"
// "Print me last"


/////////////////////////中級演習No.4///////////////////////////

/**
 * @param {number} start
 * @param {number} end
 * @param {number} step
 * @returns {Array<number>} start 以上 end 以下の整数を、 step の刻みで入れた配列。
 */

function createRangeBySteps(start, end, step) {
  let result = [];
  //let num = end - start;
  let count = start;
  if (start <= end) {
    result.push(start);
    for (let i = start; i <= end - step; i = i + step) {
      console.log(i);
      count = count + step;
      result.push(count);
    }
  } else {
    return ("No");
  }
  return result;
}


test(createRangeBySteps(1, 10, 2), [1, 3, 5, 7, 9]);
test(createRangeBySteps(10, 30, 5), [10, 15, 20, 25, 30]);
test(createRangeBySteps(1, 10, 1), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
test(createRangeBySteps(10, 30, 4), [10, 14, 18, 22, 26, 30]);
test(createRangeBySteps(50, 30, 4), "No");

////////////////////////中級演習No.5////////////////////////////////

/**
 * @param {Array<number>} ary1
 * @param {Array<number>} ary2
 * @returns {Array<number>} それぞれの配列の対応する要素の和からなる配列
 */
function addTogether(ary1, ary2) {
  let result = [];
  let sum;
  const maxLength = Math.max(ary1.length, ary2.length);
  for (let i = 0; i < maxLength; i++) {
    let num1 = ary1[i] || 0; //num1にはary1[i]に値があればその値を、undefinedやnullなら0を返す
    let num2 = ary2[i] || 0; //num2にはary2[i]に値があればその値を、undefinedやnullなら0を返す
    sum = num1 + num2;
    result.push(sum);
  }
  return result;
}

test(addTogether([1, 2, 3], [4, 5, 6]), [5, 7, 9]);
test(addTogether([1, 2, 3], [7, 8, 9]), [8, 10, 12]);
test(addTogether([1], [4, 5, 6]), [5, 5, 6]);

///////////////////////////////////////応用演習No.1///////////////////////

/**
   * @param {Array<any>} array
   * @returns {Array<any>} 重複していない値のみが入った配列
   */
function unique(array) {
  let result = [];
  for (let i = 0; i < array.length; i++) { //まずは配列の中身を全て見る。ループが終わるたびにcountを0にするためのループ
    let count = 0;
    for (let j = 0; j < array.length; j++) { //array[i]===array[0,1,2,3…]を確認。もしかぶってるならcount+1
      //二つ以上かぶってるならcountは2以上になる。一つしかないなら、重複してない
      if (array[i] === array[j]) {
        count++;
      }
    }
    if (count === 1) {//一つしか当たらなかった。配列の中に一つしかなかった値をarray[i]に.pushする
      result.push(array[i]);
    }
  }
  return result;
}

test(unique([1, 1, 1, 1, 1]), []);
test(unique([1, 3, 4, 5, 2, 4]), [1, 3, 5, 2]);


///////////////////////応用演習No.2///////////////////////////////////////////

/**
 * @param {...number} ...num
 * @returns {number} 引数の合計値
 */
function sum(...num) {
  let result = 0;
  console.log(num.length);
  for (let i = 0; i < num.length; i++) {
    result += num[i]
  }
  return result;
}

test(sum(1), 1);
test(sum(1, 1, 1, 1, 1), 5);
test(sum(1, 2, 3, 4, 5), 15);


////////////////////応用演習No.3////////////////////////////////////////////////

/**
 * @param {...<Array<any>} ...array
 * @returns {Array<any>} 与えられた配列内のすべての値を持つ配列
 */

// function zip(...array){
//   return array.flat();
// }


function zip(...array) {
  let result = [];
  for (let i = 0; i < array.length; i++) {
    for (let j = 0; j < array[i].length; j++) {
      result.push(array[i][j]);
    }
  }
  return result;
}


test(zip([1], [2], [3], [4]), [1, 2, 3, 4]);
test(zip([1, 2, 3], [4, 5], [1], [4]), [1, 2, 3, 4, 5, 1, 4]);


//ナイトメア//

/**
   * @param {string} str - 任意の 1 文字
   * @param {number} num - ツリーの高さ
   * @returns {string} 与えられた文字と高さを使用して、クリスマスツリーを文字列で作る。
   */
function christmasTree(str, num) {
  let result = "";
  if (num === 1) {
    for (let i = 1; i <= num; i++) {
      let spaces = " ".repeat(num - 1);
      result += spaces + str;
    }
  } else if (num > 1) {
    for (let i = 1; i <= num; i++) {
      let spaces = "";
      for(let j = 0; j < num - i ; j++){
      spaces += " ";
      }
      let leaves = (str + " ").repeat(i);
      result += spaces + leaves.trim();
      if (i !== num) {
        result += "\n";
      }
    }
  }
  console.log(result);
  return result;
}

// ここにコードを書きましょう

const expected1 = "T";
test(christmasTree("T", 1), expected1);
const expected2 = " +\n+ +";
test(christmasTree("+", 2), expected2);
const expected4 = "   #\n  # #\n # # #\n# # # #";
test(christmasTree("#", 4), expected4);
console.log(expected2);
console.log(expected4);

   // \n は改行を意味するコードです。実際に文字列をconsole.logすると、ツリーがこんな風に表示されますよ。

/*
      T
     T T
    T T T
   T T T T
  T T T T T
*/