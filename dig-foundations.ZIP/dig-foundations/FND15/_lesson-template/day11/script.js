'use strict'
// 1行目に記載している 'use strict' は削除しないでください
function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.group("Result:");
    console.log("  actual:", actual);
    console.log("expected:", expected);
    console.groupEnd();
  }
}


// const obj1 = { a: "A" };
// const obj2 = { a: "A", b: 2 };
// const obj3 = { a: "A", b: 2, c: "C", d: true };
// const obj4 = { a: "A", c: "C" };

// /**
//     * @param {object} オブジェクト
//     * @returns {{ [key: string]: string }} 与えられたオブジェクトによく似たオブジェクト。ただし、値が文字列のキー/値ペアだけを持つ。
//     */
// function filterObjectForStrings(object) {
//   let result = {};
//   for(const key in object){
//     console.log(object[key]);
//     if(typeof object[key] === "string"){
//       result[key] = object[key];
//     } 
//   } return result;
// }

// test(filterObjectForStrings(obj1), obj1); // 変化なし
// test(filterObjectForStrings(obj2), obj1); // キーが "b" のペアは含まれていない
// test(filterObjectForStrings(obj3), obj4); // キーが "b" や "d" のペアは含まれていない


//    /**
//     * @param {Array<object>} arrayOfObjects - オブジェクトの入った配列
//     * @returns {Array<{ [key: string]: string }>} 与えられたすべてのオブジェクトの入った配列だが、各オブジェクトには、値が文字列であるキー/値ペアだけが含まれる。
//     */
//    function filterArrayForStrings(arrayOfObjects) {
//     // ここにコードを書きましょう.
//     // ここの中で filterObjectForStrings(withSomething) を呼びましょう。
//     let result = [];
//     for(const withSomething of arrayOfObjects){
//     result.push(filterObjectForStrings(withSomething));
//   }
//     return result;
// }

//   test(filterArrayForStrings([obj1]), [obj1]); // 変化なし

//   // 2 番目の要素からキー が "b" のペアは除くこと
//   test(filterArrayForStrings([obj1, obj2]), [obj1, obj1]);

//   test(filterArrayForStrings([obj3, obj2, obj1]), [obj4, obj1, obj1]);



  const carOfmenu = [
    { name: "prius", price: "5,000,000yen", stock: "40" },
    { name: "noah", price: "2,670,000yen", stock: "30" },
    { name: "voxy", price: "3,090,000yen", stock: "20" },
    { name: "Sienta", price: "1,950,000yen", stock: "10" },
    {
      name: "harrier",
      price: "3,128,000yen",
      stock: "0",
      secret: "Happy coding!",
    },
  ];


  //すべてのkeyに対するvalueを出力しましょう
// let result = [];
// for(const count of carOfmenu){
//   for(const key in count){
//     console.log(count[key])
//   }
// }


////////////////////////////



//key名が[stock]のvalueを全て出力しましょう。

// //let result = [];
// for(const count of carOfmenu){
//   for(const key in count){
//     if(key === "stock"){
//       console.log(count[key])
//     }
//   }    
// }



//key名が[select]の入ったオブジェクトだけを出力しましょう

let any = {};
for(const count of carOfmenu){
  for(const key in count){
    if(key === "secret"){
      console.log(count);
    }
  }    
}


// let counter = 1;

// if (counter <= 10)

// console.log(counter);

// counter++;

//while文
// let counter = 1;
// while( counter <= 10){
//   counter++;
// }
 
// //for文
// for(let i = 0; i <= 10; i++){
//   thisistekitou();
// }

//↑10回適当な関数を動かす