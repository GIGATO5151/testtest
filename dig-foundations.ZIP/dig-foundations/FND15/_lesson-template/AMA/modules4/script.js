'use strict'
// 1行目に記載している 'use strict' は削除しないでください


/*
このプロジェクトでは自分が持っている lesson-templateを使います

このプロジェクトにはHTMLページに、「押してみて」というボタンが必要です。
lesson template の bodyに以下のコードを追加しましょう。
```
    <div id="display">0</div>
    <button>押してみて</button>
```

basic challenge: 
ボタンをクリックすると、ボタンの上のテキストが数字の「1」に変わります。
ボタンをクリックするたびに、この数字が1ずつ上がっていくようにします。

さあ、どう作りますか？

*このプロジェクトを実施するためには index.html のscriptタグ（JavaScriptとリンクさせているところ）が
適切な位置に置かれる必要があります。

advanced challenge: 
テキスト表示が1繰り上がると同時に表示画像がランダムに変わる
WebからURL入れる。
*/

//

const picArray = ["https://media.istockphoto.com/id/1449307455/ja/%E3%82%B9%E3%83%88%E3%83%83%E3%82%AF%E3%83%95%E3%82%A9%E3%83%88/%E6%8C%87%E7%B4%8B%E8%AA%8D%E8%A8%BC%E3%83%9C%E3%82%BF%E3%83%B3%E7%94%9F%E4%BD%93%E8%AA%8D%E8%A8%BC%E3%82%BB%E3%82%AD%E3%83%A5%E3%83%AA%E3%83%86%E3%82%A3.jpg?s=612x612&w=0&k=20&c=5m4QwWzFjIYrgWlQ2C6o9jxfGt49Bmw2UeEvTCeG4Eo=",
                  "https://media.istockphoto.com/id/1468185718/ja/%E3%82%B9%E3%83%88%E3%83%83%E3%82%AF%E3%83%95%E3%82%A9%E3%83%88/%E3%82%B0%E3%83%A9%E3%83%B3%E3%83%89%E3%83%94%E3%82%A2%E3%83%8E%E3%81%A8%E7%99%BD%E3%81%84%E8%83%8C%E6%99%AF%E3%81%AB%E3%82%B9%E3%83%86%E3%83%BC%E3%82%B8%E3%83%A9%E3%82%A4%E3%83%88%E3%81%A7%E7%85%A7%E3%82%89%E3%81%95%E3%82%8C%E3%81%9F%E9%9F%B3%E6%A5%BD%E3%82%B9%E3%83%86%E3%83%BC%E3%82%B8%E3%82%B7%E3%82%A2%E3%82%BF%E3%83%BC.jpg?s=612x612&w=0&k=20&c=wpym0d98gaOgC1cvkI2eOcsQAjnZMN3x0MSpcDG_1eU=",
                  "https://media.istockphoto.com/id/1468506905/ja/%E3%82%B9%E3%83%88%E3%83%83%E3%82%AF%E3%83%95%E3%82%A9%E3%83%88/%E3%83%81%E3%82%A7%E3%83%AA%E3%83%BC%E3%82%AA%E3%83%BC%E3%82%AC%E3%83%8B%E3%83%83%E3%82%AF%E3%83%86%E3%82%A3%E3%83%BC%E3%83%9E%E3%82%A6%E3%83%B3%E3%83%86%E3%83%B3%E3%81%AE%E7%A9%BA%E6%92%AE.jpg?s=612x612&w=0&k=20&c=XuyR8yM3Kgb4SnNeSDBTnvkieuTwaNc2Ru71AVsZubc="];

let num = 0;
function increment() {
  let count = document.getElementById("display");
  num++;
  count.innerText = num;
}

function picture(){
  const randomInt = Math.floor(Math.random() * picArray.length);
  console.log(randomInt);
  return document.getElementById("pic1").src = picArray[randomInt];
}



const push = document.getElementById("button");
push.addEventListener("click", increment)
push.addEventListener("click", picture)



//document.getElementById("pic_window").src = picArray[num]