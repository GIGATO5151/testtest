'use strict'
// 1行目に記載している 'use strict' は削除しないでください


console.log("hello");


/* 
for loopを使って 任意の数から0までコンソールに表示する
関数 countDownを書いてみよう！

引き数 カウントダウン開始の数値
返り値 undefined 
*/

// function countDown(num){
//   for(let i = num; i > 0; i--){
//     console.log(i)
//   }
  
// }

// countDown(5)

//再帰関数

function countDown2(init){
  console.log(init);
  if(init === 0){ //再帰関数の基底
    return;
  }else{
  countDown2(init - 1); // 再帰関数ステップ
  }
}

countDown2(5);


/* 
  再帰を使って 任意の数数から任意の数までコンソールに表示する
  関数 countUpを書いてみよう！
  
  引き数 : カウントアップ開始の値, カウントアップ上限の数値
  返り値 : undefined 
  */

 function countUp(start,upper){
  console.log(start);
  if(start === upper){
    return
  }else{
    countUp(start + 1,upper)
  }
 }

 countUp(0,5);
