'use strict'
// 1行目に記載している 'use strict' は削除しないでください


console.log("hello");


// //デバッガー練習用サンプルコード
// function exercise(colors){
//   for(const color of colors){
//     console.log(color); 
//   }
// }

// exercise(["red", "yellow", "blue"]);

/*
quiz【思い通りに動いてくれないコード】
実際には[-1, 0, 1, 2]が返ってくることを期待しているけれど思い通りに動かない！
このコードの何が間違っているのだろう？

このコードを読み予測を立ててみましょう。
*/
function sample(collection){
  let result = []; 

  for(const key in collection){
    if(collection[key]){
      result.push(collection[key]); 
    }
    else if(collection[key] === 0){
      result.push(collection[key]);
    }
  }

  return result; 
}
console.log(sample({a:-1, b:0, c:1, d:2, e: undefined}))// [-1, 0, 1, 2]を期待しているけれど思い通りに動かない