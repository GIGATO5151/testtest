'use strict'
// 1行目に記載している 'use strict' は削除しないでください


// const obj1 = { a: "A", b: "B" }

// const obj2 = { b: "B", a: "A" }

// test(obj1, obj2)


/*

exercise 

じゃんけんゲームを作ってみよう

basic - プログラムを起動するとじゃんけんゲームができる

- プログラムがじゃんけんの手を選択するようにユーザーに伝える

- ユーザーはグー、チョキ、パーから一つ選んで入力する

- プログラムはランダムに手を選ぶ

- ユーザーとプログラムの選択によって勝敗を表示するメッセージを表示する

 

advanced 

- ユニコーンの画像は勝敗によって変わる

- ユーザーが勝つかキャンセルするまで自動で次のゲームが開始される

- もっと遊んでもOK！

 

prompt 
https://developer.mozilla.org/ja/docs/Web/API/Window/prompt

 

alert 
https://developer.mozilla.org/ja/docs/Web/API/Window/alert

*/



const leagalmoves = ["rock", "scissors", "paper"]


function changeImage(newimg) {
  document.getElementsByTagName("img")[0].src = newimg;
}

function janken(choise) {
  const randomInt = Math.floor(Math.random() * 3);

  const computerChoice = leagalmoves[randomInt];

  console.log("choise: " + choise);
  console.log("computerChoice: " + computerChoice);
  if (choise !== null) {
    if (choise === computerChoice) {
      alert("Draw");
      const nextChoice = prompt("what is your choice? rock or scissors or paper?");
      return janken(nextChoice);
    }

    else if (
      (choise === "rock" && computerChoice === "scissors") ||
      (choise === "paper" && computerChoice === "rock") ||
      (choise === "scissors" && computerChoice === "paper")
    ) {
      changeImage("https://thumb.photo-ac.com/eb/ebefbf91a82a0f481a1fbf276318ed9d_w.jpeg");
      alert("You win!");
      return;
    } else {
      alert("You lose...");
      const nextChoice = prompt("what is your choice? rock or scissors or paper?");
      return janken(nextChoice);
    }
  }
  else return;
}

const userchoice = prompt("what is your choice? rock or scissors or paper?");

janken(userchoice);


