'use strict'
// 1行目に記載している 'use strict' は削除しないでください


// const obj1 = { a: "A", b: "B" }

// const obj2 = { b: "B", a: "A" }

// test(obj1, obj2)

///////////////////////////////////////

// alert("hello")

// const trigger = document.getElementById('gamestart');
// trigger.addEventListener("click", gamestarter );
// function gamestarter(){
//     let userChoise = prompt("Please select number. 0 :rock,  1 :scissors, 2 :paper");
//     //return userChoise;
//     const legalMoves = ["rock","scissors","paper"];
//     const user = userChoise;
//     const computerChoise = Math.floor(3*Math.random());
//     const judge = (user - computerChoise + 3) % 3;
//     const resultMessage = ["引き分け","あなたの負け","あなたの勝ち"];
//     if(judge === 0){
//       alert(resultMessage[0] + "  you: " + legalMoves[user] + "  vs  " + "cpu: " + legalMoves[computerChoise]);
//     }else if (judge === 1){
//       alert(resultMessage[1] + "  you: " + legalMoves[user] + "  vs  " + "cpu: " + legalMoves[computerChoise]);
//     }else{
//       alert(resultMessage[2] + "  you: " + legalMoves[user] + "  vs  " + "cpu: " + legalMoves[computerChoise]);
//     };
//   }


/*
exercise: 
prompt でログインを要求するコードを書いてください。

もし訪問者が "Admin" と入力したら、パスワードのための prompt を出します。もし入力が空行または 
キャンセルボタンが押下された 場合 – “Canceled” と表示します。別の文字列の場合は – “I don’t know you” と表示します。

パスワードは次に沿ってチェックされます:

”TheMaster" と等しい場合には “Welcome!” と表示します。
別の文字列の場合 – “Wrong password” を表示します。
空文字または入力がキャンセルボタンが押下された 場合 “Canceled.” と表示します。

入れ子の if ブロックを使ってください。コードの全体的な読みやすさI don’t know youに気をつけてください。

challenge: 
パスワードを自由に設定できる機能を追加する

*/

/*  adminと打つ。パスワード画面が開く、パスワード合ってれば、Welcome
それ以外だとダメ。
クロージャでchallengeして欲しい。
*/

function createAccount(selectPassword) {
    return function(){
      return selectPassword;
  }
}

//createAccount関数から返された関数が実行されるたびに、その関数が参照する「setpass」という変数が保持される
//パスワードを登録してから、複数回のログイン試行で同じパスワードを使用できるようになる。と思っている。。。

  let setpass = prompt("Set your Password?");
  let getPassword = createAccount(setpass);
  let username = prompt("Who's there?");
  console.log(username);
  if (username === null) {
    alert("Canceled");
  } else if (username !== "admin") {
    alert("I don't know you");
  } else {
    let password = prompt("Password?");
    if (password === getPassword()) {
      alert("Welcome!");
    } else if (password === null || password === "") {
      alert("Canceled")
    }
    else {
      alert("Wrong password");
    }
  }

  /*

  const greeting = (userName) => {
    if(typeof userName !== "string"){
        console.log("invalid data")
        return; 
    }
    return () => `Hello ${userName}!`; 
}

const hello2 = greeting("Taro")
console.log("hello2: ", hello2())

// const hello1 = greeting(777) // "invalid data"
// console.log("hello1: ", hello1()) //error

  */
  

  
  