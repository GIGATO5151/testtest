'use strict'
// 1行目に記載している 'use strict' は削除しないでください


// オブジェクトを作る関数を作ります
// 文字列型の引数を一つ取り、
// Nameプロパティにその値を持つオブジェクトを返します

// 返ってくるオブジェクトには二つのメソッドを持たせます
// 1. 自分のNameのValueをconsoleに表示する
// 2. 文字列型の引数を一つ取り、
//    自分のNameを変更するメソッド




function objMaker(objName){
  //オブジェクトをつくる
  let obj = {};
  obj.Name = objName;
  obj.outputName = function(){
    console.log(obj.Name);
  };
  obj.changeName = function(str){
    obj.Name  = str;
  };
  return obj;
}

//3つのkeyを持ったobjectがあって、1つは名前、2つは値としての関数をもらった感じですかね。


// テスト(TDDではない)

const objA = objMaker("apple");
const objB = objMaker("banana");

objA.outputName(); //consoleにapple表示
objA.changeName("amazon");
objA.outputName(); //consoleにamazon表示

objB.outputName(); //consoleにbanana表示
objB.changeName("brazil");
objB.outputName(); //consoleにbrazil表示

