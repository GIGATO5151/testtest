'use strict'
// 1行目に記載している 'use strict' は削除しないでください


const obj1 = { a: "A", b: "B" }

const obj2 = { b: "B", a: "A" }

test(obj1, obj2)

///////////////////////////////////////

// 関数 sayHi を実行するとコンソールに表示されるのは？それはなぜ？

let name = "Ayumi";

function sayHi() {
  console.log("Hi, " + name);
}

name = "Yuriko";

sayHi();

//////////////////////////////////////////

//スコープ
//


// makeWorkerは別の関数を作成して返します。その新しい関数は、別の場所から呼び出すことができます。
// コンソールに表示されるのはだれ？それはなぜ？

function makeWorker() {
  let name = "Mizki";

  return function() {
    console.log(name);
  };
}

//let name = "Arisa";

let work = makeWorker();

work();

//let nameの定義しているのがスコープの中で有効
//let name はArisaはメインで使われているので
//取ってこない。



// 2つのカウンターを作成します。counterとcounterは同じ関数makeCounterを使用します。
// 2つのカウンターがコンソールに表示するのは何？

function makeCounter() {
  let count = 0;

  return function() {
    return count++;
  };
}

let counter = makeCounter();
let counter2 = makeCounter();

console.log( counter() ); // ?
console.log( counter() ); // ?

console.log( counter2() ); // ?
console.log( counter2() ); // ?

//++はインクリメントされるが、returnだとインクリメント前が返される


// sum次のように機能する関数を作りましょう。
// sum(a)(b) = a+b。
// ※二重括弧を使用します (タイプミスではないよ！！)
// sum(1)(2) = 3
// sum(5)(-1) = 4

function sum(num1){
  return function(num2){
    return num1 + num2;
  }
}

console.log(sum(1)(2));
console.log(sum(5)(-1));

//Imさん
//const sum = num=>ele=>num+ele;

////////////////////////

//このコードの結果はどうなりますか?

let x = 1;

function func() {
  console.log(x); 

  let x = 2;
}

console.log(func());

//
// funcitonの中のlet xはconsole.logが先に読まれるが
// xが定義されてないと認識して、読めない。
//これを解決するにはconsole.logの前にx=2置く必要がある