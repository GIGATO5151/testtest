'use strict'
// 1行目に記載している 'use strict' は削除しないでください

console.log("Hello World!");

function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Yay! Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.group("Result:");
    console.log("  actual:", actual);
    console.log("expected:", expected);
    console.trace();
    console.groupEnd();
  }
}

let greeting = "Konnichiwa";

function sayHello(name) {
  let greeting = "Hi";
  return greeting + " " + name;
}

//greetingはグローバルスコープだったが、ローカルスコープ上にも
//定義されてるので、それがsayHelloの中では有効となり、Hiになるし
//エラーも出ない

console.log(sayHello("Rika"));


/////////////////基礎演習No.2////////////

//let sum = 0;

function sumArray(arrayOfNumbers) {
  let sum = 0;
  for (const number of arrayOfNumbers) {
    sum += number;
  }
  return sum;
}

//forの中のsumは関数が呼ばれた時点で消える
//またローカル変数からのreturnが呼ばれないので
//functionの中にsumを定義する必要がある


// 関数は何度呼び出しても期待どおりに動作しなければいけません。
test(sumArray([1, 2, 3]), 6);
test(sumArray([10, 20, 30]), 60);
test(sumArray([100, 200, 300]), 600);

//////////////////基礎演習No.3////////////////////

let count = 0;

function counter(x) {
  count = count + x;
  return count;
}


test(counter(3), 3);
test(counter(4), 7);
test(counter(5), 12);

