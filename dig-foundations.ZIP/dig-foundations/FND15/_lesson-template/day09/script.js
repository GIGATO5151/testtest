'use strict'
// 1行目に記載している 'use strict' は削除しないでください

console.log("Hello World!");


function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.group("Result:");
    console.log("  actual:", actual);
    console.log("expected:", expected);
    console.groupEnd();
  }
}


let actual;
let expected;

/**
    * @param {Array<number>} num - 数値型の要素を持つ配列

    * @returns {Array<number>} 与えられた配列の中の奇数だけが入った配列
    */

function getOddNumbers(num) {
  let result = [];
  for (const count of num) {
    if (count % 2 === 1) {
      result.push(count);
      console.log(result);
    }
  } return result;
}

actual = getOddNumbers([1, 2, 3, 4, 5, 6, 7, 8]);
expected = [1, 3, 5, 7];
// 現時点では、配列の比較には JSON.stringify を使う必要があると覚えておいてください。
if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

// テストを書きましょう。




const info = {
  name: "Hana",
  dog: true,
  age: 12
};

console.log(info["dog"]);
console.log(info.dog);
console.log(info.animal);
let animal = "dog";
console.log(info[animal]); //info["dog"]と同じ

console.log(info["name"]);
console.log(info.name);
console.log(info.age);
let age = 12;
console.log(info[age]); //info[12]はinfoオブジェクトの中に無い。

//console.log(info[dog]); dogという変数が無いからundefined

let lesson = {
  instructor: "Eriko",
  coding: true,
  place: "Zoom"
};

lesson.school = "DIG";

console.log(lesson); //ドットでも追加可能

lesson["instructor"] = "Tamaroh";

console.log(lesson);

lesson["student"] = "Hiroki";

console.log(lesson);

lesson["coding"] = false;
console.log(lesson);


////////////////////////////////////////////////////////////
console.log("演習3");
/**
 * @param {string} str - モールス信号に変換する文字
 * @returns {string} 与えられた文字に対応するモールス信号
 */

const morseCode =
{
  t: "-",
  a: ".-",
  r: ".-.",
}

function morseCodeArt(str) {
  let result = [];
  let i = 1;
  for (const cnt of str) {
    if (i === 1) {
      i++;
      if (cnt === "a") {
        result = morseCode[cnt];
      }
      if (cnt === "r") {
        result = morseCode[cnt];
      }
      if (cnt === "t") {
        result = morseCode[cnt];
      }
    }
    else {
      if (cnt === "a") {
        result += " " + morseCode[cnt];
      }
      if (cnt === "r") {
        result += " " + morseCode[cnt];
      }
      if (cnt === "t") {
        result += " " + morseCode[cnt];
      }
    }
  } return result;
}


test(morseCodeArt("a"), ".-");
test(morseCodeArt("r"), ".-.");
test(morseCodeArt("t"), "-");
test(morseCodeArt("art"), ".- .-. -");



let greeting = "Konnichiwa";

function sayHello(name) {
  let greeting = "Hi";
  return greeting + " " + name;
}

console.log(sayHello("Rika"));  //Hi Rika 





function sumArray(arrayOfNumbers) {
  let sum = 0;
  for (const number of arrayOfNumbers) {
    sum += number;
  }
  return sum;
}

// 関数は何度呼び出しても期待どおりに動作しなければいけません。
test(sumArray([1, 2, 3]), 6);
test(sumArray([10, 20, 30]), 60);
test(sumArray([100, 200, 300]), 600);



/////////////////////////////////////////////////

let count = 0;

function counter(x) {
   count = count + x;
  return count;
}

test(counter(3), 3);
test(counter(4), 7);
test(counter(5), 12);



