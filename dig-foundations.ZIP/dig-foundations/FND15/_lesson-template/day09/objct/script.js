'use strict'
// 1行目に記載している 'use strict' は削除しないでください

function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.group("Result:");
    console.log("  actual:", actual);
    console.log("expected:", expected);
    console.groupEnd();
  }
}


console.log("Hello World!");

const place = "Zoom";
const lesson = {
  instructors: ["Eriko", "Misa", "Tamaroh"],
  coding: true,
  place: "Zoom",
};
console.log(lesson["place"]); // Zoom
console.log(lesson.place); // Zoom
console.log(lesson[place]); // undefined
console.log(lesson["cod" + "ing"]); // true
console.log(lesson[2]); // undefined　//Object.valuesを使うと、valueの値が配列として取得できます。
//同様にObject.keysを使うと、配列としてオブジェクトのキーを取得できます。
//Object.keysでオブジェクトの値を配列に変換してから、インデックスで取得すればいいです。

console.log(lesson.instructors[2]); // Tamaroh
console.log(lesson.length); // undefined　Object.keys(obj).lengthこれじゃないと取れない
console.log(lesson.instructors.length); // 3
console.log(typeof lesson.instructors); // object 配列ではない



const object = {
  a: "hello",
  b: "bye",
  c: 1000,
};

console.log(object["a"]); // "hello"
console.log(object.b); // "bye"
object["b"] = "goodbye";
console.log(object["b"]); // "goodbye"

// これは少しトリッキーです 😉
//console.log(object[a]); // undefined


const pokemons = [
  {
    Number: "001",
    Name: "Bulbasaur",
    Generation: "Generation I",
    About:
      "Bulbasaur can be seen napping in bright sunlight. There is a seed on its back. By soaking up the sun's rays, the seed grows progressively larger.",
    Types: ["Grass", "Poison"],
  },
  {
    Number: "025",
    Name: "Pikachu",
    Generation: "Generation I",
    About:
      "Whenever Pikachu comes across something new, it blasts it with a jolt of electricity. If you come across a blackened berry, it's evidence that this Pokémon mistook the intensity of its charge.",
    Types: ["Electric"],
  },
  {
    Number: "019",
    Name: "Rattata",
    Generation: "Generation I",
    About:
      "Rattata is cautious in the extreme. Even while it is asleep, it constantly listens by moving its ears around. It is not picky about where it lives—it will make its nest anywhere.",
    Types: ["Normal"],
  },
];

console.log(pokemons[0]); // 001全部
console.log(pokemons[1].Name); // Picachu
console.log(pokemons[0]["Name"]); // Bulbasaur
console.log(pokemons[2]["About"]); // Rattata is cautious in the extreme. Even while it is asleep, it constantly listens by moving its ears around. It is not picky about where it lives—it will make its nest anywhere."
console.log(pokemons[2].Types[0]); // Normal

/////////////////////////////基礎演習No.1//////////////////////////


const myInfo = {
  name: "Hiroki",
  age: "34",
  location: "home",
  isCoder: true
}

// この演習では TDD スタイルのテストは必要ありません。ここでは console.log を使用してください。
console.log(myInfo["isCoder"]); // => "true"



/////////////////////////////基礎演習No.2//////////////////////////


const morseCode = {
  "t": "-",
  "a": ".-",
  "r": ".-.",

}

test(morseCode["t"], "-");
test(morseCode["a"], ".-");
test(morseCode["r"], ".-.");


/////////////////////////////基礎演習No.3//////////////////////////


/**
 * @param {string} str - モールス信号に変換する文字
 * @returns {string} 与えられた文字に対応するモールス信号
 */


function morseCodeArt(str) {
  let result;
  for (let i = 1; i < str.length + 1; i++) {
    let aaa = str.charAt(i - 1);
    console.log(aaa);
    console.log(i);
    if (i === 1) {
      if (aaa === "a") {
        console.log("ok");
        result = ".-";
      }
      else if (aaa === "r") {
        result = ".-.";
      }
      else if (aaa === "t") {
        result = "-";
      }
    } else if (i > 1) {
      if (aaa === "a") {
        result += " .-";
      }
      if (aaa === "r") {
        result += " .-.";
      }
      if (aaa === "r") {
        result += " -";
      }
    }
  }
  return result
}


test(morseCodeArt("a"), ".-");
test(morseCodeArt("r"), ".-.");
test(morseCodeArt("t"), "-");
test(morseCodeArt("art"), ".- .-. -");


/////////////////////////////基礎演習No.4//////////////////////////

/**
 * @param {object} obj - オブジェクト
 * @param {Array<string>} strArray - 文字列の入った配列
 * @returns {object} 与えられた配列の要素をキーにして、それに対応する値は第1引数のオブジェクトから抽出して作られた新しいオブジェクト
 */

function select(obj, strArray) {
  const result = {};
  for (let i = 0; i < strArray.length; i++) {
    let key = strArray[i]
    if (obj.hasOwnProperty(key)) { //もし引数で与えた配列内の文字列がobjにあればtrue
      console.log(key);
      result[key] = obj[key];  //オブジェクトresult[a]に（：は勝手に代入）obj[a]のデータを代入
    }
  }
  return result;
}

test(select({ a: 1, b: 2, c: 3 }, ["a"]), { a: 1 });
test(select({ a: 1, b: 2, c: 3 }, ["a", "c"]), { a: 1, c: 3 });
test(select({ a: 1, b: 2, c: 3 }, ["a", "b", "c"]), { a: 1, b: 2, c: 3 });
test(select({ a: 1, b: 2, c: 3 }, []), {});



/////////////////////////////基礎演習No.5//////////////////////////

/**
 * @param {string} str
 * @returns {{ [character: string]: number }} 与えられた文字列の中の各アルファベットをキーに、その登場回数を値にしたオブジェクト
 */
function countCharacters(str) {
  let result = {};
  for (let i = 0; i < str.length; i++) {
    let char = str[i];  //文字列を一文字ずつ取り出して、charに代入。
    if (result[char]) {  //resultオブジェクトのキー値にcharがあったらtrue
      result[char]++;    //そのキー値の要素を1足す
    }
    else result[char] = 1;//そうでなければ、resultオブジェクトのchar代入されたキー値の要素に1を代入
  } return result;
}


test(countCharacters("hello"), { h: 1, e: 1, l: 2, o: 1 });
test(countCharacters("hello hello"), { h: 2, e: 2, l: 4, o: 2, " ": 1 });


/////////////////////中級演習No.1///////////////////////

/**
 * @param {string} str
 * @returns {{ [word: string]: number }} 与えられた文字列の中の各単語をキーとして持つオブジェクト。各キーに対応する値は、それぞれの単語が文字列の中で使われている回数。
 */
function countWords(str) {
  let result = {};
  let char = str.split(" ");
  console.log(char);
  console.log(char.length);
  if (str !== "") {
    for (let i = 0; i < char.length; i++) {
      let word = [] = char[i]
      console.log(char[i]);
      console.log(result);
      if (result[word]) {
        result[word]++;
      }
      else result[word] = 1;
    }
    return result;
  }
  result = {};
  return result;
}

test(countWords("hello hello"), { hello: 2 });
test(countWords("hello Hello ringo ringo"), { hello: 1, Hello: 1, ringo: 2 });
test(countWords(""), {});


////////////////////////ポケモンタイム////////////////


// const pokemons = [
//   {
//     Number: "001",
//     Name: "Bulbasaur",
//     Generation: "Generation I",
//     About:
//       "Bulbasaur can be seen napping in bright sunlight. There is a seed on its back. By soaking up the sun's rays, the seed grows progressively larger.",
//     Types: ["Grass", "Poison"],
//   },
//   {
//     Number: "025",
//     Name: "Pikachu",
//     Generation: "Generation I",
//     About:
//       "Whenever Pikachu comes across something new, it blasts it with a jolt of electricity. If you come across a blackened berry, it's evidence that this Pokémon mistook the intensity of its charge.",
//     Types: ["Electric"],
//   },
//   {
//     Number: "019",
//     Name: "Rattata",
//     Generation: "Generation I",
//     About:
//       "Rattata is cautious in the extreme. Even while it is asleep, it constantly listens by moving its ears around. It is not picky about where it lives—it will make its nest anywhere.",
//     Types: ["Normal"],
//   },
// ];

/**
 * @param {Array<object>} pokeArray - ポケモンオブジェクトが入った配列
 * @returns {Array<string>} 各オブジェクトの `Names` を要素に持つ配列
 */
function getNames(pokeArray) {
  let result = [];
  for (let i = 0; i < pokeArray.length; i++) {
    result[i] = pokeArray[i].Name;
  }
  return result;
}

// 'pokemons' の配列は、以下のコードより上に書かれていなければいけません。

test(getNames(pokemons), ["Bulbasaur", "Pikachu", "Rattata"]);

/**
* @param {Array<object>} pokeArray - ポケモンが入った配列
* @param {number} num - 取り出したいポケモンの 'number'
* @returns {object|null} 与えられた数字を 'number' に持つポケモン。もし対応するポケモンが存在しなければ、null を返す。
*/

function findPokemon(pokeArray, num) {
  let number;
  let result = null;
  for (let i = 0; i < pokeArray.length; i++) {
    number = pokeArray[i].Number;
    console.log(number);
    if (number == num) {
      result = pokeArray[i]
    }
  }
  return result;
}


test(findPokemon(pokemons, 1), pokemons[0]);
test(findPokemon(pokemons, 19), pokemons[2]);
test(findPokemon(pokemons, 25), pokemons[1]);
test(findPokemon(pokemons, 1337), null);

///////////応用演習//////////////////////////

/**
  * @param {object} obj - オブジェクト
  * @returns {object} 与えられたオブジェクトのキー/値のペアのうち、値が奇数のものを除いた新たなオブジェクト。
  */


function removeOddValues(obj) {
  let number;
  let result = {};
  let prop = Object.entries(obj);
  console.log(prop);
  console.log(prop.length);
  for (let i = 0; i < prop.length; i++) {
    if (typeof prop[i][1] === "number") {
      for (let i = 0; i < prop.length; i++) {
        console.log(prop[i]);
        number = prop[i].slice(-1);
        console.log(number);
        if (parseInt(number) % 2 === 0)
          result[prop[i][0]] = prop[i][1];
      } return result;
    } return obj;
  }

}

test(removeOddValues({ a: 1, b: 2, c: 3 }), { b: 2 });
test(removeOddValues({ a: "1", b: "2", c: "3" }), {
  a: "1",
  b: "2",
  c: "3",
});
// 1 行が非常に長くなる場合は、キー/値のペアを改行して書くこともできます。


//ナイトメア//

const routes = [
  { route: "タクシー", time: { taxi: 74 }, cost: 15720 },
  { route: "ミュースカイ＋名古屋＋地下鉄", time: { kintetsu: 29, transit: 7, subway: 5, walk: 6 }, cost: 1460 },
  { route: "ミュースカイ＋金山＋バス", time: { kintetsu: 24, transit: 17, bus: 24, walk: 3 }, cost: 1400 },
  { route: "ミュースカイ＋金山＋地下鉄", time: { kintetsu: 24, transit: 6, subway: 8, walk: 6 }, cost: 1400 },
  { route: "ミュースカイ＋神宮前＋バス", time: { kintetsu: 21, transit: 10, bus: 30, walk: 3 }, cost: 1330 },
  { route: "特急＋金山＋地下鉄", time: { kintetsu: 32, transit: 5, subway: 8, walk: 6 }, cost: 1030 },
];

/**
 * @param {Array<object>}  ルートの入った配列
 * @returns {object} 一番時間のかかるオブジェクト
 */

function check(routeObj) {
  const timeValues = Object.values(routeObj.time);
  const totalTime = timeValues.reduce((sum, value) => sum + value, 0);
  return totalTime;
}

function longestTime(array) {

  if(array === undefined){
    return undefined;
  }

  // for (let i = 0; i < array.length; i++) {
  //   const totalTime = check(array[i]); // 各オブジェクトの totalTime を計算
  const totalTime = array.map(element => check(element));
  return array[totalTime.indexOf(Math.max(...totalTime))];
}

test(longestTime(routes), routes[0]);
test(longestTime(routes.slice(3)), routes[4]);
test(longestTime(), undefined);