'use strict'
// 1行目に記載している 'use strict' は削除しないでください
console.log("Hello world");

function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.group("Result:");
    console.log("  actual:", actual);
    console.log("expected:", expected);
    console.groupEnd();
  }
}

//////////////////////ウォームアップ////////////////////
  /**
    * @param {Array<object>} arrayObj - オブジェクトの入った配列
    * @param {string} key
    * @returns {Array<any>} 各オブジェクトの中から、与えられたキーに等しいキーに対応する値だけを拾って（＝ pluck して）、配列に入れたもの
    */


    function pluck(arrayObj,key){
      let result = [];
      for(const count of arrayObj){
        console.log(count);
        result.push(count[key]);
      }
      console.log(result)
      return result;
    }

   const arrayOfObjects = [
    { a: 1, b: 2, c: 3 },
    { a: 4, b: 5, c: 6 },
    { a: 7, b: 8, c: 9 },
  ];

  test(pluck(arrayOfObjects, "b"), [2, 5, 8]);

////////////////////////////////////////////////////////////////////////////////////////////////////////

const infoObject = {
  name: "Hana",
  dog: true,
  age: 12
}

console.log(infoObject.length);

for (const key in infoObject) { //keyには各要素のキーが入る
  const value = infoObject[key];
  console.log(value);
}

//配列の場合for of  オブジェクトの場合for in

// //////////////////////////////////////////////////////

// const hellos = {
//   English: "Hello",
//   Japanese: "Konnichiwa",
//   German: "Hallo",
//   Spanish: "Hola",
//   Arabic: "Ahlan wa sahlan",
//   Chinese: "Nihao",
// };


//    /**
//     * @returns {undefined} この関数は色々な言語で"Hello" を表示するだけで、返り値は必要ありません。
//     */
//     function sayHellos(){
//       for(const hello in hellos){
//         console.log(hellos[hello])
//       }
//     }

//    // console.log の表示は、返り値ではないため、テストするのは困難です。
//    // 今回は、コンソールの表示を確認することで、テストとしてください。

//    sayHellos();
//    // "Hello"
//    // "Konnichiwa"
//    // "Hallo"
//    // "Hola"
//    // ...

// /////////////////////////////////////////////////////

//    /**
//     * @param {object} obj
//     * @returns {Array<string>} 与えられたオブジェクトのすべてのキーが入った配列
//     */
//    // ここにコードを書きましょう
//     function getKeys(obj){
//       const result = [];
//       for(const key in obj){
//         result.push(key);
//       }
//       return result;
//     }

//    const object1 = { a: 1, b: 2, c: "hello" };
//    const object2 = { 1: "a", 2: "b", hello: "c" };

//    test(getKeys(object1), ["a", "b", "c"]);
//    test(getKeys(object2), ["1", "2", "hello"]);


//    /**
//     * @param {object} obj - オブジェクト。ただし値はすべて異なるものとする。
//     * @returns {object} 与えられたオブジェクトのキーと値を入れ替えた、新しいオブジェクト
//     */
    
//     function swapPairs(obj){
//       const result = {};
//       for(const key in obj){
//         result[obj[key]] = key;
//       }
//       console.log(result);
//       return result;
//     }

//    const object3 = { a: 1, b: 2, c: 3, d: 4 };
//    const object4 = { 1: "a", 2: "b", 3: "c", 4: "d" };

//    test(swapPairs(object3), { 1: "a", 2: "b", 3: "c", 4: "d" });
//    test(swapPairs(object4), { a: "1", b: "2", c: "3", d: "4" });

////////////////////////////////////////////////

let  a = [1,2,3];
let  b = [1,2,3];

if(a[0] === b[0]){//これは文字列だからOK
  console.log("OK");
}
else console.log("No")

if(a === b){//これはアドレス比較だからNo
  console.log("OK");
}
else console.log("No")


// //////////////////////////////



let theLoneliestNumber = 1;

let aFriend = theLoneliestNumber;

console.log(theLoneliestNumber); // 1
console.log(aFriend); // 1
console.log(theLoneliestNumber === aFriend); // true


///////////////////////////////////////////////////////////


const kermit = [
  "red",
  "orange",
  "yellow",
  "green",
  "blue",
  "indigo",
  "violet",
];
const missPiggy = kermit.slice();

 console.log(kermit);

// const kermit = [
//   "red",
//   "orange",
//   "yellow",
//   "green",
//   "blue",
//   "indigo",
//   "violet",
// ];


console.log(missPiggy);
//  const kermit = [
//   "red",
//   "orange",
//   "yellow",
//   "green",
//   "blue",
//   "indigo",
//   "violet",
// ];


console.log(kermit === missPiggy); // false =>文字列じゃないためfalse

//////////////////////////////////////////////////////////

let mamas = "Monday";

let papas = mamas;

papas += ", so good to me.";

console.log(mamas); // "Monday"
console.log(papas); // "Monday, so good to me."
console.log(mamas === papas); // false

//////////////////////////////////////////////////////////////

const theFabFour = {
  bass: ["paul"],
  drums: ["ringo"],
  guitar: ["george", "john"],
  vocals: ["george", "john", "paul", "ringo"],
};

const theFifthBeatle = theFabFour;
theFifthBeatle.guitar.push("beau");

console.log(theFabFour); /**
{
  bass: ["paul"],
  drums: ["ringo"],
  guitar: ["george", "john", "beau"],
  vocals: ["george", "john", "paul", "ringo"],
  guitar: [beau]
}; */ 
console.log(theFifthBeatle); 

/** 
{
  bass: ["paul"],
  drums: ["ringo"],
  guitar: ["george", "john", "beau"],
  vocals: ["george", "john", "paul", "ringo"],
  guitar: [beau]
}; */ 

console.log(theFabFour === theFifthBeatle); // true

// console.log(theFabFour.guitar); // ["george", "john", "beau"]
console.log(theFifthBeatle.guitar); //  ["george", "john", "beau"]
console.log(theFabFour.guitar === theFifthBeatle.guitar); // true =>　参照しているオブジェクトが完全一致ならtrueを返す。

///////////////////////////////////////////////////////

let isHot = true;
let isCold = !isHot;

isHot = !isHot;

console.log(isHot); // false
console.log(isCold); // false
console.log(isHot === isCold); // true

/////////////////////////////////////////////////////////

const easyAs = [
  ["a", "b", "c"],
  [1, 2, 3],
  ["do", "re"],
];
const simpleAs = easyAs.slice();
simpleAs[2].push("mi");

console.log(easyAs); 
/** 
[
  ["a", "b", "c"],
  [1, 2, 3],
  ["do", "re","mi"],
];
*/ 

console.log(simpleAs); 
/** 
[
  ["a", "b", "c"],
  [1, 2, 3],
  ["do", "re","mi"],
];
*/ 

console.log(easyAs === simpleAs); // false => 新しい配列オブジェクト作成するが、easyAsとは別に割り当てられたメモリを使用している為false

console.log(easyAs[2]); //["do", "re","mi"] 
console.log(simpleAs[2]); //["do", "re","mi"] 
console.log(easyAs[2] === simpleAs[2]); // ture => この場合は同じ要素の中の文字列比較であるため、true


