'use strict'
// 1行目に記載している 'use strict' は削除しないでください
console.log("Hello world");

function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.group("Result:");
    console.log("  actual:", actual);
    console.log("expected:", expected);
    console.groupEnd();
  }
}

const infoObject = {
  name: "Hana",
  dog: true,
  age: 12
}

for (const key in infoObject) { //keyには各要素のキーが入る
  const value = infoObject[key];
  console.log(value);
}

//配列の場合for of  オブジェクトの場合for in


///////////////////基礎演習1///////////////////

const hellos = {
  English: "Hello",
  Japanese: "Konnichiwa",
  German: "Hallo",
  Spanish: "Hola",
  Arabic: "Ahlan wa sahlan",
  Chinese: "Nihao",
};

/**
   * @returns {undefined} この関数は色々な言語で"Hello" を表示するだけで、返り値は必要ありません。
   */
function sayHellos() {
  for (const greet in hellos) {
    console.log(hellos[greet]);
  }
}

// console.log の表示は、返り値ではないため、テストするのは困難です。
// 今回は、コンソールの表示を確認することで、テストとしてください。

sayHellos();
// "Hello"
// "Konnichiwa"
// "Hallo"
// "Hola"
// ...

//////////////////////基礎演習No.2/////////////

/**
 * @param {object} obj
 * @returns {Array<string>} 与えられたオブジェクトのすべてのキーが入った配列
 */

function getKeys(obj) {
  let result = [];
  for (const word in obj) {
    result.push(word);
  }
  return result;
}

const object1 = { a: 1, b: 2, c: "hello" };
const object2 = { 1: "a", 2: "b", hello: "c" };

test(getKeys(object1), ["a", "b", "c"]);
test(getKeys(object2), ["1", "2", "hello"]);


//////////////////////基礎演習No.3/////////////

/**
* @param {object} obj
* @returns {Array<any>} 与えられたオブジェクトのすべての値が入った配列
*/
function getValues(obj) {
  let result = [];
  for (const key in obj) {
    result.push(obj[key]);
  }
  return result;
}

test(getValues(object1), [1, 2, "hello"]);
test(getValues(object2), ["a", "b", "c"]);

//////////////////////基礎演習No.4////////////

const myObj = { foo: 1, bar: 2, key: 3, delta: 4, lee: 5 };
function printAll(object) {
  for (const key in object) {
    console.log(object[key]);
  }
}

printAll(myObj);

//////////////////////基礎演習No.5////////////

/**
* @param {object} obj - オブジェクト。ただし値はすべて異なるものとする。
* @returns {object} 与えられたオブジェクトのキーと値を入れ替えた、新しいオブジェクト
*/
function swapPairs(obj) {
  let result = {};
  let any;
  for (const key in obj) {
    any = obj[key];
    result[any] = key;
  }
  return result;
}

const object3 = { a: 1, b: 2, c: 3, d: 4 };
const object4 = { 1: "a", 2: "b", 3: "c", 4: "d" };

test(swapPairs(object3), { 1: "a", 2: "b", 3: "c", 4: "d" });
test(swapPairs(object4), { a: "1", b: "2", c: "3", d: "4" });

//////////////////////基礎演習No.5////////////

//配列で for ... in ループを使用することはできるでしょうか。

//出来るが推奨されない。オブジェクトの中身のlengthも返す可能性がある。

const array = ['apple', 'banana', 'orange'];

for (const index in array) {
  console.log(index, array[index]);
}

//0 apple
//1 banana
//2 orange

//////////////////////基礎演習No.6////////////

//オブジェクトで for ... of ループを使用することはできるでしょうか。

//出来ません。for ofは配列に対する関数の為、オブジェクトには使用できない。


//////////////////////基礎演習No.7////////////


/**
 * @param {Array<object>} arrayObj - オブジェクトを要素に持つ配列

 * @returns {Array<any>} 与えられた配列の最初のオブジェクトのすべての値が入った配列
 */

function getFirstObjectValues(arrayObj) {
  let newArray = [];
  let result = [];
  for (const count of arrayObj) {
    const aaa = Object.values(count);
    console.log(aaa);
    newArray.push(aaa);
  }
    result = newArray.shift();
  // newArray = result.slice(0, 1);
  // result = result.flat();
  return result;
}

const collection = [{ a: 1, b: 2 }, { a: 3, b: 3 }, { b: 4 }, { a: 100 }];

test(getFirstObjectValues(collection), [1, 2]);
test(getFirstObjectValues(collection.slice(1)), [3, 3]);

//////////////////////基礎演習No.9////////////

/**
 * @param {Array<object>} arrayObj
 * @returns {Array<any>} すべてのオブジェクトのすべての値が入った配列
 */
function getAllValues(arrayObj) {
  let result = [];
  for (const count of arrayObj) {
    const value = Object.values(count);
    for (const int of value) {
      result.push(int);
    }
  } return result;
}

test(getAllValues(collection), [1, 2, 3, 3, 4, 100]);
test(getAllValues(collection.slice(1)), [3, 3, 4, 100]);


//////////////////////基礎演習No.10////////////////////

/**
 * @param {Array<object>} arrayObj
 * @param {string} Name - 取り出したいキーの名前
 * @returns {Array<any>} すべてのオブジェクトにおいて第二引数のキーに対応する値が入った配列
 */
function selectAllValues(arrayObj, Name) {
  let result = [];
  for (const objCount of arrayObj) {
    let newArray = [];
    let any;
    newArray = Object.keys(objCount)
    //console.log(newArray);
    for (const arrayCount of newArray) {
      if (arrayCount === Name)
        result.push(objCount[Name]);
      console.log(result);
    }

  } return result;
}


test(selectAllValues(collection, "a"), [1, 3, 100]);
test(selectAllValues(collection, "b"), [2, 3, 4]);


/////////////////////中級演習No.1////////////////

/**
 * @param {object} obj
 * @returns {object} 与えられたオブジェクトのキーと値を入れ替えた新しいオブジェクト。重複する値がある場合は、最初のキー/値のペアのみを使用し、その後のペアは無視すること。
 */
function swapPairs2(obj) {
  let result = {};
  let change = {};
  for (const key in obj) {
    let any = [];
    any = obj[key];
    if (!(any in change)) {
      change[any] = key;
    } else console.log("aaaaa")
  }
  return change;
}



const object5 = { a: 1, b: 2, c: 3, d: 1 };
const object6 = { a: 1, b: 1, c: 1, d: 1 };

// 1 はすでに使われているので、d:1 は無視される
test(swapPairs2(object5), { 1: "a", 2: "b", 3: "c" });
// この場合も 1  はすでに使われているので、二回目以降、1 が値になるキー/値のペアは無視される。

test(swapPairs2(object6), { 1: "a" });

/**
 * @param {Array<object>} arrayObj
 * @returns {Array<any>} 与えられた配列内のすべてのオブジェクトのすべての値が入った配列。重複した値がある場合は 1 つだけ残す。
 */
function getAllValues2(arrayObj) {
  let newArray = [];
  let result = [];
  for (const count of arrayObj) {
    const value = Object.values(count);
    console.log(value);
    for (const val of value) {
      newArray.push(parseInt(val));
      console.log(newArray);
    }
  }
  for (const num of newArray) {
    if (!result.includes(num)) {
      result.push(num);
      console.log(result);
    }
    else console.log("aaa");
  }
  return result;
}

const collection2 = [{ a: 1, b: 2, c: 2 }, { d: 1, e: 3 }, { f: 4, g: 5 }];

test(getAllValues2(collection2), [1, 2, 3, 4, 5]);
test(getAllValues2(collection2.slice(1)), [1, 3, 4, 5]);


// const hellos = {
//   English: "Hello",
//   Japanese: "Konnichiwa",
//   German: "Hallo",
//   Spanish: "Hola",
//   Arabic: "Ahlan wa sahlan",
//   Chinese: "Nihao",
// };

/**
 * @returns {string} 基礎演習 1 で使った `hellos` オブジェクトの中の任意の言葉
 */


function getRandomHello() {
  let result = [];
  let num;
  for (const key in hellos) {
    result.push(hellos[key]);
    num = result.length
    console.log(result);
  }
  return (result[Math.floor(Math.random() * num)]);
}

// ランダムな出力をする関数をテストすることは困難です。
// ここでは、コンソールの表示を見て、テストとしましょう。
console.log(getRandomHello()); // "konnichiawa"、"hola"、等、実行する度にランダムな言葉が表示されるはずです。


/**
  * @param {object} obj
  * @returns {object} 与えられたオブジェクトのキーと値を入れ替えた新しいオブジェクト。重複する値がある場合は、それらのキーを配列に入れること。
  */
function swapPairs3(obj) {
  let result = {};
  for (const key in obj) {
    let any = [];
    any = obj[key];
      console.log(any);
      if ((any in result)) {
        console.log(result)
        if(Array.isArray(result[any])){
          console.log("true");
        result[any].push(key)
        console.log(result);
        }else {
          result[any] = [result[any]];
          console.log("array-false");
          result[any].push(key)
          console.log(result);
        }
    }else if (!(any in result)){
        result[any] = key;
    }
  }
  return result;

}

test(swapPairs3(object5), { 1: ["a", "d"], 2: "b", 3: "c" });
test(swapPairs3(object6), { 1: ["a", "b", "c", "d"] });

//    const object5 = { a: 1, b: 2, c: 3, d: 1 };
// const object6 = { a: 1, b: 1, c: 1, d: 1 };
//const object3 = { a: 1, b: 2, c: 3, d: 4 };

   /**
    * @param {object} obj
    * @returns {object} 引数のオブジェクトとほぼ同じ形のオブジェクトだが、同じ値を持つキー/値のペアは除外する。
    */
    function noDuplicateValues(obj){
      let result = {};
      let any = {};
      for(const key in obj){
        const num = obj[key];
        const value = Object.values(key);
        if((!value in obj)){
          result = obj;
        }
        else if(!Object.values(result).includes(num)){ //キーがresultの中には行ってなかったら
          any[num] = key;
          result[key] = num;
        }
         else if(any[num] !== key){ //値がオブジェクの中にあって、格納されたキーが違ったら
          console.log(key)
          delete result[any[num]]; //格納されてるキーを消す
         }
        }
        return result;
      }
      

   test(noDuplicateValues(object3), object3);
   test(noDuplicateValues(object5), { b: 2, c: 3 });
   test(noDuplicateValues(object6), {});