'use strict'
// 1行目に記載している 'use strict' は削除しないでください
function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.group("Result:");
    console.log("  actual:", actual);
    console.log("expected:", expected);
    console.groupEnd();
  }
}

////////クロージャ―//////

function outerfunc() {
  let word = "Hi!";
  function innerFunc() {
    console.log(word);
  }
  return innerFunc;
}

console.log(outerfunc());

const func = outerfunc();

func();//outerfunc()を()で実行する感じ


///////////////////////////////////////////////////////


function addOne(number) {
  return number + 1;
}

test(addOne(5), 6);
test(addOne(50), 51);



///////////////////////////////////////


function doSomething(value, action) {
  return action(value);
}

function greeting(name) {
  return `Hello ${name}`;
}

//test(doSomething("Alex", greeting()), "Hello Alex"); // A error
test(doSomething("Alex", greeting), "Hello Alex"); // B　正しい

/////////////////////////////////////////

let x = "Outside x";

function bar() {
  x = "Inside x";
  return "This is bar!";
}

console.log(bar()); //=> 
console.log(x); // => Inside x


//////////////////////////////////////////////////////////////////

function createPasswordProtectedAccount(userChosenPassword) {
  const savedPassword = userChosenPassword; //Test1234

  function checkPassword(passwordEntered) {
    if (savedPassword === passwordEntered) {
      console.log("正しいパスワードです。アクセスを許可します。");
    } else {
      console.log("パスワードが間違っています。アクセスできません。");
    }
  }

  return checkPassword;
}

const account = createPasswordProtectedAccount("Test1234"); // 引数に初期パスワードを入れる。

account("8skwob"); // 引数に間違ったパスワードを入れる => "パスワードが間違っています。アクセスできません。"
account("Test1234");

const accountB = createPasswordProtectedAccount("banana");
account("banana"); // => 間違い
accountB("banana"); // => 正しい

//createPasswordProtectedAccount("Test1234")//checkPassword(8skwob)

// account("Test1234"); // 引数に正しいパスワードを入れる => "正しいパスワードです。アクセスを許可します。"






function createDonationAccount() {
  let donations = 0;

  function addDonation() {
    console.log(donations);
    donations += 1;
  }
  console.log("寄付受付口座が作成されました。");
  return addDonation;
}

const aaa = createDonationAccount();

aaa();
aaa();
aaa();











/**
   * @param {number} x
   * @returns {(y: number) => number} 引数 y をとり、y に x を足した値を返す関数
   */
// コードを書き始めましょう
function add(x) {
  function InnerFunc(y) {
    return y + x;
  }
  return InnerFunc;
}

const addFive = add(5);
test(addFive(1), 6);


/**
* @param {number} age
* @returns {() => boolean} 実行されるたびに age に 1 を足し、 age が 13 以上かどうかを返す関数
*/
function createWebsiteAccount(age) {
  function InnerFunc() {
    age++;
    console.log(age);
    if (age >= 13) {
      return true;
    }
    else return false;
  }
  return InnerFunc
}


const childAccount = createWebsiteAccount(10);
test(childAccount(), false); // => false
test(childAccount(), false); // => false
test(childAccount(), true); // => true (今、子供は 13 歳です！)

const adultAccount = createWebsiteAccount(33);
test(adultAccount(), true); // => true (何回呼び出すかに関わらず、いつも true を返す)




   /**
    * @param {number} x
    * @returns {(y: number) => number} 引数として y をとり、x から y を引いた値を返す関数
    */
    function subtract(x){
      return function(y){
        return x - y;
      }
    }

   const subtract5 = subtract(5);

   test(subtract5(4), 1);
   test(subtract(10)(8), 2);


  //ナイトメア//

  /**
 * @param {number} num
 * @returns {Function} 呼び出しが連鎖でき、value メソッドで値を取り出せる関数
 */
// ここにコードを書きましょう

function addCurry(num) {
  let result = num;

  function add(value) {
    result += value;
    return add;
  }

  add.value = function() {
    return result;
  };

  return add;
}



// 関数を一度呼び出すだけでも、value() で値を得られます。
test(addCurry(1).value(), 1);

// 関数呼び出しを連鎖させて、累計を出すことができます。
test(addCurry(1)(2).value(), 3);
test(addCurry(1)(2)(3)(4)(5)(6).value(), 21);