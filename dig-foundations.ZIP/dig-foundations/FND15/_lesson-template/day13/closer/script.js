'use strict'
// 1行目に記載している 'use strict' は削除しないでください

function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.group("Result:");
    console.log("  actual:", actual);
    console.log("expected:", expected);
    console.groupEnd();
  }
}

//////////////////ペア演習/////////////////////

// function addOne(1) {
//   return 1;
// }

// test(addOne(5), 6);
// test(addOne(50), 51);

//↓

function addOne(num) {
  return num + 1;
}

test(addOne(5), 6);
test(addOne(50), 51);


//////////////////////////////////////////////////

function doSomething(value, action) {
  return action(value);
}

function greeting(name) {
  return `Hello ${name}`;
}

//test(doSomething("Alex", greeting()), "Hello Alex"); // A
test(doSomething("Alex", greeting), "Hello Alex"); // B

//Bが正しい。doSomethingの引数にvalueとaction。actionにgreetingが入ると
//return action = greeting よってreturn greeting("Alex")となり。
//greeting関数が呼び出される。()を付けてしまうと
//action = greeting()("Alex")となるので、エラーが出てしまう。

///////////////////////////////////////////////////////

let x = "Outside x";
function bar() {
  let x = "Inside x";
  return "This is bar!";
}

bar(); // => console.logがないので何も表示されない。console.logすると　"This is bar!"
console.log(bar());
console.log(x); // => "Outside x" グローバル変数のOutside　x　が有効


//////////////////////////////////////////////////////////
//プライベート変数とは？
/*
ローカル変数のこと。functionの中とかでしか使えない変数。
グローバル変数からのアクセスは出来ない。
そのローカルでしか機能しない変数のこと。
*/

///////////////////////////基礎演習No.1///////////////////


function createPasswordProtectedAccount(userChosenPassword) {
  const savedPassword = userChosenPassword;

  function checkPassword(passwordEntered) {
    if (savedPassword === passwordEntered) {
      console.log("正しいパスワードです。アクセスを許可します。");
    } else {
      console.log("パスワードが間違っています。アクセスできません。");
    }
  }

  return checkPassword;
}

const account = createPasswordProtectedAccount("Test1234"); // 引数に初期パスワードを入れる。
account("8skwob"); // 引数に間違ったパスワードを入れる => "パスワードが間違っています。アクセスできません。"
/* account("8skwob") はcreatePasswordProtectedAccount("Test1234"){
   chackPassword("8skwob")と同じ意味　=> passwordEnterdの引数に代入
}
*/
account("Test1234"); // 引数に正しいパスワードを入れる => "正しいパスワードです。アクセスを許可します。"

////////////////////////////基礎演習No.2////////////////////////////////

function createDonationAccount() {
  let donations = 0;

  function addDonation() {
    console.log(donations);
    donations += 1;
  }
  console.log("寄付受付口座が作成されました。");
  return addDonation;
}

const makekouza = createDonationAccount();

makekouza();
makekouza();
makekouza();

///////////////////基礎演習No.3///////////////////////////////////////


/**
 * @param {number} x
 * @returns {(y: number) => number} 引数 y をとり、y に x を足した値を返す関数
 */
// コードを書き始めましょう
function add(x) {
  function InnerFunc(y) {
    return y + x;
  }
  return InnerFunc; //()はいらない。
}

const addFive = add(5)
test(addFive(1), 6);

/////////////////////////////基礎演習No.4///////////////////////////////

// let counter = 0;
// function makeCounter() {
//   return function () {
//     counter += 1;
//     return counter;
//   };
// }


function makeCounter() {
  let counter = 0;
  return function () {
    counter += 1;
    return counter;
  };
}


const counterA = makeCounter();
test(counterA(), 1);
test(counterA(), 2);

const counterB = makeCounter(); // 新しいカウンターを作りたい。
test(counterB(), 1);
test(counterB(), 2);

//////////////////////////////中級演習No.1////////////////////////

   /**
    * @param {number} age 年齢
    * @returns {() => boolean} 実行されるたびに age に 1 を足し、 age が 13 以上かどうかを返す関数
    */
    function createWebsiteAccount(age){
      return function (){
        age++;
        if(age >= 13){
          console.log("true: "+ age);
          return true;
        }
        else{
          console.log("false: "+ age);
          return false;
        } 
      }
    }

   const childAccount = createWebsiteAccount(10);
   test(childAccount(), false); // => false
   test(childAccount(), false); // => false
   test(childAccount(), true); // => true (今、子供は 13 歳です！)

   const adultAccount = createWebsiteAccount(33);
   test(adultAccount(), true); // => true (何回呼び出すかに関わらず、いつも true を返す)

   //////////////////////////////////中級演習No.2/////////////////////////////////


      /**
    * @param {number} x
    * @returns {(y: number) => number} 引数として y をとり、x に y を掛け合わせた値を返す関数
    */
    function product(x){
      let result;
      return function(y){
        result = x * y;
        return result;
      }
    }

   const product3 = product(3);

   test(product3(4), 12);
   test(product(4)(5), 20);


     //////////////////////////////////中級演習No.3/////////////////////////////////

      /**
    * @param {number} x
    * @returns {(y: number) => number} 引数として y をとり、x から y を引いた値を返す関数
    */
    function subtract(x){
      let result;
      return function(y){
        result = x - y;
        return  result;
      }
    }
   const subtract5 = subtract(5);

   test(subtract5(4), 1);
   test(subtract(10)(8), 2);

   