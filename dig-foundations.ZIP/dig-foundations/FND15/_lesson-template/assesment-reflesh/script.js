'use strict'
// 1行目に記載している 'use strict' は削除しないでください

function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Yay! Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.log("    actual: ", actual);
    console.log("  expected: ", expected);
    console.trace();
  }
}

//////////////////////No.1///////////////////

/**
 * @param {string} str
 * @param {object} obj
 * @returns {str} 犬は牛肉（beef）味のドッグフード、猫はマグロ（tuna）味のキャットフードが好きで、それ以外は食べたがりません。
 */

function feed(str, obj) {
  let result = "";
  if (str === "dog" && obj.custom === "dog food" && obj.taste === "beef") {
    result = "I love it!";
  }
  else if (str === "cat" && obj.custom === "cat food" && obj.taste === "tuna") {
    result = "I love it!";
  }
  else {
    result = "I don't like it!";
  }
  return result;
}

test(feed("dog", { custom: "dog food", taste: "beef" }), "I love it!");
test(feed("dog", { custom: "dog food", taste: "chicken" }), "I don't like it!");
test(feed("dog", { custom: "cat food", taste: "chicken" }), "I don't like it!");

test(feed("cat", { custom: "cat food", taste: "tuna" }), "I love it!");
test(feed("cat", { custom: "cat food", taste: "chicken" }), "I don't like it!");
test(feed("cat", { custom: "dog food", taste: "beef" }), "I don't like it!");


// //////////////////////No.2///////////////////
/**
 * @param {array} array
 * @returns {Array<str>} 配列を引数に取り、その配列の要素の順番を反対にした新しい配列を返します。
 */

function reverse(array) {
  const result = array.map((_, index, array) => array[array.length - 1 - index])
  return result;
}


test(reverse([1, 2, 3]), [3, 2, 1]);
test(reverse([{ name: "mike", isCat: true }, true, "hello!"]), ["hello!", true, { name: "mike", isCat: true }]);
test(reverse([1, 2, 3, 4, 5, 6]), [6, 5, 4, 3, 2, 1]);


// //////////////////////No.3///////////////////

/**
 * @param {Obj} listObj
 * @param {Array} cartObj
 * @returns {num} 合計金額（税込）を出す。税率は10％
 * 
 */

const priceList = {
  apple: 150,
  banana: 190,
  grape: 2000,
  orange: 300,
};

const shoppingCart = {
  apple: 3,
  banana: 1,
  grape: 3,
  orange: 5,
};

function calculateTotalWithTax(listObj, cartObj) {
  const taxRate = 1.1;

  const totalWithTax = Object.keys(cartObj).reduce((total, item) => {
    const itemTotal = listObj[item] * cartObj[item];
    return total + itemTotal;
  }, 0) * taxRate;

  return totalWithTax;
}

test(calculateTotalWithTax(priceList, shoppingCart), 8954);

// //////////////////////No.4///////////////////

/**
 * @param {Array} array
 * @returns {array<num>}  totalBookSales は、本の情報が入った配列を受け取り、本ごとの売り上げの入った配列を返します
 */

function totalBookSales(array) {
  const result = array.map(element => addPrice(element))
  return result;
}
function addPrice(obj) {
  return obj.price * obj.sales;
}

test(totalBookSales([
  {
    id: 1,
    name: "JavaScript の基礎を復習する本",
    price: 2800,
    stock: 3,
    sales: 10,
  },
  { id: 2, name: "JavaScript の配列", price: 3200, stock: 2, sales: 5 },
  { id: 3, name: "DOM を極める", price: 3800, stock: 5, sales: 15 },
  { id: 4, name: "高階関数の基本", price: 4200, stock: 1, sales: 20 },
  { id: 5, name: "DIG BTC の心構え", price: 2680, stock: 4, sales: 10 },
]), [28000, 16000, 57000, 84000, 26800]);


// //////////////////////No.5///////////////////

/**
 * @param {Array} array
 * @returns {array<str>}  オブジェクトの入った配列から、指定されたプロパティの値だけを格納した配列を作成し、返します。
 */

function getValuesByProperty(array, property) {
  const result = array.reduce((acc, cur) => {
    acc.push(cur[property]);
    return acc;
  }, []);

  return result;
}

const objects = [
  { name: "Alice", age: 30 },
  { name: "Bob", age: 25 },
  { name: "Charlie", age: 35 },
];

const property = "name";

test(getValuesByProperty(objects, property), ["Alice", "Bob", "Charlie"]);


// //////////////////////No.6///////////////////

/**
 * @param {Array} array
 * @returns {Array} コレクション内の各要素に対してコールバック関数を実行した結果を要素に持つ新しい配列を返します。
 */

function mergeAndSumObjects(...arrays) {
  const flattenedArray = arrays.flat();
  const Ids = [];

  flattenedArray.forEach(item => {
    if (!Ids.includes(item.id)) {
      Ids.push(item.id);
    }
  });

  const result = Ids.map(id => {
    const itemsWithId = flattenedArray.filter(item => item.id === id);
    const mergedItem = itemsWithId.reduce((acc, cur) => {
      acc.x += cur.x;
      acc.y += cur.y;
      return acc;
    }, { id, x: 0, y: 0 });
    return mergedItem;
  });

  return result;
}


const arr1 = [
  { id: 1, x: 1, y: 3 },
  { id: 2, x: 3, y: 5 },
];
const arr2 = [{ id: 3, x: 2, y: 2 }];

test(mergeAndSumObjects(arr1, arr2), [{ id: 1, x: 1, y: 3 }, { id: 2, x: 3, y: 5 }, { id: 3, x: 2, y: 2 }]);

const arr3 = [{ id: 2, x: 3, y: 4 }];

test(mergeAndSumObjects(arr1, arr2, arr3), [{ id: 1, x: 1, y: 3 }, { id: 2, x: 6, y: 9 }, { id: 3, x: 2, y: 2 }]);

// //////////////////////No.7///////////////////

/**
 * @param {array} array
 * @param {function} func
 * @returns {Array} 1行で書きます
 *  */

const doTheThing = (arr, ...funcs) => arr.filter(funcs[1]).map(funcs[0]).filter(funcs[2]);

const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

test(doTheThing(
  numbers,
  (n) => n * 3,
  (n) => n % 2 === 0,
  (n) => n > 20
  ,), [24, 30]);



// //////////////////////No.8///////////////////

/**
 * @param {string} str
 * @param {Object} obj
 * @returns {string} 文字列とオブジェクト型の値を引数にとり、文字列を引数にとる関数を返します
 */


function createMessages(str, obj) {
  return function (subStr) {
    const start = obj.start + " ".repeat(obj.space);
    const end = " ".repeat(obj.space) + obj.end;
    const space = " ".repeat(obj.space);
    return `${start}${str}${space}${subStr}${end}`;
  };
}


let greeting = createMessages("Hello", { start: "😄", end: "♪", space: 1 });
test(greeting("DIG"), "😄 Hello DIG ♪");

greeting = createMessages("Domo!", { start: "🦈", end: "🦈", space: 2 });
test(greeting("Same Desu!"), "🦈  Domo!  Same Desu!  🦈");

// //////////////////////No.10///////////////////


/**
 * @param {String} str1
 * @param {String} str2
 */

function getDiffDate(str1, str2) {
  let result = 0;
  const comp1 = str1.split("/");
  const comp2 = str2.split("/");

  for (let i = 0; i < comp1.length; i++) {
    const diff = comp2[i] - comp1[i];
    if (diff !== 0) {
      if (i === 0) {
        result += diff * 365;
      } else if (i === 1) {
        result += diff * 31;
      } else if (i === 2) {
        result += diff * 1;
      }
    }
  }
  return Math.abs(result);
}

test(getDiffDate("2019/01/01", "2019/01/02"), 1);
test(getDiffDate("2019/01/01", "2019/01/01"), 0);
test(getDiffDate("2019/01/01", "2019/02/01"), 31);
test(getDiffDate("2019/01/01", "2020/01/01"), 365);
test(getDiffDate("2019/01/01", "2021/01/01"), 730);
test(getDiffDate("2019/01/01", "2018/01/01"), 365);


// //////////////////////No.11///////////////////
/**
* @param {Number} init
* @param {Number} step
* @returns {number}2 つの数値型の引数をとり、関数を返します。返り値の関数は引数をとらず、最初に実行すると初期値を、以降は呼び出されるごとに初期値からステップ数分増やし（減らし）、それを返します。
*/


function createCounter(init, step) {
  let result = init;

  if (step === undefined) {
    step = 1;
  }

  return function () {
    const num = result;
    result += step;
    return num
  }
}

const countDownFromOneHundred = createCounter(100, -5);
const countUpFromTen = createCounter(10);

console.log(countDownFromOneHundred());
console.log(countUpFromTen());
console.log(countUpFromTen());
console.log(countDownFromOneHundred());
console.log(countDownFromOneHundred());

// //////////////////////No.12///////////////////

/**
* @param {String} str
* @param {String} searchString
* @param {Number} endposition
* @return {boolean} endsWithと同じ処理を返す
*/

function endsWith(str, searchString, endPosition) {
  if (endPosition === undefined) {
    endPosition = str.length;
  } else if (endPosition > str.length) {
    endPosition = str.length;
  }

  const endIndex = endPosition - searchString.length;
  if (endIndex < 0) {
    return false;
  }

  const slicedPortion = str.slice(endIndex, endPosition);
  return slicedPortion === searchString;
}



const str1 = "Cats are the best!";

test(endsWith(str1, "best!"), true);
test(endsWith(str1, "best", 17), true);

const str2 = "Is this a question?";

test(endsWith(str2, "question"), false);



// //////////////////////No.13///////////////////

/**
* @param {Array or Object} any
* @param {String} extreme
* @return {Number} この関数はコレクション（配列またはオブジェクト）を引数にとり、条件（最大か最小）に応じた値を返します
*/

function findExtremeValue(any, extreme) {
  let result = 0;
  if (extreme === "MAX") {
    result = max(any);
  } else if (extreme === "MIN") {
    result = min(any);
  }
  return result;
}

function max(maxNum) {
  let answer = 0;
  if (Array.isArray(maxNum)) {
    for (let i = 0; i < maxNum.length; i++) {
      if (answer < maxNum[i]) {
        answer = maxNum[i];
      }
    }
  } else {
    let array = Object.values(maxNum);
    for (let i = 0; i < array.length; i++) {
      if (answer < array[i]) {
        answer = array[i];
      }
    }
  }
  return answer;
}

function min(minNum) {
  let answer = Infinity;
  if (Array.isArray(minNum)) {
    for (let i = 0; i < minNum.length; i++) {
      if (answer > minNum[i]) {
        answer = minNum[i];
      }
    }
  } else {
    let array = Object.values(minNum);
    for (let i = 0; i < array.length; i++) {
      if (answer > array[i]) {
        answer = array[i];
      }
    }
  }
  return answer;
}

const arr4 = [1, 2, 3];
const arr5 = [10, 20, 15];
const comp1 = { a: 100, b: 70, c: 50 };
const comp2 = { a: 50, b: 5, c: 500 };

console.log(findExtremeValue(arr4, "MAX"));
console.log(findExtremeValue(arr5, "MIN"));
console.log(findExtremeValue(comp1, "MAX"));
console.log(findExtremeValue(comp2, "MIN"));

// //////////////////////No.14///////////////////

const drinkStock = [
  { name: "cola", price: 120 },
  { name: "water", price: 100 },
  { name: "tea", price: 150 },
];


const vendingMachine = {

  money: 0,

  totalMoney: 1000,

  insertMoney: function (num) {
    if (num === undefined) {
      console.log("お金を投入してください");
    }
    else if (num <= 0) {
      console.log("お金を投入してください");
    }
    else {
      this.money = num;
      this.totalMoney += num;
    }
  },


  selectDrink: function (str) {
    if (this.money > 100) {
      for (const drink of drinkStock) {
        if (drink.name === str) {
          console.log(`${str} が出てきました`);
          this.money -= drink.price;
          return;
        }
      }
      console.log(`${str}はありません`);
    } else {
      console.log("お金が足りません");
    }
  },

  returnChange: function () {
    console.log(this.money);
    this.totalMoney -= this.money;
    this.money = 0;
  }

}


vendingMachine.insertMoney(500);
console.log(vendingMachine.money);
console.log(vendingMachine.totalMoney);
vendingMachine.selectDrink("water");
vendingMachine.returnChange();
console.log(vendingMachine.money);
console.log(vendingMachine.totalMoney);

vendingMachine.insertMoney(100);
vendingMachine.selectDrink("cola");

vendingMachine.insertMoney();
vendingMachine.insertMoney(-100);

vendingMachine.insertMoney(300);
vendingMachine.selectDrink("soda");


// //////////////////////No.15///////////////////

/**
* @param {Number or String or Array or Object} comp1
* @param {Number or String or Array or Object} comp2
* @return {Number}  compare は 2 つの値を引数に取り、その値が等しいかを判定してブーリアンを返します。
*/


function compare(comp1, comp2) {
  if (typeof comp1 === "number" && typeof comp2 === "number") {
    if (comp1 !== comp2) {
      return false;
    }
    return true;
  }

  if (typeof comp1 === "string" && typeof comp2 === "string") {
    if (comp1 !== comp2) {
      return false;
    }
    return true;
  }

  if (typeof comp1 !== 'object' || typeof comp2 !== 'object') {
    return false;
  }

  if (Object.keys(comp1).length !== Object.keys(comp2).length) {
    return false;
  }

  for (let key in comp1) {
    if (comp1.hasOwnProperty(key)) {
      if (!comp2.hasOwnProperty(key)) {
        return false;
      }

      if (typeof comp1[key] === 'object' && typeof comp2[key] === 'object') {
        if (!compare(comp1[key], comp2[key])) {
          return false;
        }
      } else if (comp1[key] !== comp2[key]) {
        return false;
      }
    }
  }

  return true;
}

test(compare(1, 1), true);
test(compare(1, 2), false);
test(compare("a", "a"), true);
test(compare("a", "b"), false);
test(compare([1, 2, 3], [1, 2, 3]), true);
test(compare([1, 2, 3], [1, 2, 4]), false);
test(compare([1, 2, 3], [1, 2, 3, 4]), false);
test(compare({ a: 1, b: 2 }, { a: 1, b: 2 }), true);
test(compare({ a: 1, b: 2 }, { b: 2, a: 1 }), true);
test(compare({ a: 1, b: 2 }, { a: 1, b: 3 }), false);
test(compare(
  { a: 1, b: { c: { d: 2, e: { f: 3 } } } },
  { a: 1, b: { c: { d: 2, e: { f: 3 } } } }
), true);
test(compare(
  { a: 1, b: { c: { d: 2, e: { f: 3 } } } },
  { a: 1, b: { c: { d: 2, e: { f: 4 } } } }
), false);
test(compare(
  { a: 1, b: { c: { d: 2, e: { f: 3 } } } },
  { a: 1, b: { c: { d: 2, e: { f: 4, g: 5 } } } }
), false);

// //////////////////////No.16///////////////////


function furnitureStore() {
  const accounts = [];
  const items = [];

  function isDuplicateAccount(emailAddress) {
    return accounts.find(account => account.emailAddress === emailAddress) !== undefined;
  }

  function createAccount(account) {
    if (isDuplicateAccount(account.emailAddress)) {
      return false;
    }
    accounts.push(account);
    return true;
  }




  function isDuplicateItemId(id) {
    return items.find(item => item.id === id) !== undefined;
  }

  function isAdmin(account) {
    return account.idAdmin === true;
  }

  function createItem(account, item) {
    if (!isAdmin(account)) {
      return false;
    }

    if (isDuplicateItemId(item.id)) {
      return false;
    }
    items.push(item);
    return true;
  }


  function getItem(id) {
    const item = items.find(item => item.id === id);
    if (!item) {
      return false;
    }
    return item;
  }



  function getItemByCategory(category) {
    const itemsByCategory = items.filter(item => item.category === category);
    if (itemsByCategory.length === 0) {
      return false;
    }
    return itemsByCategory;
  }


  function getItemByPrice(priceData) {
    const { price, condition } = priceData;
    if (condition === "or less") {
      const itemsLessThanPrice = items.filter(item => item.price <= price);
      if (itemsLessThanPrice.length === 0) {
        return "Not found";
      }
      return itemsLessThanPrice;
    } else if (condition === "or more") {
      const itemsMoreThanPrice = items.filter(item => item.price >= price);
      if (itemsMoreThanPrice.length === 0) {
        return "Not found";
      }
      return itemsMoreThanPrice;
    } else {
      return false;
    }
  }

  function getItemByStock(stockData) {
    const { stock, condition } = stockData;
    if (condition === "or more") {
      const itemsWithMoreStock = items.filter(item => item.stock >= stock);
      if (itemsWithMoreStock.length === 0) {
        return "Not found";
      }
      return itemsWithMoreStock;
    } else {
      return false;
    }
  }

  function getItemByName(nameData) {
    const { name } = nameData;
    const itemsWithName = items.filter(item => item.name === name);
    if (itemsWithName.length === 0) {
      return "Not found";
    }
    return itemsWithName;
  }


  function deleteItem(account, idData) {
    if (!isAdmin(account)) {
      return false;
    }
    
    const { id } = idData;
    const indexToDelete = items.findIndex(item => item.id === id);
    if (indexToDelete === -1) {
      return false;
    }
    items.splice(indexToDelete, 1);
    return true;
  }


  return function (action, account, data) {
    if (action === "CREATE_ACCOUNT") {
      return createAccount(account);
    } else if (action === "CREATE_ITEM") {
      return createItem(account, data);
    } else if (action === "GET_ITEM") {
      return getItem(data.id);
    } else if (action === "GET_ITEM_BY_CATEGORY") {
      return getItemByCategory(data.category);
    } else if (action === "GET_ITEM_BY_PRICE") {
      return getItemByPrice(data);
    } else if (action === "GET_ITEM_BY_STOCK") {
      return getItemByStock(data);
    } else if (action === "GET_ITEM_BY_NAME") {
      return getItemByName(data);
    } else if (action === "DELETE_ITEM") {
      return deleteItem(account, data);
    }
  }
}

const store = furnitureStore();

const tmcAccount = {
  id: 1,
  name: "TMC",
  emailAddress: "tmc@email-service.com",
  idAdmin: false,
};
const digAccount = {
  id: 2,
  name: "DIG",
  emailAddress: "dig@email-service.com",
  idAdmin: false,
};
const adminAccount = {
  id: 3,
  name: "ADMIN",
  emailAddress: "admin@email-service.com",
  idAdmin: true,
};

// --------------------------------------------------

test(store("CREATE_ACCOUNT", tmcAccount), true);
test(store("CREATE_ACCOUNT", digAccount), true);
test(store("CREATE_ACCOUNT", adminAccount), true);
test(store("CREATE_ACCOUNT", tmcAccount), false); // false（同じアカウントは存在できない）

// --------------------------------------------------

test(store("CREATE_ITEM", adminAccount, {
  id: 1,
  name: "desk chair",
  category: "chair",
  stock: 100,
  price: 3000,
}), true);
test(store("CREATE_ITEM", adminAccount, {
  id: 2,
  name: "very good desk",
  category: "desk",
  stock: 50,
  price: 50000,
}), true);
test(store("CREATE_ITEM", adminAccount, {
  id: 3,
  name: "awesome desk",
  category: "desk",
  stock: 0,
  price: 100000,
}), true);
test(store("CREATE_ITEM", adminAccount, {
  id: 4,
  name: "good bed",
  category: "bed",
  stock: 20,
  price: 30000,
}), true);
test(store("CREATE_ITEM", adminAccount, {
  id: 4,
  name: "bookcase",
  category: "storage",
  stock: 50,
  price: 5000,
}), false);
test(store("CREATE_ITEM", adminAccount, {
  id: 5,
  name: "bookcase",
  category: "storage",
  stock: 50,
  price: 5000,
}), true);
test(store("CREATE_ITEM", digAccount, {
  name: "awesome chair",
  category: "chair",
  stock: 100,
  price: 100000,
}), false);

// // --------------------------------------------------

test(store("GET_ITEM", tmcAccount, { id: 1 }),
  {
    id: 1,
    name: "desk chair",
    category: "chair",
    stock: 100,
    price: 3000
  });

test(store("GET_ITEM", tmcAccount, { id: 2 }),
  {
    id: 2,
    name: "very good desk",
    category: "desk",
    stock: 50,
    price: 50000
  });

test(store("GET_ITEM", tmcAccount, { id: 1000 }), false);

// // --------------------------------------------------

test(store("GET_ITEM_BY_CATEGORY", tmcAccount, { category: "desk" }),
  [
    {
      id: 2,
      name: "very good desk",
      category: "desk",
      stock: 50,
      price: 50000
    },
    {
      id: 3,
      name: "awesome desk",
      category: "desk",
      stock: 0,
      price: 100000
    }
  ]);

test(store("GET_ITEM_BY_CATEGORY", tmcAccount, { category: "chair" }),
  [
    {
      id: 1,
      name: "desk chair",
      category: "chair",
      stock: 100,
      price: 3000
    }
  ]);

test(store("GET_ITEM_BY_CATEGORY", tmcAccount, { category: "table" }), false);


// // --------------------------------------------------

test(store("GET_ITEM_BY_PRICE", digAccount, {
  price: 50000,
  condition: "or less",
}),
  [
    {
      id: 1,
      name: "desk chair",
      category: "chair",
      stock: 100,
      price: 3000
    },
    {
      id: 2,
      name: 'very good desk',
      category: 'desk',
      stock: 50,
      price: 50000,
    },
    {
      id: 4,
      name: "good bed",
      category: "bed",
      stock: 20,
      price: 30000
    },
    {
      id: 5,
      name: "bookcase",
      category: "storage",
      stock: 50,
      price: 5000
    }
  ]);


test(store("GET_ITEM_BY_PRICE", digAccount, {
  price: 50000,
  condition: "or more",
}),
  [
    {
      id: 2,
      name: "very good desk",
      category: "desk",
      stock: 50,
      price: 50000
    },
    {
      id: 3,
      name: "awesome desk",
      category: "desk",
      stock: 0,
      price: 100000
    }
  ]);

test(store("GET_ITEM_BY_PRICE", digAccount, {
  price: 1000000,
  condition: "or more",
}), "Not found");


// // --------------------------------------------------

test(store("GET_ITEM_BY_STOCK", digAccount, { stock: 1, condition: "or more" }),
  [
    { id: 1, name: "desk chair", category: "chair", stock: 100, price: 3000 },
    { id: 2, name: "very good desk", category: "desk", stock: 50, price: 50000 },
    { id: 4, name: "good bed", category: "bed", stock: 20, price: 30000 },
    { id: 5, name: "bookcase", category: "storage", stock: 50, price: 5000 },
  ]);


// // --------------------------------------------------

test(store("GET_ITEM_BY_NAME", digAccount, { name: "desk chair" }),
[
  { id: 1, name: "desk chair", category: "chair", stock: 100, price: 3000 },
]
);

// // --------------------------------------------------

test(store("DELETE_ITEM", adminAccount, { id: 1 }),true);
test(store("DELETE_ITEM", adminAccount, { id: 6 }),false);
test(store("DELETE_ITEM", tmcAccount, { id: 2 }),false); 