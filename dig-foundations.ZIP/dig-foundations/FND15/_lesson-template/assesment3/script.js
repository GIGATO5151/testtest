'use strict'
// 1行目に記載している 'use strict' は削除しないでください

function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Yay! Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.log("    actual: ", actual);
    console.log("  expected: ", expected);
    console.trace();
  }
}

//////////////////////No.1///////////////////

/**
 * @param {Array<num>} array
 * @returns {Array<num>} 与えられた数字を5以下にして、それを2乗する
 */

  function doTheThing(array){
    return array.filter(element => element <= 5)
                .map(element => element ** 2)
  }

   test(doTheThing([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]), [1, 4, 9, 16, 25]);
   test(doTheThing([10, 9, 8, 7, 6, 5, 4, 3, 2, 1]), [25, 16, 9, 4, 1]);

//////////////////////No.2///////////////////

/**
 * 
 * @returns {Array<num>} getItemsInRefrigeratorで取得、putItemInRefrigeratorで追加
 * 　　　　　　　　　　　removeItemFromRefrigeratorで引数の文字列があったら削除
 */


function create() {
  let itemsInRefrigerator = [];

  function getItemsInRefrigerator() {
    return itemsInRefrigerator;
  }

  function putItemInRefrigerator(elem) {
    itemsInRefrigerator.push(elem);
  }

  function removeItemFromRefrigerator(elem) {
    if (itemsInRefrigerator.includes(elem)) {
      itemsInRefrigerator = itemsInRefrigerator.filter((current) => {
        return current !== elem;
      });
    }
  }
  //与えられた文字列比較し、無かったらはじく。

  return {
    getItemsInRefrigerator,
    putItemInRefrigerator,
    removeItemFromRefrigerator,
  };
//オブジェクト化すれば、全てのクロージャをリターン出来る。

}


const { getItemsInRefrigerator, putItemInRefrigerator, removeItemFromRefrigerator } = create();
//最後にクロージャを作る。
//create() 関数から返されるオブジェクトを分割代入して3つの定数を宣言


      test(getItemsInRefrigerator(), []);

      putItemInRefrigerator("milk");
      test(getItemsInRefrigerator(), ["milk"]);
   
      putItemInRefrigerator("juice");
      test(getItemsInRefrigerator(), ["milk", "juice"]);
   
      removeItemFromRefrigerator("milk");
      test(getItemsInRefrigerator(), ["juice"]);
   
      removeItemFromRefrigerator("milk");
      test(getItemsInRefrigerator(), ["juice"]);

