'use strict'
// 1行目に記載している 'use strict' は削除しないでください

function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Yay! Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.log("    actual: ", actual);
    console.log("  expected: ", expected);
    console.trace();
  }
}

//////////////////////No.1///////////////////

/**
 * @param {Array<string>} array - 友達の名前が入った配列
 * @returns {Array<string>} 友達の名前それぞれに `"Hello"` の挨拶が付け加わった文字列を要素に持つ配列
 */
function sayHelloToFriends(array) {
  let result = [];
  for (const count of array) {
    result.push("Hello, " + count + "!")
  }
  return result;
}

const friends = ["Mario", "Luigi"];
test(sayHelloToFriends(friends), ["Hello, Mario!", "Hello, Luigi!"]);


///////////////////////No.2///////////////////
const obj1 = { a: "A" };
const obj2 = { a: "A", b: 2 };
const obj3 = { a: "A", b: 2, c: "C", d: true };
const obj4 = { a: "A", c: "C" };

/**
 * @param {object} object
 * @returns {{ [key: string]: string }} 与えられたオブジェクトによく似たオブジェクト。ただし値が文字列である場合のみ、そのキー・値のペアを持つ。
 */

function filterObjectForStrings(object) {
  let result = {};
  for (const key in object) {
    if (typeof object[key] === "string") {
      result[key] = object[key];
    }
  } return result;
}


test(filterObjectForStrings(obj1), obj1); // 変化なし
test(filterObjectForStrings(obj2), obj1); // キーが "b" のペアは含まれていない
test(filterObjectForStrings(obj3), obj4); // キーが "b" または "d" のペアは含まれていない


///////////////////No.3/////////////////////////


/**
 * @param {Array<object>} arrayOfObjects - オブジェクトを要素に持つ配列
 * @returns {Array<{ [key: string]: string }>} 与えられたオブジェクトを要素に持つ配列。ただし値が文字列である場合のみ、各オブジェクトはそのキー・値のペアを持つ。
 */
function filterArrayForStrings(arrayOfObjects) {
  let result = [];
  for (const array of arrayOfObjects) {
    result.push(filterObjectForStrings(array))
  }
  return result;
}


test(filterArrayForStrings([obj1]), [obj1]); // 変化なし

// 2 番目の要素からキー が "b" のペアは除くこと
test(filterArrayForStrings([obj1, obj2]), [obj1, obj1]);

test(filterArrayForStrings([obj3, obj2, obj1]), [obj4, obj1, obj1]);


const names = ["ichi", "ni", "san", "yon"];

for (let i = 0; i < 4; i++) {
  for (let j = 0; j < names.length; j++) {
    for (let k = 1; k < 3; k++) {
      console.log(names[j]);
    }
  }
}


//iが加算されていくたびに、jがnameの配列の長さより小さい時までnameの配列を順に出力し
//kはその配列を連続で何回出力するかをフラグにしている
//これより、　ichi,ichi,ni,ni・・・がname配列分、4回繰り返される。



for (let i = 0; i < 2; i++) {
  console.log("a: " + i);
  for (let i = 0; i < 2; i++) {
    console.log("b: " + i);
    for (let i = 0; i < 2; i++) {
      console.log("c: " + i);
    }
  }
}



//合っていた
//まずiが宣言されて、ループスタートし、aのfor文はi=0となる。次のbのfor文でまたcのfor文で0となる、
//cはそこでloopが始まり、次はcのiには1が代入され、抜けて。bのfor文に行く、そしてbのfor文は1となり
//cにいくが、またcはi=0が定義されているので、i=0となり、c=0,c=1を出力し、bのfor文へ。bは条件を終了しているので
//aのfor文にに帰りi=1をして、同じ動作を繰り返していく。各セクションのiはブロックスコープ内限定になっており
//外側のiには影響させない為、別々の変数としての動きをしている。



