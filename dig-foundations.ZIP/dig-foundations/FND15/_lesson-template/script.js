'use strict'
// 1行目に記載している 'use strict' は削除しないでください
function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.group("Result:");
    console.log("  actual:", actual);
    console.log("expected:", expected);
    console.groupEnd();
  }
}


// function isEven(num){
//   if( num % 2 === 0){
//     return true;
//   }
//     return false;
// }

// console.log(isEven(121));


// function isEven(num){
//       num = num / 2;
//     if(Number.isInteger(num)){
//       return true;
//     }
//       return false;
//   }

//   console.log(isEven(121));


// // オブジェクトの定義
// let obj = {};

// // 配列の定義
// let array = ['a', 1];

// // 配列の要素をオブジェクトのプロパティに代入
// obj[array[0]] = array[1];

// console.log(obj); // 結果: {a: 1}

// console.log("基礎演習3");
// /**    * @param {string} text - モールス信号に変換する文字 
// *    * @returns {string} 与えられた文字に対応するモールス信号  
//   */
// const morseCode =
// {
//   t: "-",
//   a: ".-",
//   r: ".-.",
// }

// function morseCodeArt(text) {
//   let result = "";
//   //console.log(result.length);
//   for (const morse of text) {
//       let aaa = result.length
//     if (aaa === 0) {
//       result = morseCode[morse];
//       //console.log(result);
//       aaa++;
//     }
//      if (aaa > 1) {
//       result = result + " ";
//       console.log(result);
//       result += morseCode[morse];
//       //console.log(result.length);
//     }
//   }
//   console.log(result);
//   return result;
// }

// const morseCode =
// {
//   t: "-",
//   a: ".-",
//   r: ".-.",
// }


// function morseCodeArt(text) {
//   let result = "";
//   for (const morse of text) {
//     if (result.length === 1) {
//       result = result + morseCode[morse];
//       console.log(result);

//       result = result + morseCode[morse] + " ";
//       console.log(result);
//     }
//     result = result + morseCode[morse];
//     console.log(result);
//   }
//   return result;
// }




// test(morseCodeArt("a"), ".-");
// test(morseCodeArt("r"), ".-.");
// test(morseCodeArt("t"), "-");
// test(morseCodeArt("art"), ".- .-. -");//.-.-.-   .- .-. -


// // const morseCode =
// // {
// //   t: "-",
// //   a: ".-",
// //   r: ".-.",
// // }

// function morseCodeArt(str) {

//   let result;

//   let i = 1;
//   for (const cnt of str) {
//     if (i === 1) {
//       i++; //i = 2;
//       if (cnt === "a") {
//         result = morseCode[cnt];
//       }

//       if (cnt === "r") {
//         result = morseCode[cnt];
//       }

//       if (cnt === "t") {
//         result = morseCode[cnt];
//       }
//     }

//     else {

//       if (cnt === "a") {
//         result += " " + morseCode[cnt];
//       }

//       if (cnt === "r") {

//         result += " " + morseCode[cnt];
//       }

//       if (cnt === "t") {
//         result += " " + morseCode[cnt];
//       }
//     }
//   }
//   return result;
// }

// test(morseCodeArt("a"), ".-");
// test(morseCodeArt("r"), ".-.");
// test(morseCodeArt("t"), "-");
// test(morseCodeArt("art"), ".- .-. -")

// function countCharacters(str) {

//   const result = {};
//   for (const array of str) {
//     if (!(array in result)) {
//       result[array] = 1;
//     }
//     else {
//       result[array] = result[array] + 1;
//       console.log(result[array]);
//     }
//     console.log(result);
//   }
//   return result;
// }

// test(countCharacters("hello"), { h: 1, e: 1, l: 2, o: 1 });
// test(countCharacters("hello hello"), { h: 2, e: 2, l: 4, o: 2, " ":1 });






//  /**
//     * @param {Array<number>} numArray - 数値型の要素を持つ配列

//     * @returns {Array<number>} 与えられた配列の中の３の倍数だけが入った配列
//     */
//  function getOddNumbers(numArray) {
//   let result = [];
//   for(const count of numArray){
//     if(count % 3 === 0){
//       result.push(count);
//     }
//   }
//   return result;
// }

// test(getOddNumbers([1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12]),  [3, 6, 9, 12]);

// // テストを書きましょう。


// ///////Objct////////////////////////

//    /**
//     * @param {string} str
//     * @returns {{ [character: string]: number }} 与えられた文字列の中の各アルファベットをキーに、その登場回数を値にしたオブジェクト.ただし、スペースはいれない
//     */
//     function countCharacters(str){
//       let result = {};
//       for(const count of str){
//         if(!(count === " ")){
//         if(!(count in result)){
//         result[count] = 1;
//         }
//         else{
//         result[count]++  
//         }
//       }
//     } 
//       return result;
//     }

//    test(countCharacters("hello"), { h: 1, e: 1, l: 2, o: 1 });
//    test(countCharacters("hello hello"), { h: 2, e: 2, l: 4, o: 2 });




// //for in loop /////

// /**
//  * @param {object} ??? - オブジェクト。ただし値はすべて異なるものとする。
//  * @returns {object} 与えられたオブジェクトのキーと値を入れ替えた、新しいオブジェクト
//  */
// // ここにコードを書きましょう

// const object3 = { a: 1, b: 2, c: 3, d: 4 };
// const object4 = { 1: "a", 2: "b", 3: "c", 4: "d" };

// test(swapPairs(object3), { 1: "a", 2: "b", 3: "c", 4: "d" });
// test(swapPairs(object4), { a: "1", b: "2", c: "3", d: "4" });



// //for loop///

// /**
// * @param {Array<number>} ???
// * @returns {Array<number>} 与えられた配列の要素にそれぞれ 1 を加えた数字を要素として持つ配列
// */
// // ここにコードを書きましょう

// const array1 = [1, 2, 3, 4];

// // function が動作するかテストする
// test(addOne(array1), [2, 3, 4, 5]);
// // 元の配列が変更されていないことを確認する
// test(array1, [1, 2, 3, 4]);

// ///////////////

// /**
// * @param {number} start
// * @param {number} end
// * @param {number} step
// * @returns {Array<number>} start 以上 end 以下の整数を、 step の刻みで入れた配列。
// */
// // ここにコードを書きましょう

// test(createRangeBySteps(1, 10, 2), [1, 3, 5, 7, 9]);
// test(createRangeBySteps(10, 30, 5), [10, 15, 20, 25, 30]);




// let x = "Outside x";
// function bar() {
//   let x = "Inside x";
//   return "This is bar!";
// }

// bar();
// console.log(x);


// /**
//  * @param {object} obj - オブジェクト
//  * @param {Array<string>} str - 文字列の入った配列
//  * @returns {object} 与えられた配列の要素をキーにして、それに対応する値は第1引数のオブジェクトから抽出して作られた新しいオブジェクト
//  */
// function select(obj, str) {
//   let result = {};
//   for (const count of str) {
//     console.log(count);
//     console.log(str);
//       result[count] = obj[count];
//     }
//   return result;
// }

// test(select({ a: 1, b: 2, c: 3 }, ["a"]), { a: 1 });
// test(select({ a: 1, b: 2, c: 3 }, ["a", "c"]), { a: 1, c: 3 });
// test(select({ a: 1, b: 2, c: 3 }, ["a", "b", "c"]), { a: 1, b: 2, c: 3 });
// test(select({ a: 1, b: 2, c: 3 }, []), {});

// /**
//  * @param {object} obj - オブジェクト
//  * @param {Array<string>} str - 文字列の入った配列
//  * @returns {object} 与えられた配列の要素をキーにして、それに対応する値は第1引数のオブジェクトから抽出して作られた新しいオブジェクト
//  */
// function select(obj, str) {
//   let result = {};
//   for (const key in obj) {
//     for (const count of str) {
//       console.log(count);
//       console.log(key)
//       if (key === count) {
//         console.log("aaaa")
//         result[count] = obj[key];
//       }
//     }
//   }
//   return result;
// }

// test(select({ a: 1, b: 2, c: 3 }, ["a"]), { a: 1 });
// test(select({ a: 1, b: 2, c: 3 }, ["a", "c"]), { a: 1, c: 3 });
// test(select({ a: 1, b: 2, c: 3 }, ["a", "b", "c"]), { a: 1, b: 2, c: 3 });
// test(select({ a: 1, b: 2, c: 3 }, []), {});

// let color = ["red", "blue", "yellow"]

// function randomNumber2(arg) {
//   return Math.floor(Math.random() * (arg));
// }

// let aaa = document.getElementsByClassName("title");
// for (let i = 0; i < aaa.length; i++) {
//   aaa[i].style.background = color[randomNumber2(color.length)];
// }

// console.log(color[0])

// console.log(color[randomNumber2(color.length)]);

//'use strict';
// please do not delete the 'use strict' line above

// document.getElementById('color-button').addEventListener('click', changeColor)

// const color = ["#66CCFF","#FFCCFF","#99CCFF","#99FFCC","#FFFFCC"]
// function changeColor() {
//   console.log('Button clicked!'); // feel free to change/delete this line
//   let random = Math.floor( Math.random() * 5 );
//   console.log( color[random]);
  
//   let image = document.getElementById("start");
//   if(color[random]==="#99CCFF"){
//     image.src = "https://1.bp.blogspot.com/-NWGJdB5ebUw/UT10EzjUFyI/AAAAAAAAOrA/WSiOXCmSI90/s1600/animal_jinbeizame.png"
//   }else if (color[random]==="#66CCFF"){
//     image.src = "https://4.bp.blogspot.com/-GY783_04Xsk/VpjBpgEivII/AAAAAAAA25s/G8MR3MGOLkE/s1600/bg_natural_sky.jpg"
//   }else if (color[random]==="#FFCCFF"){
//     image.src = "https://1.bp.blogspot.com/-B0gXHEdatto/Uj_2T4l3M-I/AAAAAAAAX_E/TaXRfvqvZ74/s800/usagi_pink.png"
//   }else if (color[random]==="#FFFFCC"){
//     image.src = "https://1.bp.blogspot.com/-xqp2KiGYXn8/Xbo7HEoILEI/AAAAAAABVy0/G7Psvp1lsCk3S5fm4kmZUq_k6nqqAKfGQCNcBGAsYHQ/s1600/flower_marigold.png"
//   }else if (color[random]==="#99FFCC"){
//     image.src = "https://4.bp.blogspot.com/-rWqsZt0T9DI/VMItrbRsdtI/AAAAAAAAqw0/5nNB8-0mJ9k/s800/bird_mejiro.png"
//   }
  
//   document.body.style.backgroundColor = color[random];
// }

//////////////////////No.2///////////////////
/**
 * @param {obj} obj
 * @param {string} str
 * @returns {Array<num>} オブジェクト中、ターゲットにマッチする値を持つ全てのキーを含む新しい配列を返します。
 */

function findKeys(obj, str) {
  const result = Object.keys(obj).reduce((acc, key) => {
    if (obj[key] === str) {
      acc.push(key);
    }
    return acc;
  }, []);
  return result;
}

test(findKeys({ a: 1, b: 2, c: 6, d: 4, e: 2 }, 2), ["b", "e"]); // ["b", "e"]
test(findKeys({ 1: "h", b: "el", c: "hello", d: "hello", e: "o" }, "hello"), ["c", "d"]); // ["c", "d"]

//

  /**
    * @param {Array<string>} names - 友達の名前が入った配列
    * @returns {Array<string>} 友達の名前それぞれに `"Hello"` の挨拶が付け加わった文字列を要素に持つ配列
    */
    function sayFourHellos(names){
      let result = [];
      for(let i = 0; i < names.length;i++){
        result = "Hello, " + names[i] + "!";
      }
      return result;
    }

   const friends = ["Mario", "Luigi"];
   test(sayHelloToFriends(friends), ["Hello, Mario!", "Hello, Luigi!"]);

   