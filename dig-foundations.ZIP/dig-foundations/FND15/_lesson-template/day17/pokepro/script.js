'use strict'
// Please don't delete the 'use strict' line above


function test(actual, expected) {
  if (JSON.stringify(actual) === JSON.stringify(expected)) {
    console.log("Yay! Test PASSED.");
  } else {
    console.error("Test FAILED. Keep trying!");
    console.log("    actual: ", actual);
    console.log("  expected: ", expected);
    console.trace();
  }
}


console.log(allPokemon);
console.log(allPokemon.length);
console.log(allPokemon[0].Name);

////////////////////////基本演習No.1//////////////

/**
 * @returns {Array<string>} データ中のすべてのポケモンの名前を要素に持つ配列
 */
// function getNames() {
//   let result = [];
//   for (let i = 0; i < allPokemon.length; i++) {
//     result.push(allPokemon[i].Name);
//   }
//   return result
// }

// test(getNames(), getNamesExpected);

////////////////////////基本演習No.2//////////////

/**
* @param {string} str - ポケモンの名前
* @returns {object} 与えられた名前を持つポケモンのオブジェクト
*/
function getPokemonByName(str) {
  let result = {};
  for (const obj of allPokemon) {
    for (const key in obj) {
      if (obj.Name === str) {
        result = obj;
      }
    }
  }
  return result;
}


test(getPokemonByName("Pikachu"), getPokemonByNameExpected);


////////////////////////基本演習No.3//////////////


/**
* @returns {number} 全ポケモンの最大CP（戦闘力）の平均値
*/

// コンピュータは内部で2進法を使っているため、10進法の小数点以下の計算で誤差がでることがあります。

// このテストで計算した値が期待値と全く同じでなくても近似値であれば合格として、テストをコメントアウトしておいてください。
function getAvgMaxCP() {
  let result = 0;
  for (let i = 0; i < allPokemon.length; i++) {
    result += allPokemon[i].MaxCP
    //console.log(result);
  }
  return result / allPokemon.length
}

test(getAvgMaxCP(), getAvgMaxCPExpected);

////////////////////////基本演習No.4//////////////

/**
* @param {string} attack（技）
* @returns {Array<object>} 与えられた技に耐性がある、すべてのポケモンのオブジェクトが入った配列
*/
function getResistantPokemon(attack) {
  let result = [];
  let sum = 0
  for (let i = 0; i < allPokemon.length; i++) {
    for (let j = 0; j < allPokemon[i].Resistant.length; j++) {
      if (attack === allPokemon[i].Resistant[j]) {
        //console.log(allPokemon[i]);
        result.push(allPokemon[i]);
      }
    }
  }
  return result;
}

test(getResistantPokemon("Fire"), getResistantPokemonExpected);

////////////////////////基本演習No.5//////////////


/**
* @param {string} attack（技）
* @returns {Array<string>} 与えられた技に耐性がある、すべてのポケモンの名前が入った配列
*/
function getResistantPokemonNames(attack) {
  let result = [];
  for (let i = 0; i < getResistantPokemon(attack).length; i++) {
    //console.log(getResistantPokemon(attack)[i]);
    result.push(getResistantPokemon(attack)[i].Name)
  }
  return result;
}


test(getResistantPokemonNames("Ice"), getResistantPokemonNamesExpected);

////////////////////////基本演習No.6//////////////

   /**
    * @returns {{ [weakness: string]: number }} 弱点とその弱点を持つポケモンの数の組み合わせをキー/値のペアで表現したオブジェクト
    */
  function getWeaknessCounts(){
    let result = {};
    //console.log(getWeaknessCountsExpected);
    for(let i = 0; i < allPokemon.length; i++){
      for(let j = 0; j < allPokemon[i].Weaknesses.length; j++){
        console.log(allPokemon[i].Weaknesses[j])
        if(!(allPokemon[i].Weaknesses[j] in result)){
          console.log("ない")
          result[allPokemon[i].Weaknesses[j]] = 1
          console.log(result);
        }
        else{
          console.log("ある")
          result[allPokemon[i].Weaknesses[j]]++;
          console.log(result);
        }
      }    
    }
    return result;
  }
   test(getWeaknessCounts(), getWeaknessCountsExpected);


   ///////////////////////中級演習No.1///////////////////

   function getNames() {
    let result = [];
    allPokemon.forEach(element => {    //配列.forEachで一つずつelementに出る。それの.Nameを取ることでキーに対する値が出る。
      console.log(element.Name)
      result.push(element.Name);
    });
    return result; //forEachが抜けたところで、returnが必要
   }
  
  test(getNames(), getNamesExpected);

  // .map, .filter, .forEach, .reduceは便利
