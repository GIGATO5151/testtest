'use strict'
// 1行目に記載している 'use strict' は削除しないでください


const obj1 = { a: "A", b: "B" }

const obj2 = { b: "B", a: "A" }

test(obj1, obj2)


//////////////////////////////////////////////
function doubleArray(array) {
  let result = [];
  for (let i = 0; i < array.length; i++) {
    result.push(array[i] * 2);
  }
  return result;
}

test(doubleArray([2, 3, 4, 5, 6]), [4, 6, 8, 10, 12]); // => [4, 6, 8, 10, 12]


function squareArray(array) {
  const result = [];
  for (let i = 0; i < array.length; i++) {
    result.push(array[i] ** 2);
  }
  return result;
}

test(squareArray([2, 3, 4, 5, 6]), [4, 9, 16, 25, 36]); // => [4, 6, 8, 10, 12]

/////////////////////////////////////////////

function double(num) {
  return num * 2;
}

const originalArray = [2, 3, 4, 5, 6];

const newArray = originalArray.map(double);

console.log(newArray);


///////////////////////////////基礎演習No.1/////////////////////////

// /**
//    * @param {string} str
//    * @returns {string} 与えられた引数に挨拶文を追加した文字列
//    */
// function getGreeting(str) {
//   return `Hello, ${str}.`;
// }

// test(["zeno", "yanis", "xander"].map(getGreeting), [
//   "Hello, zeno.",
//   "Hello, yanis.",
//   "Hello, xander.",
// ]);

///////////////////////////////基礎演習No.1(map版）/////////////////////////

function getGreeting(str) {
  let result = str.map(function (Name) {
    return `Hello, ${Name}.`;
  })
  return result;
}

test(getGreeting(["zeno", "yanis", "xander"]), [
  "Hello, zeno.",
  "Hello, yanis.",
  "Hello, xander.",
]);


/////////////////////////////基礎演習No.2/////////////////////////


/**
* @param {number} num
* @returns {number} 与えられた引数の絶対値
*/
function abs(num) {
  let result = [];
  if (Math.sign(num) === 1) {
    result = num
  }
  else {
    result = num * -1;
  }
  return result;
}


test([1, 2, 3].map(abs), [1, 2, 3]);
test([-1, -2, -3].map(abs), [1, 2, 3]);
test([-1, 2, -3].map(abs), [1, 2, 3]);

///////////////////////////基礎演習No.3/////////////////////////////

/**
 * @param {Array<number>} array
 * @returns {Array<number>} 与えられた配列の各要素に 1 を足した数を要素として持つ、新しい配列
 */


function getIncrementedNumbers(array) {
  let result = array.map(function (num) {
    return num + 1
  });
  return result
}

test(getIncrementedNumbers([1, 2, 3]), [2, 3, 4]);
test(getIncrementedNumbers([-1, -2, -3]), [0, -1, -2]);

const array1 = [0, 0, 0];
test(getIncrementedNumbers(array1), [1, 1, 1]);
// 元の配列が変更されていないことを確認してください
test(array1, [0, 0, 0]);



/////////////////////////中級演習No.1//////////////////////////////



/**
    * @param {Array<number|string>} array
    * @returns {Array<number|string>} 与えられた配列の各要素が数値型なら文字列型に、文字列型なら数値型に変換したものが入った、新しい配列
    */
function getSwitched(array) {
  let result = array.map(function (str) {
    if (typeof str === "number") {
      console.log(str);
      return String(str);
    }
    else if (typeof str === "string") {
      return Number(str)
    }
  });
  return result;
}

test(getSwitched([1, 2, 3]), ["1", "2", "3"]);
test(getSwitched(["1", "2", "3"]), [1, 2, 3]);
test(getSwitched(["1", 2, "3"]), [1, "2", 3]);

///////////////////////////応用演習No.1//////////////

/**
 * @param {Array<number>} array
 * @returns {Array<number>} 与えられた配列の各要素とそのインデックスを掛け合わせた数字が要素として入った、新たな配列
 */
function multiplyByIndex(array) {
  let result = array.map(function (num, index) {
    return num * index;
  });
  return result;
}

test(multiplyByIndex([1, 2, 3]), [0, 2, 6]);
test(multiplyByIndex([2, 3, 4]), [0, 3, 8]);
test(multiplyByIndex([-3, -4, -5]), [-0, -4, -10]);

////////////////////////応用演習No.2////////////////////

/**
   * @param {Array<any>} array
   * @param {Function} func - 実行したい関数
   * @param {number} num - 関数を実行したい回数
   * @returns {Array<any>} 与えられた配列の各要素に、実行したい回数だけ関数を実行した結果が入った、新しい配列
   */
function feedback(array, func, time) {
  return array.map(function (num) {
    let result = num;
    for (let i = 0; i < time; i++) { //繰り返しが使える。
      result = func(result); //ここでdouble(配列の数値)を引数回実行した結果を代入
    }
    return result;
  });
}
function double(element) {
  return element * 2;
}

test(feedback([1, 2, 3], double, 1), [2, 4, 6]);
test(feedback([1, 2, 3], double, 2), [4, 8, 12]);
test(feedback([1, 2, 3], double, 8), [256, 512, 768]);