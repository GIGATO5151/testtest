'use strict'
// 1行目に記載している 'use strict' は削除しないでください

function isMultipleOfThree(numA) {
    return (numA % 3 === 0);
  }

  // テスト
  console.log(isMultipleOfThree(6)); // => true
  console.log(isMultipleOfThree(10)); // => false


  function isMultipleOf(numA,numB) {
    return (numA % numB === 0);
  }

  // テスト
  console.log(isMultipleOf(-3, 3)); // => true
  console.log(isMultipleOf(10, 4)); // => false


let broke = true;
let tired = false;

// function aaa(){

// if (broke === true){
//    //return console.log("悲しい");
// } 
// if (tired === true){
//     console.log("コーヒーを買う");
// }else {
//     console.log("プログラミングする");
// }

// }

function printDataType(data) {
    if (typeof data === "number") {

      console.log("This is a number.");
    } 

    else if (typeof data === "string"){

      console.log("This is a string.");

    } 
    else if (typeof data === "boolean"){

      console.log("This is a boolean.");

    } 
    else if(typeof data === "undefined"){

      console.log("This is not a string, boolean, or number.");

    }
      
}

  printDataType(42); // => "This is a number."
  printDataType("Hello!"); // "This is a string." が表示されるようにする。
  printDataType(true); // => "This is a boolean."
  printDataType(undefined); // => "This is not a string, boolean, or number."