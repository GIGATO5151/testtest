'use strict'
// 1行目に記載している 'use strict' は削除しないでください

console.log("Hello World");

function simplePasswordLock(password) {
    if (password === "password") {
      return "Correct! Welcome.";
    }
    return "Incorrect password, please try again.";
  }

  console.log(simplePasswordLock("qwerty")); // => "Incorrect password, please try again."
  console.log(simplePasswordLock("password")); // => "Correct! Welcome."


  console.log("Hello".length);
  console.log("The length of this string is 31".length);
  console.log(" spaces! ".length); //スペースも長さとして1カウント

  function isItTooLong(long){
    if(long.length > 10){
    return true;
    } 
    return false;
  }

  console.log(isItTooLong("1234567890"));


  function biggerNumber(numOne, numTwo) {
    if(numOne > numTwo){
    return 'The first argument is bigger.';
    }
    else if(numOne === numTwo){
        return 'The first and The second argument is same.'
    }
    {
        return 'The second argument is bigger.';
    }
  } 

   console.log(biggerNumber(4, 3)); // 'The first argument is bigger.' を表示
   console.log(biggerNumber(2, 4)); // => 'The second argument is bigger.'
   console.log(biggerNumber(4, 4)); // => 'The first and The second argument is same.'

   function printDataType(data) {
    if (typeof data === "number") {
      console.log("This is a number.");
    }
    else if(typeof data === "string"){
      console.log("This is a string.");
    }
    else if(typeof data === "boolean"){
      console.log("This is a boolean.");
    }
    else if(typeof data === "undefined"){
      console.log("This is not a string, boolean, or number.");
    }
    // More code here.
  }
   printDataType(42); // => "This is a number."
   printDataType("Hello!"); // "This is a string." が表示されるようにする。
   printDataType(true); // => "This is a boolean."
   printDataType(undefined); // => "This is not a string, boolean, or number."

   function greeting(name,greet) {
   if(greet === 'Japanese'){ 
    return "Konnichiwa, " + name +"!";   
   }
   if(greet === "English"){
    return "Hello, " + name +"!"; 
   }
   if(greet === "German"){
    return "Gutentag, " + name +"!";
   }
   if(greet === "Spanish"){
    return "Hola, " + name +"!";
   }
}

 console.log(greeting("Harry Potter", "Japanese")); // "Konnichiwa, Harry Potter!" が表示されるようにする。
 console.log(greeting("Harry Potter", "English")); // => "Hello, Harry Potter!"
 console.log(greeting("Harry Potter", "German")); // => "Gutentag, Harry Potter!"
 console.log(greeting("Harry Potter", "Spanish")); // => "Hola, Harry Potter!"

function isEven(num){
    if(num % 2 === 0){
        return true;
    }
    else if(typeof num !== "number"){
        return  "This is not a number." ;
    }
    return false;
}

   console.log(isEven(4)); // true が表示されるようにする。
   console.log(isEven(7)); // => false
   console.log(isEven("a")); // => 'This is not a number.'

   function isOdd(num){
    if(num % 2 === 1){
        return true;
    }
    return false;
   }
   console.log(isOdd(3));

   function isPositive(num){
    if(Math.sign(num) === 1){
        return true;
    }
    return false;
   }
   console.log(isPositive(3));

   function isNegative(num){
    if(Math.sign(num) === -1){
        return true;
    }
    return false;
   }
   console.log(isNegative(-2));

   function isZero(num){
    if(Math.sign(num) === 0){
        return true;
    }
    return false;
   }
   console.log(isZero(-0));

   function guessMyNumber(n) {
    if (n > 5) {
      return "Please try a number between 0 and 5.";
    } else if (n === randomNumber(5)) {
      return "YES!";
    }
    return "NO!";
  }

    function randomNumber(n) {
    return Math.floor(Math.random() * (n + 1));
  }

  console.log(guessMyNumber(3));

//応用//

  let box;
  let arg = 10;

  function randomNumber2(arg) {
    return Math.floor(Math.random() * (arg + 1));
  }

  box = randomNumber2(arg)
  
  function randomStopLight(){
    if(box < 3){
        console.log(box);
        return "🔴Red";
    }
    if(box >= 3 && box <= 6){
        console.log(box);
        return "🟡Yellow";
    }
    if(box > 6){
        console.log(box);
        return "🟢Green";
    }

  }
  console.log(randomStopLight());
   
