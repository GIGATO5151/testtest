'use strict'
// 1行目に記載している 'use strict' は削除しないでください


const obj1 = { a: "A", b: "B" }

const obj2 = { b: "B", a: "A" }

test(obj1, obj2)

///////////////ウォームアップ/////////////////////

const arrayOfObjects = [
  { name: "alice", favoriteColor: "green" },
  { name: "bob", favoriteColor: "blue" },
];

function getNames(array){
  return array.map((element) => element.name
  )};

function getFavoriteColors(array){
    return array.map((element) => element.favoriteColor
    )};


test(getNames(arrayOfObjects), ["alice", "bob"]);
test(getFavoriteColors(arrayOfObjects), ["green", "blue"]);



//////////////////////////////////////////////

function evenArray(array) {
  let result = [];
  for (const count of array) {
    if (count % 2 === 0) {
      result.push(count);
    }
  }
  return result;
}

console.log(evenArray([2, 3, 4, 5, 6]));

///////////////////////////////////////////

function greaterThanThreeArray(array) {
  let result = [];
  for (const count of array) {
    if (count > 3) {
      result.push(count);
    }
  }
  return result;
}

console.log(greaterThanThreeArray([2, 3, 4, 5, 6]));

////////////////基礎演習No.1/////////////////////////

/**
 * @param {number} num
 * @returns {boolean} 与えられた数値が 10 の倍数かどうか
 */
function isMultipleOfTen(num) {
  return num % 10 === 0;
}


const arrayOfNumbers = [2, 4, 6, 8, 10, 15, 20, 30, 66, 89, 100];

test(arrayOfNumbers.filter(isMultipleOfTen), [10, 20, 30, 100]);
test(arrayOfNumbers.slice(6).filter(isMultipleOfTen), [20, 30, 100]);

////////////////基礎演習No.2/////////////////////////

/**
 * @param {string} str
 * @returns {boolean} 与えられた文字列に母音 (a, e, i, o, u) が1つ以上含まれているか
 */
  function hasAVowel(str){
    for(const word of str){
      //console.log(word);
      if (word === "a" || word ===  "e" || word ==="i" ||word === "o" ||word === "u"){
        return true //filterはtrueを返す時のみ新しい配列に代入する。
      }
    }
    return false
  }


const arrayOfStrings1 = ["bat", "ball", "tree", "cow", "bnm"];
const arrayOfStrings2 = ["bhg", "waa", "cvb"];

test(arrayOfStrings1.filter(hasAVowel), ["bat", "ball", "tree", "cow"]);
test(arrayOfStrings2.filter(hasAVowel), ["waa"]);

////////////////基礎演習No.3/////////////////////////

   /**
    * @param {Array<number>} numArray
    * @returns {Array<number>} 与えられた配列の中にある正の数のみを要素として持つ配列
    */
  function getPositiveNumbers(numArray){
    return numArray.filter((element) => 
    Math.sign(element) === 1);
  }

   test(getPositiveNumbers([1, 2, 3, 4, 5]), [1, 2, 3, 4, 5]);
   test(getPositiveNumbers([0, 1, 2, 3, 4, 5]), [1, 2, 3, 4, 5]);
   test(getPositiveNumbers([1, -2, 3, -4, 5]), [1, 3, 5]);
   test(getPositiveNumbers([-2, -4]), []);


   ////////////////基礎演習No.4/////////////////////////

    /**
    * @param {Array<string>} arrayStr
    * @returns {Array<string>} 与えられた配列の中にある、大文字で始まり、疑問符で終わる文字列のみを要素として持つ配列
    */
    function getQuestions(arrayStr){
      return arrayStr
      .filter((element) => element.charAt(0) === element.charAt(0).toUpperCase())
      .filter((element) => element.charAt(element.length - 1) === "?")
      }
      

   const arrayOfStrings3 = [
    "Hi, there.",
    "What in the world?",
    "My name is JavaScript",
    "Do you want to know a secret?",
  ];

  test(getQuestions(arrayOfStrings3), [
    "What in the world?",
    "Do you want to know a secret?",
  ]);
  test(getQuestions(arrayOfStrings3.slice(2)), [
    "Do you want to know a secret?",
  ]);

  ///////////////////////中級演習No.1//////////////////////////

     /**
    * @param {Array<string>} arrayStr
    * @returns {Array<string>} 与えられた配列の中にある、長さが奇数で、文字がすべて大文字の文字列のみを要素として持つ配列
    */
    function getOddLengthCapitalWords(arrayStr){
      return arrayStr
      .filter((element) => element.length % 2 === 1)
      .filter((element) => element === element.toUpperCase())
    }



   const arrayOfStrings4 = ["SNAKE", "APPLES", "Peaches", "PUMPKINPIES"];

   test(getOddLengthCapitalWords(arrayOfStrings4), ["SNAKE", "PUMPKINPIES"]);
   test(getOddLengthCapitalWords(arrayOfStrings4.slice(1)), ["PUMPKINPIES"]);


   ///////////////////////中級演習No.2//////////////////////////

      /**
    * @param {Array<any>} array1
    * @param {Array<any>} array2
    * @returns {Array<any>} 与えられた配列の両方に存在する要素だけが入った配列
    */
    function intersection(array1,array2){
      return array1.filter(element => array2.includes(element));
    }
  //filter() メソッドを使って、array1 の要素を1つずつ処理し、 array2  にその要素が含まれているかどうかを includes() メソッドで確認します。
  //includes() が true を返した場合は、その要素を新しい配列に含めます。そして、最終的に、新しい配列を返します。

   test(intersection([1, 2, 3], [1, 2, 3]), [1, 2, 3]);
   test(intersection([1, 2, 3], [2, 3, 4]), [2, 3]);
   test(intersection([1, 2, 3], [3, 4, 5]), [3]);
   test(intersection([1, 2, 3], [4, 5, 6]), []);

   ////////////////////応用演習No.1////////////////////////////////

   /**
    * @param {...Array<any>} array - 任意の数の配列
    * @returns {Array<any>} 与えられた配列のすべてに共通する要素だけが入った配列
    */
   function intersection2(...arrays){
    return arrays.reduce((prev, current) => {console.log(prev); console.log(current)
      return prev.filter(element => current.includes(element));
    });
  }
  //reduce() メソッドを使っています。reduce() メソッドは、配列を1つの値にまとめることができるメソッドで
  //各要素に対して順番に処理を行い、最終的に1つの値を返します。

  //prevには今回の比較するarray[0]([1,2,3]),currentにはarray[1]([2,3,4])を渡して
  //filterで実行し、[2,3]
  //次に[2,3]がprevに、cureentに[3,4,5]が渡されて、[3]が出力される。


   test(intersection2([1, 2, 3], [1, 2, 3], [1, 2, 3]), [1, 2, 3]);
   test(intersection2([1, 2, 3], [2, 3, 4], [3, 4, 5]), [3]);
   test(intersection2([1, 2, 3], [3, 4, 5], [6]), []);
   test(
     intersection2([1, 2, 3], [1, 2, 3], [1, 2, 3], [1, 2, 3], [4, 5, 6]),
     []
   );


 ////////////////////応用演習No.2////////////////////////////////


   /**
    * @param {...Array<any>} array
    * @returns {Array<any>} 与えられた配列の 1 つにしか存在しない要素だけが入った配列
    */
   function loneRangers(...arrays) {
    const flattened = arrays.flat();
    console.log(flattened);
    return flattened.filter((element) => {
      return flattened.indexOf(element) === flattened.lastIndexOf(element);
    });
  }

  //indexOf メソッドは、配列内で要素を最初に見つけた位置のインデックスを返す。
  //一方、lastIndexOf メソッドは、配列内で要素を最後に見つけた位置のインデックスを返す

  //flattened 内で要素が1つしかない場合、その要素の indexOf と lastIndexOf の返り値は同じになる。
  //つまり、配列内で要素が1つしかない場合は filter によって結果に残る。

  //flattened 内で要素が2つ以上ある場合、indexOf と lastIndexOf の返り値が異なる要素だけが、
  //結果の配列に残る。たとえば、flattened 内で要素 3 の最初のインデックスが 2、最後のインデックスが 8 だとすると、
  //indexOf は 2 を、lastIndexOf は 8 を返す。
  //この場合、要素 3 は flattened 内に複数回出現しているため、結果の配列には含まれません。⇒false



   test(loneRangers([1, 2, 3]), [1, 2, 3]);
   test(loneRangers([1, 2, 3], [1, 2, 3]), []);
   test(loneRangers([1, 2, 3], [1, 2, 3], [1, 2, 3, 4]), [4]);
   test(loneRangers([1, 2, 3], [1, 2, 3], [1, 2, 3, 4], [5], [6]), [4, 5, 6]);

