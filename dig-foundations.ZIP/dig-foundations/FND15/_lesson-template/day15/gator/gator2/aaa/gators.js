
console.log(document.getElementsByClassName("box"));
console.log(document.getElementsByClassName("bluebox"));

console.log(document.getElementById("button"));

console.log(document.getElementById("kazu"));

console.log(document.getElementById("kazu").ariaValueMax)


function OnButtonClick(){
  let gatorText ="";
  const numGators = document.getElementById("kazu").value
  for(let i = 0; i < numGators; i++){
  gatorText += "🐊";
  }
  target.innerText = gatorText;
}

target = document.getElementsByClassName("bluebox")[0];
const push = document.getElementById("button1");
push.addEventListener("click",OnButtonClick);
