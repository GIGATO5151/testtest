console.log(document.getElementsByClassName("box"));
console.log(document.getElementsByClassName("bluebox"));


function OnButtonClick() {
  const numGators = document.getElementById("name").value;
  const target = document.getElementsByClassName("bluebox")[0];
  let gatorText = "";
  for(let i = 0; i < numGators; i++){
    gatorText += "🐊";
  }
  target.innerText = gatorText;
}



  //button.addEvnetListener("click",gatorOut)
