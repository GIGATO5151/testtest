'use strict'
// 1行目に記載している 'use strict' は削除しないでください

console.log("Hello world!");

function addTen(number){
    console.log(number + 10);
}

addTen(5);


function add(numOne, numTwo) {
    return numOne + numTwo;
  }

  // テスト
  console.log(add(4, 3)); // 7 を表示
  console.log(add(100, 42)); // => 142

  console.log(add(100)); // 何が起こる？
  console.log(add(1, 4, 5)); // 何が起こる？



  function simpleFunctionA() {
    return "Hello simple function A";
  }

  function simpleFunctionB() {
    console.log("Hello simple function B");
  }

  console.log(simpleFunctionA(), "--> From running Simple Function A");
  console.log(simpleFunctionB(), "--> From running Simple Function B");
  
  function subtract(num1, num2) {
    // ここにコードを書いてください
    return num1 - num2;
  }

  console.log(subtract(4, 3)); // => 1
  console.log(subtract(100, 42)); // => 58

  function greeting(name){
    return "Hello, " + name + "!";
  }

     console.log(greeting("Alex")); // => "Hello, Alex!"
     console.log(greeting("Beau")); // => "Hello, Beau!"

  function average(num1,num2){
    return (num1 + num2) / 2;
  }
    console.log(average(2,2));

    function cube(x){
        return x ** 3;
    }

    console.log(cube(3));


 function exchange(money){
    return money * 130;
 }

 function exchange1(money,fluc){
    return money * (130 + (fluc - 130));
 }

console.log(exchange(2));
console.log(exchange1(40,110));
