'use strict'
// 1行目に記載している 'use strict' は削除しないでください

//　console.log("Hello world!");

//  function add(numOne, numTwo) {
//     return numOne + numTwo;
//   }

//   console.log(add(100)); //NaN
//   console.log(add(1,4,5)); //1,4だけ処理 5は無視する


// function simpleFunctionA() {
//     return "Hello simple function A";
//   }

//   function simpleFunctionB() {
//     console.log("Hello simple function B");
//   }

//   console.log(simpleFunctionA(), "--> From running Simple Function A");
//   console.log(simpleFunctionB(), "--> From running Simple Function B");

// function subtract(num1, num2) {
//     // ここにコードを書いてください
// 　　return num1 - num2;
//   }

//   console.log(subtract(4, 3));
//   console.log(subtract(100, 42));

//   function greeting(name){
//     return "Hello," + name;
//   }

//   console.log(greeting("Alex"));
//   console.log(greeting("Beau"));

//  function average(ave1,ave2){
//    return (ave1 + ave2)/2;

//  }

// console.log(average(5,5));

// function cube(x) {
//     return x*x*x;
// }

// console.log(cube(3));

// function simpleHelloA() {
//     console.log("hello");
//   }

//   function simpleHelloB() {
//     return "hello";
//   }

//   const a = simpleHelloA();
//   const b = simpleHelloB();
//   console.log(a, b);


function createGreeting(greetingPhrase, instructorName) {
    return greetingPhrase + ", " + instructorName + "!";
  }

  let morningGreeting = createGreeting("Good morning","Mike!");
  let dayGreeting = createGreeting("Hello","Beau!");
  let eveningGreeting = createGreeting("Good evening","Alex!");

  console.log(morningGreeting); //"Good morning, Mike!" を表示
  console.log(dayGreeting); // "Hello, Beau!" を表示
  console.log(eveningGreeting); // "Good evening, Alex!" を表示


  function squArea(S) {
    return squArea = S**2;
  }

  function squPeri(S) {
    return squPeri = 4*S;
  }

   function rectangle(l,w){
    return l * w;
   }

   function rectanglePeri(l,w){
   return 2*l + 2*w;
   }

   function Trapezoid(b1,b2,h){
    return (h * (b1 + b2) / 2);
    }

 console.log(squArea(5));
 console.log(squPeri(5));

 console.log(rectangle(2,3));
 console.log(rectanglePeri(2,3));

 console.log(Trapezoid(2,3,2));


//応用//

