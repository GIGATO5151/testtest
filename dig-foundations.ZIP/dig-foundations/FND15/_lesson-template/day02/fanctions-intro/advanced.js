console.log("hello advanced.js!");

let upperBound = 7;
let x;
let y = 5;

x = randomNumber(upperBound);

function guessMyNumber(n) {
    if (n > upperBound) {
      return "Please try a number between 0 and 5.";
    } 
    if (n === x) {
        console.log(x);
      return "You guessed my number!正しい数字は"+x+"です";
    }else {
        //x = randomNumber(upperBound);
        console.log(x);
    return "違います！正しい数は:" + x +"でした。";
    }
  }

  function randomNumber(upperBound) {
    return Math.floor(Math.random() * (upperBound + 1));
  }
  
  console.log(guessMyNumber(6));

