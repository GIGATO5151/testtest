'use strict'
// 1行目に記載している 'use strict' は削除しないでください

console.log("Hello World!");


// /**
//   * @param {Array<string>} arrayOfPeople - 人の名前の配列
//   * @returns {number} 与えられた配列の長さ
//   */
function numberOfPeople(arrayOfPeople) {
  return arrayOfPeople.length;
}

let actual = numberOfPeople(["Alex", "Beau", "Carlos", "Dustin"]);
let expected = 4;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd("Result:");
}

let students = ["joy", "Emily", "Dustin", "Beau", "Alex"]

/**
    * @param {Array<string>} students - 人の名前の配列
    * @returns {number} 与えられた配列の長さ
    */

actual = numberOfPeople(students);
expected = 5;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd("Result:");
}

///////////////////基礎演習No.3/////////////////////

students.push("a", "b", "c");

actual = numberOfPeople(students);
expected = 8;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd("Result:");
}

///////////////////基礎演習No.4/////////////////////

/**
* @param {Array<any>} array - 配列
* @returns {any} 与えられた配列の最後の要素を返す
*/
function last(array) {
  let result;
  result = array.pop();
  return result;
}

actual = last([1, 2, 3, 4]);
expected = 4;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd("Result:");
}

/**
* @param {Array<any>} array - 配列
* @param {any} num - 配列の最後に追加する値
* @returns {number} 処理後の配列の長さを返す。与えられた配列の末尾に、第 2 引数で渡された要素を追加してください。
*/


function push(array, num) {

  array[array.length] = num;
  return array[array.length - 1];
}


let array = [1, 2, 3, 4];

// 関数が正しい結果を返すことを確認する
actual = push(array, 5);
expected = 5;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd("Result:");
}

// 配列が正しく変更されていることを確認する

actual = array;
expected = [1, 2, 3, 4, 5];

// 上にも書きましたが、配列はそのまま比較することができません。まず、JSON.stringify を使う必要があります。
if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd("Result:");
}

// さらにテストを追加してみましょう。






/**
* @param {Array<any>} array - 配列
* @returns {Array<any>} 配列の真ん中が "hi" に置き換えらえた配列、もしくは同じ配列を返す
*/

function hiInTheMiddle(array) {
  if (array.length % 2 === 1) {
    array[(Math.floor(array.length / 2))] = "hi";
    return array;
  }
  return array;
}

actual = hiInTheMiddle([1, 2, 3, 4, 5]);
expected = [1, 2, "hi", 4, 5];

if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd("Result:");
}

actual = hiInTheMiddle([1, 2, 3, 4]);
expected = [1, 2, 3, 4];

if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd("Result:");
}

actual = hiInTheMiddle([1, 2, 3, 4, 5, 6, 7]);
expected = [1, 2, 3, "hi", 5, 6, 7];

if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd("Result:");
}

/**
 * @param {Array<any>} array - 配列
 * @returns {any} 与えられた配列の最後の要素を返す。
 */
function pop(array) {
  //console.log(array);
  return parseInt(array.splice(-1, 1)); //-1で最後の配列、それを一つ取り出す。⇒splice
  //それをpareseIntで配列を数値型に変換
}

array = [1, 2, 3, 4, 5, 6];

actual = pop(array);
expected = 6;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd("Result:");
}

actual = array;
expected = [1, 2, 3, 4, 5];

if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd("Result:");
}

/**
* @param {Array<any>} array - 配列
* @param {any} num - 配列の先頭に追加する値
* @returns {number} 処理後の配列の長さを返す。
*/
function unshift(array, num) {
  array.splice(0, 0, num);  //先頭に追加する。
  return array.length;
}

array = [1, 2, 3, 4];

actual = unshift(array, 5);
expected = 5;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd("Result:");
}

actual = array;
expected = [5, 1, 2, 3, 4];

if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd("Result:");
}

/**
* @param {Array<any>} array - 配列
* @returns {any} 与えられた配列の先頭の要素を返す。
*/
function shift(array) {
  return parseInt(array.splice(0,1));
}

array = [1, 2, 3, 4];

actual = shift(array);
expected = 1;

if (actual === expected) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd("Result:");
}

actual = array;
expected = [2, 3, 4];

if (JSON.stringify(actual) === JSON.stringify(expected)) {
  console.log("Test PASSED!");
} else {
  console.error("Test FAILED. Keep trying!");
  console.group("Result:");
  console.log("  actual:", actual);
  console.log("expected:", expected);
  console.groupEnd("Result:");
}


// // /////////////////////////////////////応用演習No.1////////////////////////

// // /**
// //   * @param {Array<string>} arrayOfPeople - 人の名前の配列
// //   * @returns {number} 与えられた配列の長さ
// //   */

// let actual;
// let expected;

// function numberOfPeople(arrayOfPeople) {
//     let sum = 0;
//   for (const count of arrayOfPeople){
//     sum++;
//   }
//   return sum;
// }

// actual = numberOfPeople(["Alex", "Beau", "Carlos", "Dustin","Joy","RIN"]);
// expected = 6;

// if (actual === expected) {
//   console.log("Test PASSED!");
// } else {
//   console.error("Test FAILED. Keep trying!");
//   console.group("Result:");
//   console.log("  actual:", actual);
//   console.log("expected:", expected);
//   console.groupEnd("Result:");
// }

////////////////////////////////応用演習2///////////////////////////////
 /**
    * @param {Array<any>} array1 - 1 番目の配列
    * @param {Array<any>} array2 - 2 番目の配列
    * @returns {boolean} 2 つの配列が互いに逆順かどうか
    */
    function areReverses(array1,array2){
      if(JSON.stringify([...array1].reverse()) === JSON.stringify(array2)){ ///[...array1]でシャロコピーを作成。元の配列を変更しない。
        return true;
      }
        return false;
    }

   let array1 = [1, 2, 3, 4];
   let array2 = [4, 3, 2, 1];

   actual = areReverses(array1, array2);
   expected = true;

   if (actual === expected) {
     console.log("Test PASSED!");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.group("Result:");
     console.log("  actual:", actual);
     console.log("expected:", expected);
     console.groupEnd("Result:");
   }

   actual = array1;
   expected = [1, 2, 3, 4];

   // 元の配列が変更されていないことを確認する
   if (JSON.stringify(actual) === JSON.stringify(expected)) {
     console.log("Test PASSED!");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.group("Result:");
     console.log("  actual:", actual);
     console.log("expected:", expected);
     console.groupEnd("Result:");
   }


////////////////////////////////応用演習3///////////////////////////////

      /**
    * @param {Array<any>} array1 - 1 番目の配列
    * @param {Array<any>} array2 - 2 番目の配列
    * @returns {Array<any>} 与えられた 2 つの配列を連結した新しい 1 つの配列を返す
    */
   function concat(array1,array2){

    let aaa = array1.slice();//コピーを作成する。
    for(const count of array2){
    let bbb = parseInt(count);
    aaa.push(bbb);
    }
    return aaa;

  }
    

   array1 = [1, 2, 3, 4];
   array2 = [4, 3, 2, 1];

   actual = concat(array1, array2);
   expected = [1, 2, 3, 4, 4, 3, 2, 1];

   if (JSON.stringify(actual) === JSON.stringify(expected)) {
     console.log("Test PASSED!");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.group("Result:");
     console.log("  actual:", actual);
     console.log("expected:", expected);
     console.groupEnd("Result:");
   }

   // 元の配列が変更されていないことを確認する
   actual = array1;
   expected = [1, 2, 3, 4];

   if (JSON.stringify(actual) === JSON.stringify(expected)) {
     console.log("Test PASSED!");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.group("Result:");
     console.log("  actual:", actual);
     console.log("expected:", expected);
     console.groupEnd("Result:");
   }

   actual = array2;
   expected = [4, 3, 2, 1];

   if (JSON.stringify(actual) === JSON.stringify(expected)) {
     console.log("Test PASSED!");
   } else {
     console.error("Test FAILED. Keep trying!");
     console.group("Result:");
     console.log("  actual:", actual);
     console.log("expected:", expected);
     console.groupEnd("Result:");
   }

   ////////////////////////////////応用演習No.4///////////////////////

let testArray = new Array("A", "B", "C");

testArray.forEach(function(value){
    console.log(value);
});

let testArray2 = new Array(1,2,3);

testArray2.forEach(function (value){
    console.log(value * 2);
});

//forEachによってコールバック関数で呼ばれたものを返す
//詳しくはhttps://camp.trainocate.co.jp/magazine/javascript-foreach/


////////////////////////////////ナイトメア////////////////////////////////


 /**
    * @param {number} num - 数値。その名前がアルファベットの形で返ることになる
    * @returns {number} 与えられた数値をアルファベットで記した時の名前
    */

function getNumberName(num){
  let result = "";
  const digits = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"];
  const teens = ["", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"];
  const tens = ["", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"];


  //もし　引数.lengthが　4以上　6以下　だったら
  //  thousand 加える

  //3桁分を処理する関数を作る
  //thousands と　それ以外　を処理する
  //最後にくっつける


  if (num < 0) { // 引数が負の数の場合、resultに"negative"を加えて、numを正の数に変換する
    result += "negative ";
    num *= -1;
  }

  if (num === 0) {
    return "zero";
  }

  // const thousands = Math.floor(num / 1000);
  // if (thousands > 0) {
  //   result += digits[thousands] + " thousand ";
  //   num = num % 1000;
  // }

//   if(num.length === 4){
//     num.slice(0);
//     console.log(num)
//     unit(num);
//     result += result + " thousands";
//   }


// function unit(){
//   const hundreds = Math.floor(num / 100);
//   if (hundreds > 0) {
//     result += digits[hundreds] + " hundred ";
//     num = num % 100;
//   }

//   const tensPlace = Math.floor(num / 10);
//   const onesPlace = num % 10;

//   if (tensPlace > 1) {
//     result += tens[tensPlace] + " ";
//     if (onesPlace > 0) {
//       result += digits[onesPlace] + " ";
//     }
//   } else if (tensPlace === 1) {
//     result += teens[onesPlace] + " ";
//   } else if (onesPlace > 0) {
//     result += digits[onesPlace] + " ";
//   }

//   return result.trim();
// }
// }

const convertToWords = (num) => {
  let words = "";
  const thousands = Math.floor(num / 1000);
  if (thousands > 0) {
    words += convertToWords(thousands) + " thousand ";
    num = num % 1000;
  }

  const hundreds = Math.floor(num / 100);
  if (hundreds > 0) {
    words += digits[hundreds] + " hundred ";
    num = num % 100;
  }

  const tensPlace = Math.floor(num / 10);
  const onesPlace = num % 10;

  if (tensPlace > 1) {
    words += tens[tensPlace] + " ";
    if (onesPlace > 0) {
      words += digits[onesPlace] + " ";
    }
  } else if (tensPlace === 1) {
    words += teens[onesPlace] + " ";
  } else if (onesPlace > 0) {
    words += digits[onesPlace] + " ";
  }

  return words.trim();
}

result += convertToWords(num);  //resultは最初に負や0を判定しているので、それに最後くっつける。

return result.trim();
}



actual = getNumberName(0);
expected = "zero";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

actual = getNumberName(12345);
expected = "twelve thousand three hundred forty five";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}


actual = getNumberName(-1345);
expected = "negative one thousand three hundred forty five";

if (actual === expected) {
  console.log("Yay! Test PASSED.");
} else {
  console.error("Test FAILED. Keep trying!");
  console.log("    actual: ", actual);
  console.log("  expected: ", expected);
}

