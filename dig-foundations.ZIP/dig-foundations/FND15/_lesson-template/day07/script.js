'use strict'
// 1行目に記載している 'use strict' は削除しないでください

console.log("Hello World!");


// const instructors = ["Kimiko", "Yan", "Dustin", "Dylan"];

// instructors[5] = "k"
// console.log(instructors);
// console.log(instructors.length);
// console.log(instructors[instructors.length - 1]);

// let array1 = [1, 2, 3];
// const array2 = [4, 5, 6];
// array1 = array2;
// array2.push(7);
// console.log("array1 = ", array1);
// console.log("array2 = ", array2);

///////////////////////////////////////////////////

// const numbers = [1, 2, 3];

// console.log(numbers[2]); // 3
// console.log(numbers[0]); // 1
// console.log(numbers[numbers.length - 1]); // 3

// 次で使用しているメソッドやプロパティについて、分からないときはドキュメント（MDN）で調べてみましょう！

//console.log(numbers.pop() + numbers.pop()); // 3 + 2 = 6  配列の最後を除外

// numbers.unshift(4, 5, 6);
// console.log(numbers); // [4,5,6,1,2,3] 前に無理矢理挿入

//console.log(numbers.shift()); // 1

// console.log(numbers.length); // 3

// numbers.push(5); //[1,2,3,5] 5,6,1,5
// numbers.push(6); //[1,2,3,6] 5,6,1,5,6

//console.log(numbers.pop() * numbers.pop()); // 5 * 6 = 30
//console.log(numbers[0]); // 1

//////////////////////////////////////////////////////////

// const numbers = [
//   [0, 1, 2, 3],
//   ["zero", "one", "two", "three"],
//   ["rei", "ichi", "ni", "san"],
// ];
// console.log(numbers[2]); // "rei", "ichi", "ni", "san"
// console.log(numbers[1][1]); // one
// console.log(numbers[0][2]); // 2
// console.log(numbers[numbers.length - 1][0]); // rei
// console.log(numbers[2].length); // 4
// console.log(numbers.pop()); // "rei", "ichi", "ni", "san"
// console.log(numbers[0].push(4)); // 0,1,2,3,4→lengthプロパティだから5
// console.log(numbers.length); // 3

// const string = "hello";
// console.log(string.length); // 5
// console.log(string[0]); // h
// console.log(string[3]); // l
// console.log(string[string.length - 1]); // o

// /////////////////////////////////////応用演習No.1////////////////////////

// /**
//   * @param {Array<string>} arrayOfPeople - 人の名前の配列
//   * @returns {number} 与えられた配列の長さ
//   */

// let actual;
// let expected;

// function numberOfPeople(arrayOfPeople) {
//     let sum = 0;
//   for (const count of arrayOfPeople){
//     sum++;
//   }
//   return sum;
// }

// actual = numberOfPeople(["Alex", "Beau", "Carlos", "Dustin","Joy","RIN"]);
// expected = 6;

// if (actual === expected) {
//   console.log("Test PASSED!");
// } else {
//   console.error("Test FAILED. Keep trying!");
//   console.group("Result:");
//   console.log("  actual:", actual);
//   console.log("expected:", expected);
//   console.groupEnd("Result:");
// }



// /**
//    * @param {Array<string>} arrayOfPeople - 人の名前の配列
//    * @returns {number} 与えられた配列の長さ
//    */
// function numberOfPeople(arrayOfPeople) {
//   return arrayOfPeople.length;
// }

// let actual = numberOfPeople(["Alex", "Beau", "Carlos", "Dustin"]);
// let expected = 4;

// if (actual === expected) {
//   console.log("Test PASSED!");
// } else {
//   console.error("Test FAILED. Keep trying!");
//   console.group("Result:");
//   console.log("  actual:", actual);
//   console.log("expected:", expected);
//   console.groupEnd("Result:");
// }


// let students = ["a", "b", "c", "d", "e"];

// actual = numberOfPeople(students);
// expected = 5;

// if (actual === expected) {
//   console.log("Test PASSED!");
// } else {
//   console.error("Test FAILED. Keep trying!");
//   console.group("Result:");
//   console.log("  actual:", actual);
//   console.log("expected:", expected);
//   console.groupEnd("Result:");
// }

// students.push("f", "g", "h");
// console.log(students);

// actual = numberOfPeople(students);
// expected = 8;

// if (actual === expected) {
//   console.log("Test PASSED!");
// } else {
//   console.error("Test FAILED. Keep trying!");
//   console.group("Result:");
//   console.log("  actual:", actual);
//   console.log("expected:", expected);
//   console.groupEnd("Result:");
// }

// /**
//  * @param {Array<any>} array - 配列
//  * @returns {any} 与えられた配列の最後の要素を返す
//  */
// function last(array) {
//   //return array[array.length - 1];
//   // array.pop();
//   // console.log(array);
//   return array.pop();
// }

// console.log(last(students));
// console.log(students);

