'use strict'
// 1行目に記載している 'use strict' は削除しないでください

console.log("Hello world");



function isEqual(valueOne, valueTwo) {
    return valueOne == valueTwo;
  }

  console.log(isEqual(1, "1"));


  function isGreaterThan(valueOne, valueTwo) {
    return valueOne > valueTwo;
  }

   console.log(isGreaterThan(1,2));

   function isOfAge(age){
    return age >= 20;
   }

   console.log(isOfAge(18));

   

