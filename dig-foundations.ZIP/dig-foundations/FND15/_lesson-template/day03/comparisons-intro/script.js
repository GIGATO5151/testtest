'use strict'
// 1行目に記載している 'use strict' は削除しないでください

console.log("Hello world");

console.log(1100 >= 99) // => true を表示させる。

console.log(1 > 21) // => false

console.log(62 !== 1) // => true

console.log("5" === 5) // => false

console.log("6" !== "six") // => true

console.log(2 + 3 * 10 < 50);

function isEqual(valueOne, valueTwo) {
    return valueOne == valueTwo;
  }

  console.log(isEqual(5, "5"));

  function isGreaterThan(valueOne, valueTwo) {
     return valueOne > valueTwo;

  }

  console.log(isGreaterThan(7,4));


//   function isOfAge(age){
//     return age >= 20;
//   }

//   console.log(isOfAge(20));

function isOfAge(age){
    if(age >= 20){
        console.log("あなたは"+age+"歳なので飲めます！");
        return(age >= 20);
    }
    else{
        console.log("あなたは"+age+"歳なので飲めません！");
        return(age >= 20);
  }
}

  console.log(isOfAge(20));

//   function isEven(n){
//     if(n % 2 === 0){
//     return true;
//     }else{
//     return false;
//   }
//   }
//   console.log(isEven(55));


  function validCredentials(username,password){
    if(username.length >= 5 && password.length >=5){
        return true;
    }else{
        return false;
    }
  }

  console.log(validCredentials("hirok","sent"));


  function isEven(n){
    n = n / 2;
    if(Number.isInteger(n)){
    return true;
    }
    else{
    return false;
  }
}
  console.log(isEven(1202));



  function getGreatestValue(...num){
    return Math.max(...num);
  }

  console.log(getGreatestValue(10, 15)); // 15 を表示
  console.log(getGreatestValue(15, 10)); // 15 を表示
  console.log(getGreatestValue(1, 2, 3, 4, 5)); // 5 を表示
  console.log(getGreatestValue(1, 10, 3, 4, 5,29)); // 10 を表示



  //ナイトメア//

  function flatten(num){
    //console.log("AA:" + num);
    return num.flat();
  }
  
  function flatten(...num){
    let result = [];
    num.map(element => recursion(element));
    return result;

    function recursion(arr){
      if(Array.isArray(arr)){
        arr.map(element => recursion(element));
        return;
      }
      result.push(arr);
    }
  }


  console.log(
    flatten([
      [1, 2, 3],
      [4, 5, 6],
    ])
  ); // [1, 2, 3, 4, 5, 6]
  
  console.log(flatten([1, 2, 3, [4, 5, 6]])); // [1, 2, 3, 4, 5, 6]
  console.log(flatten([[1], [2], [3], [4, 5, 6]])); // [1, 2, 3, 4, 5, 6]
  console.log(flatten([[[1], [2]], [3], [4, 5, 6],[7,[8,[9]]]]));// [1, 2, 3, 4, 5, 6]
  console.log(flatten([[1], [2], [3], [4, 5, 6],[7]],[8,9],[10])); // [1, 2, 3, 4, 5, 6]
















  // function flatten(arr) {
  //   let result = [];
  
  //   function recursiveFlatten(subArr) {
  //     for (let i = 0; i < subArr.length; i++) {
  //       if (Array.isArray(subArr[i])) {
  //         recursiveFlatten(subArr[i]);
  //       } else {
  //         result.push(subArr[i]);
  //       }
  //     }
  //   }
  
  //   recursiveFlatten(arr);
  //   return result;
  // }

  // console.log(
  //   flatten([
  //     [1, 2, 3],
  //     [4, 5, 6],
  //   ])
  // ); // [1, 2, 3, 4, 5, 6]
  // console.log(flatten([1, 2, 3, [4, 5, 6]])); // [1, 2, 3, 4, 5, 6]
  // console.log(flatten([[1], [2], [3], [4, 5, 6]])); // [1, 2, 3, 4, 5, 6]
  // console.log(flatten([[[1], [2]], [3], [4, 5, 6]]));// [1, 2, 3, 4, 5, 6]